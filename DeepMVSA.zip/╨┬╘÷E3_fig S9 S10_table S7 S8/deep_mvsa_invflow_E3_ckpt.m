function [M_est, Sest, Up, my, theta, hist, ctx] = deep_mvsa_invflow_E3_ckpt(Y, p, varargin)
%% DeepMVSA-InvFlow (mini-batch version) + E3 instrumentation hooks
% 在原 code/deep_mvsa_invflow.m 基础上增加两类 E3 钩子（2026-11-23 最终方案）：
%
%   (i) RECORD_AT 节点记录（"单次训练、多节点记录"，GRID 专用）：
%       一次运行到 max(RECORD_AT)，在每个节点保存 theta 快照与确定性
%       全数据完整目标值。节点处**不消耗任何随机数**，因此与"同种子、
%       同 MM_ITERS=节点值 的独立运行"按构造逐步一致（同批序、同 Adam
%       状态流）。等价性须按预注册协议在 K=3, N=1e4 交叉核对（容差 0）。
%
%   (ii) EARLY_STOP 早停（REFERENCE 专用，预注册规则）：
%       联合阶段每 evalEvery 步在全量数据上评估完整目标 F；
%       当 |ΔF|/|F| < relTol（按 perSteps=1000 步窗）且持续 sustainSteps
%       =2000 步（即连续 sustainSteps/evalEvery 次评估均满足）即停；
%       tCap=10000 为预期上限：若到达 tCap 规则仍未触发，按
%       continueToHardMax=true 继续至 tHardMax=50000 并如实记录
%       reason='cap_reached_no_plateau'（论文口径：回退跑满并报告）。
%
% 关键修复（相对原文件）：warm-up 步数取 min(WARM_UP, MM_ITERS)。
%   原实现 warm-up 固定跑满 600 步，MM_ITERS=250/500 的独立运行会执行
%   600 步，与长程运行的前 250/500 步**不等价**；E3 的 T 网格含 250/500，
%   两种模式必须共用同一 guard。移植到 deep_mvsa_invflow_E3.m 时此 guard
%   为必需项。
%
% 新增参数：
%   RECORD_AT   - 整数向量，记录节点（总迭代步口径，含 warm-up）。默认 []。
%   COORD_MODE  - 'index'（E3 正式方案的一维样本索引）/'grid'/'auto'。
%   SKIP_ABUNDANCE_OUTPUT - true 时不生成 p-by-N 的完整丰度矩阵。
%   FULL_BATCH_CHUNK_SIZE - 全批量梯度/完整目标的分块大小；仍是精确 B=N。
%   EARLY_STOP  - struct，字段：enabled (false), evalEvery (250),
%                 relTol (1e-4), perSteps (1000), sustainSteps (2000),
%                 tCap (10000), tHardMax (50000), continueToHardMax (true)。
%
% 新增输出：
%   hist - struct: .nodes 记录节点；.theta_snaps 节点快照（cell）；
%          .fullloss_nodes 节点处全数据完整目标值；
%          .es 早停信息（stopped/t_stop/reason/eval_t/eval_F）。
%   ctx  - 预处理上下文（Q0/Up/D/my/lambda_reg/spherize/p），供
%          recover_endmembers_from_theta 由快照重建端元。
%
% 其余与原 mini-batch 版一致：BATCH_SIZE >= N 即全批量；SEED 固定则
% 批序、初始化、Adam 状态流完全确定。

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'HIDDEN', 32, @(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(pStruct, 'COORD_MODE', 'auto', @ischar);
addParameter(pStruct, 'SKIP_ABUNDANCE_OUTPUT', false, @(x)islogical(x)||isnumeric(x));
addParameter(pStruct, 'FULL_BATCH_CHUNK_SIZE', 50000, @(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);
addParameter(pStruct, 'BATCH_SIZE', 4096, @isnumeric);
addParameter(pStruct, 'SEED', [], @isnumeric);
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'RECORD_AT', [], @isnumeric);          % <<< E3 hook (i)
addParameter(pStruct, 'EARLY_STOP', struct(), @isstruct);    % <<< E3 hook (ii)
parse(pStruct, varargin{:});

% ---- early-stop defaults (pre-registered values) ----
es = struct('enabled', false, 'evalEvery', 250, 'relTol', 1e-4, ...
    'perSteps', 1000, 'sustainSteps', 2000, 'tCap', 10000, ...
    'tHardMax', 50000, 'continueToHardMax', true);
f = fieldnames(pStruct.Results.EARLY_STOP);
for i = 1:numel(f), es.(f{i}) = pStruct.Results.EARLY_STOP.(f{i}); end

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

[L, N] = size(Y);  %#ok<ASGLU>
B = min(pStruct.Results.BATCH_SIZE, N);
full_batch = (B >= N);

MM_ITERS = pStruct.Results.MM_ITERS;
WARM_UP  = min(pStruct.Results.WARM_UP, MM_ITERS);   % <<< E3 必需 guard

nodes = sort(unique(round(pStruct.Results.RECORD_AT(:).')));
nodes = nodes(nodes >= 1 & nodes <= MM_ITERS);
if ~isempty(nodes) && nodes(end) < MM_ITERS
    nodes = [nodes, MM_ITERS];    % 终态必记
end
hist.nodes = nodes;
hist.theta_snaps = cell(1, numel(nodes));
hist.fullloss_nodes = nan(1, numel(nodes));
hist.node_elapsed_s = nan(1, numel(nodes));
hist.es = struct('stopped', false, 't_stop', [], 'reason', 'not_enabled', ...
    'eval_t', [], 'eval_F', []);

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');   % one pass, fixed target

%% --------------------- Coordinates ---------------------
coordMode = lower(strtrim(pStruct.Results.COORD_MODE));
switch coordMode
    case 'index'
        % E3 Section 4.1: one-dimensional sample-index coordinates.
        coords = linspace(-1,1,N);
        coords = coords(:)';
    case 'grid'
        H = round(sqrt(N)); W = round(N/H);
        if H*W == N
            [gx, gy] = meshgrid(linspace(-1,1,W), linspace(-1,1,H));
            coords = [gx(:)'; gy(:)'];
        else
            coords = linspace(-1,1,N); coords = coords(:)';
        end
    case 'auto'
        H = round(sqrt(N)); W = round(N/H);
        if H*W == N
            [gx, gy] = meshgrid(linspace(-1,1,W), linspace(-1,1,H));
            coords = [gx(:)'; gy(:)'];
        else
            coords = linspace(-1,1,N); coords = coords(:)';
        end
    otherwise
        error('COORD_MODE must be ''index'', ''grid'', or ''auto''.');
end
coord_dim = size(coords,1);

%% --------------------- A-Net parameters ---------------------
hidden = round(pStruct.Results.HIDDEN);
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = 0.05;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);
theta.R = zeros(p,p);
theta.r_log = zeros(p,1);

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;
trainStart = tic;
fullBatchChunkSize = max(1, round(pStruct.Results.FULL_BATCH_CHUNK_SIZE));

if pStruct.Results.verbose
    fprintf('Mini-batch training: N=%d, batch=%d, steps/epoch=%.1f\n', N, B, N/B);
end

% ctx：供事后由 theta 快照重建端元（与原"Recover endmembers"一致）
ctx = struct('Q0', Q0, 'Up', Up, 'D', D, 'my', my, 'p', p, ...
    'spherize', pStruct.Results.spherize, 'lambda_reg', lambda_reg);

lam = struct('vol', pStruct.Results.LAMBDA_VOL, 'nonneg', pStruct.Results.LAMBDA_NONNEG, ...
    'eq', pStruct.Results.LAMBDA_EQ, 'sumone', pStruct.Results.LAMBDA_SUMONE, ...
    'enclose', pStruct.Results.LAMBDA_ENCLOSE);

snap_next = 1;   % 下一个待记录节点下标
es_consec = 0;   % 早停连续满足计数
es_stop = false; es_reason = '';

%% --------------------- Warm-up (linear, Q fixed at Q0) ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:WARM_UP
    [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch);
    if full_batch && N > fullBatchChunkSize
        [loss, grad] = compute_gradients_invflow_streamed(theta, Yb, cb, Q0, qm, p, ...
            0, lam.nonneg, lam.eq, lam.sumone, lam.enclose, true, N, fullBatchChunkSize);
    else
        [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
            0, lam.nonneg, lam.eq, lam.sumone, lam.enclose, true, N);
    end
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    [theta, hist, snap_next] = maybe_record(theta, hist, snap_next, iter, ...
        Y_work, coords, Q0, qm, p, lam, N, fullBatchChunkSize, trainStart);
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, WARM_UP, loss);
    end
end

%% --------------------- Joint training (with early stop) ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = MM_ITERS - WARM_UP;
for k = 1:n_joint
    [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch);
    if full_batch && N > fullBatchChunkSize
        [loss, grad] = compute_gradients_invflow_streamed(theta, Yb, cb, Q0, qm, p, ...
            lam.vol, lam.nonneg, lam.eq, lam.sumone, lam.enclose, false, N, fullBatchChunkSize);
    else
        [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
            lam.vol, lam.nonneg, lam.eq, lam.sumone, lam.enclose, false, N);
    end
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    [theta, hist, snap_next] = maybe_record(theta, hist, snap_next, iter, ...
        Y_work, coords, Q0, qm, p, lam, N, fullBatchChunkSize, trainStart);

    % ---- pre-registered early stop (joint phase only; full-data eval, no rng) ----
    if es.enabled && mod(iter, es.evalEvery) == 0
        F = full_objective(theta, Y_work, coords, Q0, qm, p, lam, N, fullBatchChunkSize);
        hist.es.eval_t(end+1) = iter;  %#ok<AGROW>
        hist.es.eval_F(end+1) = F;     %#ok<AGROW>
        % Plateau may trigger only on or before the pre-registered tCap.
        % If no plateau has been confirmed by tCap, do not keep testing later:
        % continue to tHardMax and report cap_reached_no_plateau.
        if iter <= es.tCap
            back = round(es.perSteps / es.evalEvery);
            if numel(hist.es.eval_F) > back
                F0 = hist.es.eval_F(end-back);
                rel = abs(F - F0) / max(abs(F0), eps);
                if rel < es.relTol, es_consec = es_consec + 1; else, es_consec = 0; end
                if es_consec * es.evalEvery >= es.sustainSteps
                    es_stop = true; es_reason = 'plateau_rule';
                end
            end
        end
        if ~es_stop && iter >= es.tCap && ~es.continueToHardMax
            es_stop = true; es_reason = 'cap_reached_no_plateau';
        elseif ~es_stop && iter >= es.tHardMax
            es_stop = true; es_reason = 'cap_reached_no_plateau';
        end
        if es_stop, break; end
    end
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

if es.enabled
    hist.es.stopped = es_stop;
    hist.es.t_stop = iter;
    if es_stop, hist.es.reason = es_reason;
    elseif iter >= MM_ITERS, hist.es.reason = 'completed_T_max';
    else, hist.es.reason = 'rule_not_triggered'; end
end

%% --------------------- Recover endmembers ---------------------
M_est = recover_endmembers_from_theta(theta, ctx);

% The formal E3 runner needs endmembers/objectives, not the full p-by-N
% abundance matrix. Skip it to reduce per-worker memory on N=1e6.
if logical(pStruct.Results.SKIP_ABUNDANCE_OUTPUT)
    Sest = [];
else
    CHUNK = min(N, 50000);
    A_eff = zeros(p, N);
    for i1 = 1:CHUNK:N
        i2 = min(i1+CHUNK-1, N);
        A_eff(:, i1:i2) = abundance_net_forward_nl(coords(:, i1:i2), theta, false);
    end
    Sest = A_eff;
end
end

%% ===================== E3 sub-functions =====================
function [theta, hist, snap_next] = maybe_record(theta, hist, snap_next, iter, ...
    Y_work, coords, Q0, qm, p, lam, N, chunkSize, trainStart)
%MAYBE_RECORD  Snapshot theta + deterministic full-data objective at nodes.
% 不消耗任何随机数（无 rand/randi 调用），保证批序与独立运行逐位一致。
if snap_next <= numel(hist.nodes) && iter == hist.nodes(snap_next)
    hist.theta_snaps{snap_next} = theta;
    hist.fullloss_nodes(snap_next) = full_objective(theta, Y_work, coords, ...
        Q0, qm, p, lam, N, chunkSize);
    hist.node_elapsed_s(snap_next) = toc(trainStart);
    snap_next = snap_next + 1;
end
end

function F = full_objective(theta, Y_work, coords, Q0, qm, p, lam, N, chunkSize)
%FULL_OBJECTIVE  Exact full-data objective evaluated in chunks to bound RAM.
% The scalar is algebraically identical to the unchunked full-batch objective.
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q);

lossReconSum = 0;
lossNonneg = 0;
lossSumone = 0;
lossEnclose = 0;
for i1 = 1:chunkSize:N
    i2 = min(i1 + chunkSize - 1, N);
    idx = i1:i2;
    Yb = Y_work(:,idx);
    cb = coords(:,idx);
    A_eff = abundance_net_forward_nl(cb, theta, false);
    diff = M*A_eff - Yb;
    lossReconSum = lossReconSum + sum(sum(diff.^2,1));
    penalty = min(A_eff,0);
    lossNonneg = lossNonneg + sum(penalty.^2,'all');
    sumA = sum(A_eff,1);
    lossSumone = lossSumone + sum((sumA-1).^2,'all');
    penEnclose = min(Q*Yb,0);
    lossEnclose = lossEnclose + sum(penEnclose.^2,'all');
end
lossRecon = lossReconSum / N;
lossVol = -sum(theta.r_log);
colSums = sum(Q,1);
lossEq = sum((colSums-qm).^2,'all');
F = lossRecon + lam.vol*lossVol + lam.nonneg*lossNonneg + ...
    lam.sumone*lossSumone + lam.eq*lossEq + lam.enclose*lossEnclose;
end

function [loss, grad] = compute_gradients_invflow_streamed(theta, Y_work, coords, ...
    Q0, qm, p, lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, ...
    lambda_enclose, warm_up, N_total, chunkSize)
% Exact full-batch gradient accumulated over chunks, with one Adam update
% after all chunks. This bounds activation memory without changing B=N.
fields = fieldnames(theta);
grad = init_adam(theta);
loss = 0;
for i1 = 1:chunkSize:N_total
    i2 = min(i1 + chunkSize - 1, N_total);
    idx = i1:i2;
    Yb = Y_work(:,idx);
    cb = coords(:,idx);
    nb = numel(idx);
    [lossChunk, gradChunk] = compute_gradients_invflow(theta, Yb, cb, ...
        Q0, qm, p, lambda_vol, lambda_nonneg, lambda_eq, ...
        lambda_sumone, lambda_enclose, warm_up, N_total);
    weight = nb / N_total;
    loss = loss + weight * lossChunk;
    for j = 1:numel(fields)
        f = fields{j};
        grad.(f) = grad.(f) + weight * gradChunk.(f);
    end
end
end

function M_est = recover_endmembers_from_theta(theta, ctx)
%RECOVER_ENDMEMBERS_FROM_THETA  由 theta 快照重建原空间端元（与训练终态一致）。
p = ctx.p;
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * ctx.Q0 * R_mat;
M_sub = inv(Q);
if strcmp(ctx.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = ctx.Up(:,1:p-1)*diag(sqrt(diag(ctx.D+ctx.lambda_reg*eye(p-1))))*M_sub ...
        + repmat(ctx.my,1,p);
else
    M_est = ctx.Up*M_sub;
end
end

%% ===================== Original sub-functions (verbatim) =====================
function [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch)
%NEXT_BATCH  Uniform random mini-batch (with replacement); full batch if B >= N.
if full_batch
    Yb = Y_work; cb = coords;
else
    idx = randi(N, 1, B);
    Yb = Y_work(:, idx); cb = coords(:, idx);
end
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function grad = abundance_net_backward_nl(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; bg2 = sum(dZg2,2); grad.bg2 = bg2;
    dHg2 = theta.Wg2'*dZg2;
    dZg1 = dHg2.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);
end

function [loss, grad] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, warm_up, N_total)
% Y is a BATCH of Nb columns drawn from the full data set of N_total
% samples. Per-sample SUM penalties are scaled by s = N_total/Nb so that
% all stochastic losses/gradients are unbiased estimates of the original
% full-batch versions (s = 1 recovers them exactly).
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

[A_eff, ~, ~, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
s = N_total / Nb;              % unbiased scaling for per-sample SUM penalties

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));         % per-sample MEAN: no rescaling

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

penalty = min(A_eff,0);
loss_nonneg = s * sum(penalty.^2, 'all');                 % scaled

sum_A = sum(A_eff,1);
loss_sumone = s * sum((sum_A-1).^2, 'all');               % scaled

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');   % data-free (q_m precomputed)

QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = s * sum(pen_enclose.^2, 'all');            % scaled

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

dY_hat = 2*diff/Nb;                        % gradient of the batch MEAN
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * s * pen_enclose * Y';                % scaled
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

dA_eff = M' * dY_hat + s * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));               % scaled
grad_net = abundance_net_backward_nl(dA_eff, cache, theta);
grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
