%% DEEPMVSA E3 — CPU PARALLEL / COMPUTATION-REDUCED VERSION
% Based on the uploaded E3 v2 main script and E3 model.
% Section 4.1: noise-free synthetic regular simplices, Dirichlet(1) mixtures.
% DTV: same E2 affine-projection / Monte-Carlo definition.
%
% Main reductions:
%   (1) K=5 at the largest configured N (currently 500,000) omits full-batch GRID and REFERENCE.
%   (2) For each B, one uninterrupted trajectory records all requested T nodes.
%       This is equivalent to independent runs only when initialization, RNG
%       stream, warm-up and objective are identical; this script keeps them fixed.
%   (3) The three FIXED-BT points are also recorded from one continuous B=256 path.
%   (4) REFERENCE is a 6000-step full-batch proxy with an empirical objective-based
%       early-stop heuristic; it is not treated as a convergence certificate.
%   (5) Independent (K,N,repeat) tasks use CPU parfor, up to 8 workers.
%       Worker count is reduced for large N to control RAM use (8/4/2).
%
% IMPORTANT:
%   - CPU only; no GPU code.
%   - The current run output is separated from the original E3 output folder.
%   - A MATLAB Parallel Computing Toolbox license is needed for parfor.
%   - If parallel support is unavailable, the script falls back to serial.
%   - Early stopping is an empirical numerical criterion, not a proof of convergence.

clear; close all; clc;

%% --------------------------- USER SETTINGS ------------------------------
RUN_MODE = 'formal';      % 'formal' or 'smoke'
RESUME = true;

if strcmpi(RUN_MODE,'smoke')
    OUT_DIR = fullfile(pwd,'E3_smoke_CPU_parallel_N500k_K5noFullBatch');
else
    OUT_DIR = fullfile(pwd,'E3_formal_CPU_parallel_optimized_N500k_K5noFullBatch');
end

cfg=struct();
cfg.RUN_MODE=RUN_MODE;
cfg.K_values=[3 5];
cfg.N_values=[10000 100000 500000];
cfg.T_values=[250 500 1500 3000 4500 6000];
cfg.B_small=256;
cfg.B_large=4096;
cfg.nRepeats=10;                 % preserve paired repeat count across N
cfg.refRepeats=3;
cfg.refRestarts=2;
cfg.refT=6000;
cfg.doReference=true;
cfg.doFigureFControl=true;
% Matched B*T points. With B_large/B_small=16, the small-batch path is
% T=[4000 8000 24000]; 24000 is intentional and must not be capped by GRID T.
cfg.F_reference_T_large=[250 500 1500];

% V3 reduction: omit K=5 full-batch GRID and REFERENCE only at the largest N.
% For the current N grid, this means K=5, N=500000.
cfg.DROP_K5_MAXN_FULLBATCH=true;

% REFERENCE early stopping (full-batch objective only).
cfg.REF_EARLY_STOP=true;
cfg.REF_EARLY_STOP_MIN_T=5000;
cfg.REF_EARLY_STOP_PATIENCE=2000;
cfg.REF_EARLY_STOP_TOL=1e-4;
cfg.REF_EARLY_STOP_CHECK_INTERVAL=100;
cfg.REF_EARLY_STOP_CONFIRMATIONS=3;

% CPU parallel policy for this 10-core / 16-logical-processor / 32-GB PC.
cfg.PARALLEL_ENABLED=true;
cfg.PARALLEL_MAX_WORKERS=8;
cfg.PARALLEL_WORKERS_N1E4=8;      % N < 1e5
cfg.PARALLEL_WORKERS_N1E5=8;      % intermediate N below the maximum
cfg.PARALLEL_WORKERS_NMAX=8;      % largest configured N: memory-conservative

% Metric / model settings retained from E3 v2.
cfg.TV_MC_FINAL=100000;
cfg.TV_MC_TRAJ=2000;
cfg.HIDDEN=32;
cfg.LR=3e-4;
cfg.LAMBDA_VOL=0.005;
cfg.LAMBDA_NONNEG=3;
cfg.LAMBDA_EQ=80;
cfg.LAMBDA_SUMONE=2;
cfg.LAMBDA_ENCLOSE=10;
cfg.WARM_POLICY='fixed';
cfg.WARM_FIXED=200;
cfg.DATA_SEED_BASE=31000;
cfg.TRAIN_SEED_BASE=61000;
cfg.TV_SEED_BASE=910000;
cfg.checkpointEvery=1;
cfg.CHECK_CONTINUOUS_EQUIVALENCE=false;
cfg.wall_clock_note=['For continuous GRID/FIXED-BT trajectories, wall_clock_s is cumulative ' ...
    'elapsed time from trajectory start through that T snapshot, including exact full-objective ' ...
    'evaluations at earlier requested snapshots.'];
cfg.reference_note=['REFERENCE is a full-batch target-6000-step comparison proxy, not a verified ' ...
    'near-converged solution or convergence certificate. It may stop when the moving-average ' ...
    'objective change between 100-step windows 2000 updates apart is <=1e-4 for 3 consecutive ' ...
    'checks after at least 5000 updates; actual_T is recorded.'];
cfg.data_note=['Section 4.1 noiseless regular simplex, K+1 vertices, Dirichlet(1); ' ...
    'paired B/T and nested N; E2 affine-projected Monte-Carlo DTV; ' ...
    'continuous T-node trajectories; CPU parfor; K=5 at largest N full-batch GRID/REFERENCE omitted.'];

if strcmpi(RUN_MODE,'smoke')
    cfg.K_values=3;
    cfg.N_values=10000;
    cfg.T_values=[250 500];
    cfg.nRepeats=1;
    cfg.doReference=false;
    cfg.DROP_K5_MAXN_FULLBATCH=false;
    cfg.PARALLEL_ENABLED=false;
    cfg.CHECK_CONTINUOUS_EQUIVALENCE=true;
    cfg.F_reference_T_large=250;
    cfg.TV_MC_FINAL=10000;
    cfg.TV_MC_TRAJ=500;
end

if exist('deep_mvsa_invflow_E3_CPU_parallel','file')~=2
    error('Put deep_mvsa_invflow_E3_CPU_parallel.m in this folder or on the MATLAB path.');
end
if ~exist(OUT_DIR,'dir'), mkdir(OUT_DIR); end
CKPT=fullfile(OUT_DIR,'E3_CPU_parallel_checkpoint.mat');

% Worker count is a runtime setting; it does not change numerical results.
sigCfg=cfg;
runtimeFields={'PARALLEL_ENABLED','PARALLEL_MAX_WORKERS', ...
    'PARALLEL_WORKERS_N1E4','PARALLEL_WORKERS_N1E5', ...
    'PARALLEL_WORKERS_NMAX'};
sigCfg=rmfield(sigCfg,runtimeFields);
signature=jsonencode(sigCfg);

runs=e3_empty_run_records();
refs=e3_empty_ref_records();
if RESUME && exist(CKPT,'file')
    old=load(CKPT,'cfg','runs','refs','signature');
    if ~isfield(old,'signature') || ~strcmp(old.signature,signature)
        error(['Checkpoint signature mismatch. This optimized CPU schedule uses a ' ...
            'separate output folder; do not mix it with the old E3 checkpoint.']);
    end
    runs=old.runs;
    refs=old.refs;
    fprintf('RESUME: %d GRID/FIXED-BT result rows and %d REFERENCE rows loaded.\n', ...
        numel(runs),numel(refs));
end

e3_test_tv_implementation();
e3_test_drop_policy(cfg);
if cfg.CHECK_CONTINUOUS_EQUIVALENCE
    e3_test_continuous_equivalence(cfg);
end
fprintf('\nE3 CPU-optimized run: K=%s, N=%s, T=%s, repeats=%d\n', ...
    mat2str(cfg.K_values),mat2str(cfg.N_values), ...
    mat2str(cfg.T_values),cfg.nRepeats);
fprintf('Output: %s\n',OUT_DIR);
[expectedGridRows,expectedFixedBTRows,expectedReferenceRows]=e3_expected_result_counts(cfg);
fprintf(['Target result rows: GRID=%d, FIXED-BT=%d, REFERENCE=%d; total=%d. ' ...
    'Continuous-path model calls are substantially fewer than result rows.\n'], ...
    expectedGridRows,expectedFixedBTRows,expectedReferenceRows, ...
    expectedGridRows+expectedFixedBTRows+expectedReferenceRows);
fixedBT_T_small=cfg.B_large*cfg.F_reference_T_large/cfg.B_small;
fprintf('Maximum iteration budgets: GRID=%d; FIXED-BT=%d (B=%d); REFERENCE=%d.\n', ...
    max(cfg.T_values),max(fixedBT_T_small),cfg.B_small,cfg.refT);

% Start/resize worker pool per N. Large N uses fewer workers to protect RAM.
for ik=1:numel(cfg.K_values)
    K=cfg.K_values(ik);
    for in=1:numel(cfg.N_values)
        N=cfg.N_values(in);
        repsTodo=[];
        for rep=1:cfg.nRepeats
            if e3_rep_has_pending(K,N,rep,runs,refs,cfg)
                repsTodo(end+1)=rep; %#ok<AGROW>
            end
        end
        if isempty(repsTodo)
            fprintf('Already complete: K=%d N=%d.\n',K,N);
            continue;
        end

        useParallel=false;
        nWorkers=e3_workers_for_N(N,cfg);
        if cfg.PARALLEL_ENABLED
            % Resolve this script by its actual path, including when its filename
            % contains a suffix such as (4). Do not depend on a hard-coded name.
            mainPath=mfilename('fullpath');
            if isempty(mainPath)
                mainFile='';
            else
                [~,~,mainExt]=fileparts(mainPath);
                if isempty(mainExt), mainFile=[mainPath '.m']; else, mainFile=mainPath; end
            end
            if isempty(mainFile) || exist(mainFile,'file')~=2
                mainFile=which(mfilename);
            end
            modelFile=which('deep_mvsa_invflow_E3_CPU_parallel');
            useParallel=e3_prepare_pool(nWorkers,mainFile,modelFile);
        end
        if useParallel
            batchSize=nWorkers;
            fprintf('K=%d N=%d: using %d CPU workers (batch size %d).\n', ...
                K,N,nWorkers,batchSize);
        else
            batchSize=1;
            fprintf('K=%d N=%d: serial execution.\n',K,N);
        end

        for first=1:batchSize:numel(repsTodo)
            batchReps=repsTodo(first:min(first+batchSize-1,numel(repsTodo)));
            nBatch=numel(batchReps);
            taskRunCells=cell(nBatch,1);
            taskRefCells=cell(nBatch,1);
            taskLogCells=cell(nBatch,1);
            runKeyCells=cell(nBatch,1);
            refKeyCells=cell(nBatch,1);
            for ib=1:nBatch
                [runKeyCells{ib},refKeyCells{ib}]= ...
                    e3_existing_keys_for_rep(K,N,batchReps(ib),runs,refs);
            end

            if useParallel
                try
                    parfor ib=1:nBatch
                        [taskRunCells{ib},taskRefCells{ib},taskLogCells{ib}]= ...
                            e3_run_rep_task(K,N,batchReps(ib),cfg, ...
                            runKeyCells{ib},refKeyCells{ib});
                    end
                catch ME
                    warning('E3:ParforBatchFailed', ...
                        'Parallel batch failed (%s). Retrying this batch serially.',ME.message);
                    for ib=1:nBatch
                        [taskRunCells{ib},taskRefCells{ib},taskLogCells{ib}]= ...
                            e3_run_rep_task(K,N,batchReps(ib),cfg, ...
                            runKeyCells{ib},refKeyCells{ib});
                    end
                end
            else
                for ib=1:nBatch
                    [taskRunCells{ib},taskRefCells{ib},taskLogCells{ib}]= ...
                        e3_run_rep_task(K,N,batchReps(ib),cfg, ...
                        runKeyCells{ib},refKeyCells{ib});
                end
            end

            % Only the client process merges records and writes checkpoints.
            for ib=1:nBatch
                newRuns=taskRunCells{ib};
                for j=1:numel(newRuns)
                    if ~e3_has_key(runs,newRuns(j).key)
                        runs(end+1)=newRuns(j); %#ok<SAGROW>
                    end
                end
                newRefs=taskRefCells{ib};
                for j=1:numel(newRefs)
                    if ~e3_has_key(refs,newRefs(j).key)
                        refs(end+1)=newRefs(j); %#ok<SAGROW>
                    end
                end
                logs=taskLogCells{ib};
                for j=1:numel(logs)
                    fprintf('%s\n',logs{j});
                end
                fprintf('Finished K=%d N=%d rep=%d: +%d run rows, +%d reference rows.\n', ...
                    K,N,batchReps(ib),numel(newRuns),numel(newRefs));
            end
            e3_save_ckpt(CKPT,cfg,runs,refs,signature);
        end
    end
end

% Close the pool to release memory before summary/plotting.
if exist('gcp','file')==2
    pool=gcp('nocreate');
    if ~isempty(pool), delete(pool); end
end

e3_save_ckpt(CKPT,cfg,runs,refs,signature);

%% ---------------------------- ANALYSIS ----------------------------------
runTable=e3_run_table(runs);
refTable=e3_ref_table(refs);
[runTable,configTable,plateauTable,slopeTable]= ...
    e3_summaries(runTable,refTable,cfg);

writetable(runTable,fullfile(OUT_DIR,'E3_run_summary.csv'));
writetable(configTable,fullfile(OUT_DIR,'E3_config_summary.csv'));
if ~isempty(refTable), writetable(refTable,fullfile(OUT_DIR,'E3_reference_summary.csv')); end
if ~isempty(plateauTable), writetable(plateauTable,fullfile(OUT_DIR,'E3_plateau_summary.csv')); end
if ~isempty(slopeTable), writetable(slopeTable,fullfile(OUT_DIR,'E3_slope_summary.csv')); end

save(fullfile(OUT_DIR,'E3_formal_results.mat'), ...
    'cfg','runs','refs','runTable','configTable','refTable', ...
    'plateauTable','slopeTable','signature','-v7.3');
e3_plot_figures(runTable,plateauTable,slopeTable,cfg,OUT_DIR);

fprintf('\nE3 completed: %d GRID/FIXED-BT result rows, %d REFERENCE rows.\n', ...
    numel(runs),numel(refs));
fprintf('MAT/CSV/PNG/SVG saved in %s\n',OUT_DIR);

%% ============================ LOCAL FUNCTIONS ===========================
function [Y,M_true] = e3_make_noiseless_data(K,N,seed)
% p orthonormal vertices form a regular K-simplex in a p=K+1 ambient space.
% Its intrinsic simplex dimension is K, not p. An orthogonal embedding is an
% isometry and preserves volumes' ratios, barycentric coordinates and TV.
% This fixes the K-versus-vertex-count mismatch in the reduced Python demo.
rng(seed,'twister');
p=K+1;
[Q,R]=qr(randn(p,p));
s=sign(diag(R)); s(s==0)=1;
M_true=Q*diag(s);
A=-log(max(rand(p,N),realmin));
A=A./sum(A,1);               % Dirichlet(1,...,1)
Y=M_true*A;                  % strict noise-free linear mixtures
end

function tf=e3_has_key(records,key)
if isempty(records), tf=false; return; end
tf=any(strcmp({records.key},key));
end

function warmup=e3_warmup(T,cfg)
if strcmpi(cfg.WARM_POLICY,'python_demo')
    warmup=max(50,min(200,floor(T/5)));  % copied from demo_E3.py
elseif strcmpi(cfg.WARM_POLICY,'fixed')
    warmup=min(cfg.WARM_FIXED,T-1);
else
    error('Unknown WARM_POLICY.');
end
assert(warmup>=0 && warmup<T,'warmup must be less than T.');
end

function records=e3_train_schedule(Y,M_true,K,N,B,T_nodes,rep, ...
    dataSeed,trainSeed,tvSeed,kind,cfg)
% One uninterrupted Adam trajectory; exact snapshots are returned at T_nodes.
T_nodes=sort(unique(T_nodes(:)'));
if isempty(T_nodes), records=e3_empty_run_records(); return; end
Tmax=max(T_nodes);
warmup=e3_warmup(Tmax,cfg);
[~,~,Up,~,~,hist,~,snapshots] = deep_mvsa_invflow_E3_CPU_parallel(Y,K+1, ...
    'MM_ITERS',Tmax,'WARM_UP',warmup,'LR',cfg.LR, ...
    'LAMBDA_VOL',cfg.LAMBDA_VOL,'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
    'LAMBDA_EQ',cfg.LAMBDA_EQ,'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
    'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE,'BATCH_SIZE',B, ...
    'SEED',trainSeed,'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
    'spherize','yes','verbose',0,'E1_MTRUE',M_true, ...
    'E1_MONITOR_INTERVAL',0,'E1_TV_MC',cfg.TV_MC_TRAJ, ...
    'E1_TV_SEED',tvSeed,'E3_SNAPSHOT_STEPS',T_nodes, ...
    'E3_EARLY_STOP_ENABLE',false,'E3_SKIP_ABUNDANCE_OUTPUT',true);
if numel(snapshots)~=numel(T_nodes)
    error('E3 schedule did not return all requested snapshots (kind=%s,K=%d,N=%d,B=%d).', ...
        kind,K,N,B);
end
records=e3_empty_run_records();
M_true_proj=Up'*M_true;
for j=1:numel(T_nodes)
    snap=snapshots(j);
    T=snap.iteration;
    M_est_proj=snap.M_est_proj;
    M_est=Up*M_est_proj;
    [DTV,volTrue,volEst]=e3_tv_dist_simplex( ...
        M_true_proj,M_est_proj,cfg.TV_MC_FINAL,tvSeed);
    if ~isfinite(DTV)
        warning('E3:DegenerateSimplex','DTV NaN for K=%d N=%d B=%d T=%d.',K,N,B,T);
    end
    L=snap.full_loss;
    histRecord=hist;
    histRecord.record_T=T;
    histRecord.trajectory_max_T=max(T_nodes);
    histRecord.wall_clock_semantics=cfg.wall_clock_note;
    rec=struct('key',sprintf('%s_K%d_N%d_B%d_T%d_R%d',upper(kind),K,N,B,T,rep), ...
        'kind',kind,'K',K,'p',K+1,'N',N,'B',B,'T',T, ...
        'BT',double(B)*double(T),'repeat',rep, ...
        'data_seed',dataSeed,'train_seed',trainSeed,'tv_seed',tvSeed, ...
        'warmup',e3_warmup(T,cfg),'DTV',DTV,'vol_true',volTrue,'vol_est',volEst, ...
        'wall_clock_s',snap.elapsed_s,'loss_total',L.total, ...
        'loss_recon',L.recon,'loss_vol',L.vol,'loss_nonneg',L.nonneg, ...
        'loss_sumone',L.sumone,'loss_eq',L.eq,'loss_enclose',L.enclose, ...
        'M_true',M_true,'M_est',M_est,'M_true_proj',M_true_proj, ...
        'M_est_proj',M_est_proj,'Up_projection',Up,'history',histRecord);
    records(end+1)=rec; %#ok<AGROW>
end
end

function [rec,elapsed]=e3_train_one(Y,M_true,K,N,B,T,rep, ...
    dataSeed,trainSeed,tvSeed,key,kind,cfg)
% Independent full-batch reference run; may stop after the configured
% empirical full-batch objective plateau criterion is met.
p=K+1; warmup=e3_warmup(T,cfg);
earlyEnable=strcmpi(kind,'reference') && cfg.REF_EARLY_STOP;
t0=tic;
[M_est,~,Up,~,~,hist,loss] = deep_mvsa_invflow_E3_CPU_parallel(Y,p, ...
    'MM_ITERS',T,'WARM_UP',warmup,'LR',cfg.LR, ...
    'LAMBDA_VOL',cfg.LAMBDA_VOL,'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
    'LAMBDA_EQ',cfg.LAMBDA_EQ,'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
    'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE,'BATCH_SIZE',B, ...
    'SEED',trainSeed,'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
    'spherize','yes','verbose',0,'E1_MTRUE',M_true, ...
    'E1_MONITOR_INTERVAL',0,'E1_TV_MC',cfg.TV_MC_TRAJ,'E1_TV_SEED',tvSeed, ...
    'E3_EARLY_STOP_ENABLE',earlyEnable, ...
    'E3_EARLY_STOP_MIN_ITERS',cfg.REF_EARLY_STOP_MIN_T, ...
    'E3_EARLY_STOP_PATIENCE',cfg.REF_EARLY_STOP_PATIENCE, ...
    'E3_EARLY_STOP_TOL',cfg.REF_EARLY_STOP_TOL, ...
    'E3_EARLY_STOP_CHECK_INTERVAL',cfg.REF_EARLY_STOP_CHECK_INTERVAL, ...
    'E3_EARLY_STOP_CONFIRMATIONS',cfg.REF_EARLY_STOP_CONFIRMATIONS, ...
    'E3_SKIP_ABUNDANCE_OUTPUT',true);
elapsed=toc(t0);
actualT=hist.total_iterations;
M_true_proj=Up'*M_true;
M_est_proj=Up'*M_est;
[DTV,volTrue,volEst]=e3_tv_dist_simplex( ...
    M_true_proj,M_est_proj,cfg.TV_MC_FINAL,tvSeed);
if ~isfinite(DTV)
    warning('E3:DegenerateSimplex','DTV NaN for %s; inspect M_est.',key);
end
rec=struct('key',key,'kind',kind,'K',K,'p',p,'N',N,'B',B,'T',actualT, ...
    'BT',double(B)*double(actualT),'repeat',rep, ...
    'data_seed',dataSeed,'train_seed',trainSeed,'tv_seed',tvSeed, ...
    'warmup',warmup,'DTV',DTV,'vol_true',volTrue,'vol_est',volEst, ...
    'wall_clock_s',elapsed,'loss_total',loss.total, ...
    'loss_recon',loss.recon,'loss_vol',loss.vol, ...
    'loss_nonneg',loss.nonneg,'loss_sumone',loss.sumone, ...
    'loss_eq',loss.eq,'loss_enclose',loss.enclose, ...
    'M_true',M_true,'M_est',M_est, ...
    'M_true_proj',M_true_proj,'M_est_proj',M_est_proj, ...
    'Up_projection',Up,'history',hist);
end

function [taskRuns,taskRefs,logLines]=e3_run_rep_task(K,N,rep,cfg,existingRunKeys,existingRefKeys)
% A task owns one independent synthetic dataset and all its B/T schedules.
% Workers never write shared checkpoint files; the client merges results.
taskRuns=e3_empty_run_records();
taskRefs=e3_empty_ref_records();
logLines={};
dataSeed=cfg.DATA_SEED_BASE+10000*K+rep;
[Y,M_true]=e3_make_noiseless_data(K,N,dataSeed);
trainSeed0=cfg.TRAIN_SEED_BASE+100000*K+1000*rep;
tvSeed=cfg.TV_SEED_BASE+1000*K+rep;

B_grid=e3_grid_Bs(K,N,cfg);
for ib=1:numel(B_grid)
    B=B_grid(ib);
    todoT=[];
    for it=1:numel(cfg.T_values)
        T=cfg.T_values(it);
        key=sprintf('GRID_K%d_N%d_B%d_T%d_R%d',K,N,B,T,rep);
        if ~any(strcmp(existingRunKeys,key))
            todoT(end+1)=T; %#ok<AGROW>
        end
    end
    if ~isempty(todoT)
        newRecords=e3_train_schedule(Y,M_true,K,N,B,todoT,rep, ...
            dataSeed,trainSeed0,tvSeed,'grid',cfg);
        taskRuns=[taskRuns,newRecords]; %#ok<AGROW>
        for j=1:numel(newRecords)
            r=newRecords(j);
            logLines{end+1}=sprintf('GRID | K=%d N=%d B=%d T=%d rep=%d TV=%.5f %6.1fs', ...
                K,N,B,r.T,rep,r.DTV,r.wall_clock_s); %#ok<AGROW>
        end
    end
end

if cfg.doFigureFControl
    Tsmall=cfg.B_large*cfg.F_reference_T_large/cfg.B_small;
    if any(abs(Tsmall-round(Tsmall))>1e-10)
        error('Figure F requires integer small-batch iteration counts.');
    end
    Tsmall=round(Tsmall);
    todoT=[];
    for it=1:numel(Tsmall)
        T=Tsmall(it);
        key=sprintf('FIXEDBT_K%d_N%d_B%d_T%d_R%d',K,N,cfg.B_small,T,rep);
        if ~any(strcmp(existingRunKeys,key))
            todoT(end+1)=T; %#ok<AGROW>
        end
    end
    if ~isempty(todoT)
        newRecords=e3_train_schedule(Y,M_true,K,N,cfg.B_small,todoT,rep, ...
            dataSeed,trainSeed0,tvSeed,'fixedBT',cfg);
        taskRuns=[taskRuns,newRecords]; %#ok<AGROW>
        for j=1:numel(newRecords)
            r=newRecords(j);
            logLines{end+1}=sprintf('FIXED-BT | K=%d N=%d B=%d T=%d rep=%d TV=%.5f %6.1fs', ...
                K,N,r.B,r.T,rep,r.DTV,r.wall_clock_s); %#ok<AGROW>
        end
    end
end

doRef=e3_reference_enabled(K,N,cfg) && rep<=cfg.refRepeats;
if doRef
    for rs=1:cfg.refRestarts
        key=sprintf('REF_K%d_N%d_R%d_RS%d',K,N,rep,rs);
        if any(strcmp(existingRefKeys,key)), continue; end
        trainSeed=trainSeed0+10000*rs;
        [rec,elapsed]=e3_train_one(Y,M_true,K,N,N,cfg.refT,rep, ...
            dataSeed,trainSeed,tvSeed,key,'reference',cfg);
        newRef=struct('key',key,'K',K,'N',N,'repeat',rep, ...
            'restart',rs,'B',N,'T',rec.T,'target_T',cfg.refT, ...
            'early_stopped',logical(rec.history.early_stop_triggered), ...
            'early_stop_iteration',rec.history.early_stop_iteration, ...
            'early_stop_relative_change',rec.history.early_stop_relative_change, ...
            'data_seed',dataSeed,'train_seed',trainSeed,'DTV',rec.DTV, ...
            'loss_total',rec.loss_total,'vol_true',rec.vol_true, ...
            'vol_est',rec.vol_est,'wall_clock_s',elapsed, ...
            'M_true_proj',rec.M_true_proj,'M_est_proj',rec.M_est_proj);
        taskRefs(end+1)=newRef; %#ok<AGROW>
        logLines{end+1}=sprintf('REFERENCE | K=%d N=%d rep=%d restart=%d actualT=%d TV=%.5f loss=%.5g %6.1fs', ...
            K,N,rep,rs,rec.T,rec.DTV,rec.loss_total,elapsed); %#ok<AGROW>
    end
end
clear Y M_true;
end

function B_grid=e3_grid_Bs(K,N,cfg)
if K==3
    B_grid=unique([cfg.B_small cfg.B_large N],'stable');
elseif K==5
    if cfg.DROP_K5_MAXN_FULLBATCH && N==max(cfg.N_values)
        % Keep the large mini-batch, but omit B=N at the largest N.
        B_grid=unique(cfg.B_large,'stable');
    else
        B_grid=unique([cfg.B_large N],'stable');
    end
else
    B_grid=unique([cfg.B_large N],'stable');
end
end

function tf=e3_reference_enabled(K,N,cfg)
% Use the same omission rule for REFERENCE as for full-batch GRID.
tf=cfg.doReference && ...
    ~(cfg.DROP_K5_MAXN_FULLBATCH && K==5 && N==max(cfg.N_values));
end

function e3_test_drop_policy(cfg)
% Verify that the K=5 largest-N full-batch omission is active.
if ~cfg.DROP_K5_MAXN_FULLBATCH || ~any(cfg.K_values==5) || numel(cfg.N_values)<2
    return;
end
maxN=max(cfg.N_values);
Bmax=e3_grid_Bs(5,maxN,cfg);
if any(Bmax>=maxN)
    error('K=5 largest-N full-batch GRID omission failed.');
end
if e3_reference_enabled(5,maxN,cfg)
    error('K=5 largest-N full-batch REFERENCE omission failed.');
end
lowerN=max(cfg.N_values(cfg.N_values<maxN));
if ~any(e3_grid_Bs(5,lowerN,cfg)==lowerN) || ~e3_reference_enabled(5,lowerN,cfg)
    error('K=5 full-batch GRID/REFERENCE was omitted at a non-maximum N.');
end
fprintf('K=5 largest-N full-batch omission policy passed (N=%d).\n',maxN);
end

function [nGrid,nFixedBT,nRef]=e3_expected_result_counts(cfg)
% Count planned result rows from the active configuration, not stale literals.
nGrid=0; nFixedBT=0; nRef=0;
for k=cfg.K_values
    for n=cfg.N_values
        nGrid=nGrid+numel(e3_grid_Bs(k,n,cfg))*numel(cfg.T_values)*cfg.nRepeats;
        if cfg.doFigureFControl
            tSmall=cfg.B_large*cfg.F_reference_T_large/cfg.B_small;
            if any(abs(tSmall-round(tSmall))>1e-10)
                error('Figure F requires integer small-batch iteration counts.');
            end
            nFixedBT=nFixedBT+numel(unique(round(tSmall)))*cfg.nRepeats;
        end
        if e3_reference_enabled(k,n,cfg)
            nRef=nRef+min(cfg.refRepeats,cfg.nRepeats)*cfg.refRestarts;
        end
    end
end
end

function tf=e3_rep_has_pending(K,N,rep,runs,refs,cfg)
tf=false;
runKeys={runs.key}; refKeys={refs.key};
for B=e3_grid_Bs(K,N,cfg)
    for T=cfg.T_values
        key=sprintf('GRID_K%d_N%d_B%d_T%d_R%d',K,N,B,T,rep);
        if ~any(strcmp(runKeys,key)), tf=true; return; end
    end
end
if cfg.doFigureFControl
    Tsmall=round(cfg.B_large*cfg.F_reference_T_large/cfg.B_small);
    for T=Tsmall
        key=sprintf('FIXEDBT_K%d_N%d_B%d_T%d_R%d',K,N,cfg.B_small,T,rep);
        if ~any(strcmp(runKeys,key)), tf=true; return; end
    end
end
doRef=e3_reference_enabled(K,N,cfg) && rep<=cfg.refRepeats;
if doRef
    for rs=1:cfg.refRestarts
        key=sprintf('REF_K%d_N%d_R%d_RS%d',K,N,rep,rs);
        if ~any(strcmp(refKeys,key)), tf=true; return; end
    end
end
end

function [runKeys,refKeys]=e3_existing_keys_for_rep(K,N,rep,runs,refs)
runMask=false(1,numel(runs));
for i=1:numel(runs)
    runMask(i)=runs(i).K==K && runs(i).N==N && runs(i).repeat==rep;
end
refMask=false(1,numel(refs));
for i=1:numel(refs)
    refMask(i)=refs(i).K==K && refs(i).N==N && refs(i).repeat==rep;
end
runKeys={runs(runMask).key};
refKeys={refs(refMask).key};
end

function r=e3_empty_run_records()
r=struct('key',{},'kind',{},'K',{},'p',{},'N',{},'B',{},'T',{}, ...
    'BT',{},'repeat',{},'data_seed',{},'train_seed',{},'tv_seed',{}, ...
    'warmup',{},'DTV',{},'vol_true',{},'vol_est',{},'wall_clock_s',{}, ...
    'loss_total',{},'loss_recon',{},'loss_vol',{},'loss_nonneg',{}, ...
    'loss_sumone',{},'loss_eq',{},'loss_enclose',{}, ...
    'M_true',{},'M_est',{},'M_true_proj',{},'M_est_proj',{}, ...
    'Up_projection',{},'history',{});
end

function r=e3_empty_ref_records()
r=struct('key',{},'K',{},'N',{},'repeat',{},'restart',{}, ...
    'B',{},'T',{},'target_T',{},'early_stopped',{}, ...
    'early_stop_iteration',{},'early_stop_relative_change',{}, ...
    'data_seed',{},'train_seed',{},'DTV',{},'loss_total',{}, ...
    'vol_true',{},'vol_est',{},'wall_clock_s',{}, ...
    'M_true_proj',{},'M_est_proj',{});
end

function nWorkers=e3_workers_for_N(N,cfg)
if N>=max(cfg.N_values)
    nWorkers=min(cfg.PARALLEL_MAX_WORKERS,cfg.PARALLEL_WORKERS_NMAX);
elseif N>=100000
    nWorkers=min(cfg.PARALLEL_MAX_WORKERS,cfg.PARALLEL_WORKERS_N1E5);
else
    nWorkers=min(cfg.PARALLEL_MAX_WORKERS,cfg.PARALLEL_WORKERS_N1E4);
end
nWorkers=max(1,round(nWorkers));
end

function ok=e3_prepare_pool(nWorkers,mainFile,modelFile)
ok=false;
try
    if ~license('test','Distrib_Computing_Toolbox') || exist('parpool','file')~=2
        return;
    end
    pool=gcp('nocreate');
    if ~isempty(pool) && pool.NumWorkers~=nWorkers
        delete(pool);
        pool=[];
    end
    if isempty(pool)
        pool=parpool('local',nWorkers);
    end
    attachList={};
    if exist(mainFile,'file')==2, attachList{end+1}=mainFile; end
    if exist(modelFile,'file')==2, attachList{end+1}=modelFile; end
    if ~isempty(attachList), addAttachedFiles(pool,attachList); end
    ok=true;
catch ME
    warning('E3:ParallelUnavailable', ...
        'Could not start %d workers (%s). This batch will run serially.', ...
        nWorkers,ME.message);
end
end

function [DTV,volT,volE]=e3_tv_dist_simplex(M_T,M_E,nMC,seed)
% Exact same formula, geometry and membership tolerance as supplied E2:
% DTV = 1 - Vol(S_true INTERSECT S_est)/max(Vol(S_true),Vol(S_est)).
% Paired MC points via identical random seed in every arm of each repeat.
rng(seed,'twister');
p=size(M_T,2); K=p-1;
assert(size(M_E,2)==p && size(M_T,1)==size(M_E,1), ...
    'Simplex matrices must have equal size.');
ET=M_T(:,2:p)-repmat(M_T(:,1),1,K);
EE=M_E(:,2:p)-repmat(M_E(:,1),1,K);
volT=sqrt(max(det(ET'*ET),0))/factorial(K);
volE=sqrt(max(det(EE'*EE),0))/factorial(K);
if ~(isfinite(volT) && isfinite(volE) && volT>0 && volE>0)
    DTV=NaN; return;
end
G=-log(max(rand(p,nMC),realmin));
a=G./sum(G,1);
rT=mean(e3_inside(M_T*a,M_E));
G=-log(max(rand(p,nMC),realmin));
a=G./sum(G,1);
rE=mean(e3_inside(M_E*a,M_T));
intersection=0.5*(rT*volT+rE*volE);
DTV=max(1-intersection/max(volT,volE),0);
end

function inside=e3_inside(X,M)
% E2's barycentric-coordinate membership test.
tol=1e-8;
p=size(M,2);
m0=M(:,1);
E=M(:,2:end)-repmat(m0,1,p-1);
C=E\(X-repmat(m0,1,size(X,2)));
inside=all(C>=-tol,1)&(1-sum(C,1)>=-tol);
end

function e3_test_continuous_equivalence(cfg)
% Smoke-only verification: continuous snapshots should match independent
% runs with the same data/training seed, fixed warm-up and objective.
K=3; N=3000; B=256; Tnodes=[250 500];
[Y,M_true]=e3_make_noiseless_data(K,N,47321);
seed=82461; tvSeed=93451; warmup=cfg.WARM_FIXED;
[~,~,Up,~,~,~,~,snaps]=deep_mvsa_invflow_E3_CPU_parallel(Y,K+1, ...
    'MM_ITERS',max(Tnodes),'WARM_UP',warmup,'LR',cfg.LR, ...
    'LAMBDA_VOL',cfg.LAMBDA_VOL,'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
    'LAMBDA_EQ',cfg.LAMBDA_EQ,'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
    'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE,'BATCH_SIZE',B, ...
    'SEED',seed,'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
    'spherize','yes','verbose',0,'E1_MTRUE',[], ...
    'E1_MONITOR_INTERVAL',0,'E1_TV_MC',cfg.TV_MC_TRAJ, ...
    'E1_TV_SEED',tvSeed,'E3_SNAPSHOT_STEPS',Tnodes, ...
    'E3_EARLY_STOP_ENABLE',false,'E3_SKIP_ABUNDANCE_OUTPUT',true);
for j=1:numel(Tnodes)
    [Mi,~,Ui]=deep_mvsa_invflow_E3_CPU_parallel(Y,K+1, ...
        'MM_ITERS',Tnodes(j),'WARM_UP',warmup,'LR',cfg.LR, ...
        'LAMBDA_VOL',cfg.LAMBDA_VOL,'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
        'LAMBDA_EQ',cfg.LAMBDA_EQ,'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
        'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE,'BATCH_SIZE',B, ...
        'SEED',seed,'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
        'spherize','yes','verbose',0,'E1_MTRUE',[], ...
        'E1_MONITOR_INTERVAL',0,'E1_TV_MC',cfg.TV_MC_TRAJ, ...
        'E1_TV_SEED',tvSeed,'E3_EARLY_STOP_ENABLE',false, ...
        'E3_SKIP_ABUNDANCE_OUTPUT',true);
    M_independent=Ui'*Mi;
    relerr=norm(snaps(j).M_est_proj-M_independent,'fro') / ...
        max(norm(M_independent,'fro'),1);
    fprintf('Continuous snapshot check T=%d: relative vertex error %.3g\n', ...
        Tnodes(j),relerr);
    if relerr>1e-7
        error('Continuous trajectory differs from independent T=%d run.',Tnodes(j));
    end
end
fprintf('Continuous-training equivalence check passed.\n');
end

function e3_test_tv_implementation()
% Self-test the estimator using nested regular simplices. Exact TV is
% 1-scale^K; allows MC finite-sample tolerance when 1e5 draws are used.
M=eye(4); center=mean(M,2); Msmall=center+0.5*(M-center);
[v0,~,~]=e3_tv_dist_simplex(M,M,2000,1234);
[v1,~,~]=e3_tv_dist_simplex(M,Msmall,10000,1234);
if abs(v0)>0.02 || abs(v1-(1-0.5^3))>0.04
    error('E3 TV self-test failed: identity=%g, nested=%g (expected 0.875).',v0,v1);
end
end

function e3_save_ckpt(path,cfg,runs,refs,signature)
save(path,'cfg','runs','refs','signature','-v7.3');
end

function T=e3_run_table(r)
if isempty(r), T=table(); return; end
n=numel(r);
kind=strings(n,1); K=zeros(n,1); N=K; B=K; steps=K; BT=K;
rep=K; dseed=K; tseed=K; tvseed=K; warmup=K; tv=K;
vt=K; ve=K; sec=K; total=K; rec=K; vol=K;
nonneg=K; sumone=K; eq=K; enc=K;
for i=1:n
    x=r(i); kind(i)=string(x.kind);
    K(i)=x.K;N(i)=x.N;B(i)=x.B;steps(i)=x.T;BT(i)=x.BT;
    rep(i)=x.repeat;dseed(i)=x.data_seed;
    tseed(i)=x.train_seed;tvseed(i)=x.tv_seed;warmup(i)=x.warmup;
    tv(i)=x.DTV;vt(i)=x.vol_true;ve(i)=x.vol_est;
    sec(i)=x.wall_clock_s;total(i)=x.loss_total;
    rec(i)=x.loss_recon;vol(i)=x.loss_vol;nonneg(i)=x.loss_nonneg;
    sumone(i)=x.loss_sumone;eq(i)=x.loss_eq;enc(i)=x.loss_enclose;
end
T=table(kind,K,N,B,steps,BT,rep,dseed,tseed,tvseed,warmup, ...
    tv,vt,ve,sec,total,rec,vol,nonneg,sumone,eq,enc, ...
    'VariableNames',{'kind','K','N','B','T','BT','repeat', ...
    'data_seed','train_seed','tv_seed','warmup', ...
    'DTV','vol_true','vol_est','wall_clock_s','loss_total', ...
    'loss_recon','loss_vol','loss_nonneg','loss_sumone', ...
    'loss_eq','loss_enclose'});
end

function T=e3_ref_table(r)
if isempty(r), T=table(); return; end
n=numel(r);
K=zeros(n,1);N=K;rep=K;restart=K;B=K;Tactual=K;Ttarget=K;
early=false(n,1);stopIter=nan(n,1);stopRel=nan(n,1);
dseed=K;tseed=K;tv=K;obj=K;sec=K;
for i=1:n
    x=r(i);K(i)=x.K;N(i)=x.N;rep(i)=x.repeat;
    restart(i)=x.restart;B(i)=x.B;Tactual(i)=x.T;Ttarget(i)=x.target_T;
    early(i)=x.early_stopped;stopIter(i)=x.early_stop_iteration;
    stopRel(i)=x.early_stop_relative_change;dseed(i)=x.data_seed;
    tseed(i)=x.train_seed;tv(i)=x.DTV;
    obj(i)=x.loss_total;sec(i)=x.wall_clock_s;
end
T=table(K,N,rep,restart,B,Ttarget,Tactual,early,stopIter,stopRel, ...
    dseed,tseed,tv,obj,sec,...
    'VariableNames',{'K','N','repeat','restart','B','target_T','actual_T', ...
    'early_stopped','early_stop_iteration','early_stop_relative_change', ...
    'data_seed','train_seed','DTV','loss_total','wall_clock_s'});
end

function [R,C,P,S]=e3_summaries(R,Ref,cfg)
% eta_opt is a full-objective gap to the best saved long full-batch proxy.
% Negative gaps are retained (NOT silently clamped to zero): this proxy is
% not a certified optimum and may be worse than a grid run.
if isempty(R), C=table(); P=table(); S=table(); return; end
R.eta_opt_proxy=nan(height(R),1);
R.refbest_loss=nan(height(R),1);
R.refbest_tv=nan(height(R),1);
P=table('Size',[0 6], ...
    'VariableTypes',repmat({'double'},1,6), ...
    'VariableNames',{'K','N','repeat','plateau_DTV','refbest_loss','n_restarts'});
S=table('Size',[0 6], ...
    'VariableTypes',repmat({'double'},1,6), ...
    'VariableNames',{'K','n_slopes','slope_mean','slope_sd', ...
    'slope_CI95_half','reference_slope'});
if ~isempty(Ref)
    for i=1:height(R)
        f=Ref.K==R.K(i)&Ref.N==R.N(i)&Ref.repeat==R.repeat(i);
        if any(f)
            ref=Ref(f,:);
            [best,id]=min(ref.loss_total);
            R.refbest_loss(i)=best;
            R.refbest_tv(i)=ref.DTV(id);
            R.eta_opt_proxy(i)=R.loss_total(i)-best;
        end
    end
end

% Mean, std and approximate normal 95% CI half-width by configuration.
C=table('Size',[0 14], ...
    'VariableTypes',[{'string'},repmat({'double'},1,13)], ...
    'VariableNames',{'kind','K','N','B','T','BT', ...
    'n_repeats','DTV_mean','DTV_sd','DTV_CI95_half', ...
    'time_mean_s','time_sd_s','loss_mean','eta_opt_proxy_mean'});
for k=cfg.K_values
    for n=cfg.N_values
        f=(R.K==k)&(R.N==n);
        kinds=unique(R.kind(f));
        for iKind=1:numel(kinds)
            typ=kinds(iKind);
            Bs=unique(R.B(f&R.kind==typ));
            for b=Bs'
                Ts=unique(R.T(f&R.kind==typ&R.B==b));
                for t=Ts'
                    rr=R(f&R.kind==typ&R.B==b&R.T==t,:);
                    good=isfinite(rr.DTV);
                    vals=rr.DTV(good); nrep=numel(vals);
                    if nrep<1, continue; end
                    new=table(typ,k,n,b,t,double(b)*double(t),nrep, ...
                        mean(vals),std(vals),1.96*std(vals)/sqrt(nrep), ...
                        mean(rr.wall_clock_s),std(rr.wall_clock_s), ...
                        mean(rr.loss_total,'omitnan'), ...
                        mean(rr.eta_opt_proxy,'omitnan'), ...
                        'VariableNames',{'kind','K','N','B','T','BT', ...
                        'n_repeats','DTV_mean','DTV_sd','DTV_CI95_half', ...
                        'time_mean_s','time_sd_s','loss_mean', ...
                        'eta_opt_proxy_mean'});
                    C=[C;new]; %#ok<AGROW>
                end
            end
        end
    end
end

% Per-dataset near-converged reference = minimum exact full objective
% across cfg.refRestarts restarts; save its TV separately from its objective value.
% If no reference run exists, do not invent a statistical plateau.
if isempty(Ref), return; end
for k=cfg.K_values
    for n=cfg.N_values
        repvals=unique(Ref.repeat(Ref.K==k&Ref.N==n));
        for rep=repvals'
            rr=Ref(Ref.K==k&Ref.N==n&Ref.repeat==rep,:);
            if isempty(rr), continue; end
            [best,j]=min(rr.loss_total);
            new=table(k,n,rep,rr.DTV(j),best,height(rr), ...
                'VariableNames',{'K','N','repeat','plateau_DTV', ...
                'refbest_loss','n_restarts'});
            P=[P;new]; %#ok<AGROW>
        end
    end
end

% CI over independent repeat-wise log-log slopes (requires >= 3 N values).
% This prevents a 2-point fit being misleadingly presented with a CI.
for k=cfg.K_values
    rr=P(P.K==k,:);
    repvals=unique(rr.repeat);
    slopes=[];
    for rep=repvals'
        r=rr(rr.repeat==rep & isfinite(rr.plateau_DTV) & ...
            rr.plateau_DTV>0,:);
        [ns,ord]=sort(r.N);
        if numel(unique(ns))<3, continue; end
        vals=r.plateau_DTV(ord);
        coefs=polyfit(log(double(ns)),log(double(vals)),1);
        slopes(end+1,1)=coefs(1); %#ok<AGROW>
    end
    if isempty(slopes), continue; end
    ns=numel(slopes); smean=mean(slopes); ssd=std(slopes);
    new=table(k,ns,smean,ssd,1.96*ssd/sqrt(ns),-0.5, ...
        'VariableNames',{'K','n_slopes','slope_mean','slope_sd', ...
        'slope_CI95_half','reference_slope'});
    S=[S;new]; %#ok<AGROW>
end
end

function e3_plot_figures(R,P,S,cfg,outDir)
if isempty(R), return; end
C=lines(max(3,numel(cfg.N_values)));
for k=cfg.K_values
    f=figure('Color','w','Position',[60 60 1050 720]);
    hold on;
    styles={'-o','--s',':^'};
    handles=gobjects(0);labels={};
    for ni=1:numel(cfg.N_values)
        n=cfg.N_values(ni);
        Bs=unique(R.B(R.K==k&R.N==n&R.kind=="grid"));
        for ib=1:numel(Bs)
            b=Bs(ib);
            r=R(R.K==k&R.N==n&R.B==b&R.kind=="grid",:);
            if isempty(r), continue; end
            ts=unique(r.T);x=zeros(size(ts));y=x;
            for j=1:numel(ts)
                sel=r.DTV(r.T==ts(j));
                x(j)=double(b)*double(ts(j));
                y(j)=mean(sel,'omitnan');
            end
            [x,ord]=sort(x);y=y(ord);
            h=plot(x,max(y,realmin),styles{min(ib,3)},'Color',C(ni,:), ...
                'LineWidth',1.35,'MarkerSize',5);
            handles=[handles,h]; %#ok<AGROW>
            if b==n, bLabel='full';else,bLabel=num2str(b);end
            labels{end+1}=sprintf('N=%g, B=%s',n,bLabel); %#ok<AGROW>
        end
    end
    set(gca,'XScale','log','YScale','log'); grid on;box on;
    xlabel('Presented samples B x T');
    ylabel('D_{TV} (E2 / Table-2 definition)');
    title(sprintf('E3 Figure E: K=%d, noiseless synthetic simplex',k));
    if ~isempty(handles),legend(handles,labels,'Location','eastoutside');end

    % Inset: reference-based plateaus with a N^(-1/2) guide.
    rr=table();
    if ~isempty(P), rr=P(P.K==k,:); end
    if ~isempty(rr)
        ax2=axes('Position',[0.16 0.56 0.34 0.28]);hold(ax2,'on');
        ns=unique(rr.N);pl=zeros(size(ns));err=pl;
        for j=1:numel(ns)
            v=rr.plateau_DTV(rr.N==ns(j));
            pl(j)=mean(v,'omitnan');
            err(j)=1.96*std(v,'omitnan')/sqrt(sum(isfinite(v)));
        end
        errorbar(ns,max(pl,realmin),err,'ko-','LineWidth',1.2);
        if ~isempty(pl) && pl(1)>0
            plot(ns,pl(1)*(ns/ns(1)).^(-0.5),'r--','LineWidth',1.15);
        end
        set(ax2,'XScale','log','YScale','log');
        xlabel(ax2,'N');ylabel(ax2,'Reference TV'); grid(ax2,'on');
        s=table();
        if ~isempty(S), s=S(S.K==k,:); end
        if ~isempty(s)
            title(ax2,sprintf('slope %.3f +/- %.3f (95%%)', ...
                s.slope_mean(1),s.slope_CI95_half(1)),'FontSize',9);
        else
            title(ax2,'Reference trend; fewer than 3 N values for slope','FontSize',9);
        end
    end
    saveas(f,fullfile(outDir,sprintf('E3_FigE_K%d.png',k)));
    print(f,fullfile(outDir,sprintf('E3_FigE_K%d.svg',k)),'-dsvg');
    close(f);
end

% Figure F: compare B=256 and B=4096 at exactly matching B*T.
if ~cfg.doFigureFControl, return; end
for k=cfg.K_values
    f=figure('Color','w','Position',[80 80 1280 500]);
    tL=cfg.F_reference_T_large;
    for ni=1:numel(cfg.N_values)
        n=cfg.N_values(ni);
        subplot(1,numel(cfg.N_values),ni);hold on;
        vals=nan(numel(tL),2); errs=vals;
        for it=1:numel(tL)
            for ib=1:2
                if ib==1
                    B=cfg.B_small; T=cfg.B_large*tL(it)/cfg.B_small;
                    kind="fixedBT";
                else
                    B=cfg.B_large;T=tL(it);kind="grid";
                end
                sub=R.DTV(R.K==k & R.N==n & R.B==B & R.T==T & R.kind==kind);
                if isempty(sub),continue;end
                vals(it,ib)=mean(sub,'omitnan');
                errs(it,ib)=1.96*std(sub,'omitnan')/sqrt(sum(isfinite(sub)));
            end
        end
        % Explicit offsets work for both a single budget (smoke) and
        % multiple budgets (formal); grouped bar(vals) may return one Bar.
        x=1:numel(tL);
        plotColors=lines(2);
        bh=gobjects(1,2);
        bh(1)=bar(x-0.18,vals(:,1),0.34,'FaceColor',plotColors(1,:));
        bh(2)=bar(x+0.18,vals(:,2),0.34,'FaceColor',plotColors(2,:));
        for ib=1:2
            if ib==1, xpos=x-0.18; else, xpos=x+0.18; end
            good=isfinite(vals(:,ib)) & isfinite(errs(:,ib));
            if any(good)
                errorbar(xpos(good),vals(good,ib),errs(good,ib), ...
                    'k.','CapSize',3);
            end
        end
        xticks(1:numel(tL));
        xticklabels(string(cfg.B_large*tL));
        xtickangle(28);xlabel('Matched presented samples B x T');
        ylabel('D_{TV}');title(sprintf('K=%d, N=%g',k,n));
        grid on;box on;
        if ni==numel(cfg.N_values)
            legend(bh,{'B=256','B=4096'},'Location','best');
        end
    end
    sgtitle(sprintf('E3 Figure F: fixed B x T, variable batch, K=%d',k));
    saveas(f,fullfile(outDir,sprintf('E3_FigF_K%d.png',k)));
    print(f,fullfile(outDir,sprintf('E3_FigF_K%d.svg',k)),'-dsvg');
    close(f);
end
end
