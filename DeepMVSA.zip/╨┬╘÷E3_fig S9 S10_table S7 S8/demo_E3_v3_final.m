%% DEEPMVSA E3 — FINAL FORMAL EXPERIMENT
% Implements the approved 2026-11-23 E3 plan:
% GRID (14 cells x 10 repeats x 6 nodes = 840),
% FIXED-BT (2 K x 3 N x 3 budgets x 2 batch sizes x 5 repeats = 180),
% REFERENCE (5 cells x 3 datasets x 2 restarts = 30).
%
% Data: noiseless regular K-simplex, p=K+1 vertices, Dirichlet(1) mixtures.
% Geometry: E2/Table-2 symmetric Monte-Carlo intersection-volume D_TV.
% Model: deep_mvsa_invflow_E3_ckpt.m in the same folder; VCA.m on MATLAB path.
%
% IMPORTANT:
%   - This is the FORMAL runner, not the toy demo.
%   - Output directory is intentionally kept as ./outputs_e3v3/.
%   - Existing incompatible toy checkpoint is NOT silently reused.
%   - RESUME saves after each completed task batch; a task interrupted before
%     its batch checkpoint may be rerun.
%   - Full-batch B=N is evaluated by exact chunked gradient accumulation:
%     one accumulated gradient and one Adam update per iteration.
%
% Final protocol:
%   GRID T=[250 500 1500 3000 6000 12000], WARM_UP=600 with model guard
%   WARM_UP=min(WARM_UP,MM_ITERS); repeats=10.
%   FIXED-BT: B=4096,T=[250 500 1500] versus B=256,T=[4000 8000 24000];
%             repeats=5; large-batch results reused from GRID.
%   REFERENCE: B=N, MM_ITERS=50000; early-stop rule can trigger only by
%              tCap=10000, otherwise continue to 50000; 3 datasets x 2 restarts.
%
% Run from this folder. Keep deep_mvsa_invflow_E3_ckpt.m and VCA.m on path.

clear; clc; close all;
tE3Start = tic;

%% --------------------------- FINAL CONFIG ---------------------------
RESUME = true;

cfg = struct();
cfg.PROTOCOL_ID = 'E3_2026-11-23_FINAL_FORMAL_v1';
cfg.MODEL_IMPLEMENTATION_ID = 'indexcoord_chunked_fullbatch_earlystopcap_v1';
cfg.K_values = [3 5];
cfg.N_values = [10000 100000 1000000];

cfg.T_values = [250 500 1500 3000 6000 12000];
cfg.nRepeats = 10;

cfg.B_small = 256;
cfg.B_large = 4096;

cfg.fixedBTRepeats = 5;
cfg.F_reference_T_large = [250 500 1500];
cfg.F_reference_T_small = cfg.B_large * cfg.F_reference_T_large / cfg.B_small;

cfg.refDataRepeats = 3;
cfg.refRestarts = 2;
cfg.refT = 50000;
cfg.earlyStop = struct('enabled',true, 'evalEvery',250, ...
    'relTol',1e-4, 'perSteps',1000, 'sustainSteps',2000, ...
    'tCap',10000, 'tHardMax',50000, 'continueToHardMax',true);

cfg.WARM_UP = 600;                 % model applies min(600, MM_ITERS)
cfg.HIDDEN = 32;
cfg.LR = 3e-4;
cfg.LAMBDA_VOL = 0.005;
cfg.LAMBDA_NONNEG = 3;
cfg.LAMBDA_EQ = 80;
cfg.LAMBDA_SUMONE = 2;
cfg.LAMBDA_ENCLOSE = 10;
cfg.SPHERIZE = 'yes';
cfg.COORD_MODE = 'index';

cfg.TV_MC_FINAL = 100000;           % E2/Table-2 metric
cfg.FULL_BATCH_CHUNK_SIZE = 50000;  % exact B=N gradient accumulation; RAM bound

cfg.DATA_SEED_BASE = 31000;
cfg.TRAIN_SEED_BASE = 61000;
cfg.TV_SEED_BASE = 910000;

cfg.PARALLEL_WORKERS = 8;
cfg.RUN_STEP0A_EQUIVALENCE = true;
cfg.RUN_STEP0B_REFERENCE_VALIDATION = true;
cfg.RUN_STEP0_CALIBRATION = true;

% Keep the requested output folder name and storage layout unchanged.
cfg.outdir = 'outputs_e3v3';
if ~exist(cfg.outdir,'dir'), mkdir(cfg.outdir); end

scriptDir = fileparts(mfilename('fullpath'));
if ~isempty(scriptDir), addpath(scriptDir); end

if exist('deep_mvsa_invflow_E3_ckpt','file') ~= 2
    error(['deep_mvsa_invflow_E3_ckpt.m is missing. Put the matching model ' ...
        'file in this folder or on the MATLAB path.']);
end
if exist('VCA','file') ~= 2
    error('VCA.m is required by the supplied E3 model and must be on the MATLAB path.');
end

CKPT = fullfile(cfg.outdir,'e3v3_formal_checkpoint.mat');
LOGFILE = fullfile(cfg.outdir,'e3v3_run.log');
diary(LOGFILE); diary on;

fprintf('\n============================================================\n');
fprintf('DEEPMVSA E3 FINAL FORMAL EXPERIMENT\n');
fprintf('Start: %s\n',datestr(now));
fprintf('K=%s | N=%s | GRID T=%s | GRID repeats=%d\n', ...
    mat2str(cfg.K_values),mat2str(cfg.N_values),mat2str(cfg.T_values),cfg.nRepeats);
fprintf('FIXED-BT repeats=%d | REFERENCE datasets=%d | restarts=%d | T_max=%d\n', ...
    cfg.fixedBTRepeats,cfg.refDataRepeats,cfg.refRestarts,cfg.refT);
fprintf('REFERENCE early-stop: evalEvery=%d, relTol=%g, window=%d, sustain=%d, cap=%d, hardMax=%d\n', ...
    cfg.earlyStop.evalEvery,cfg.earlyStop.relTol,cfg.earlyStop.perSteps, ...
    cfg.earlyStop.sustainSteps,cfg.earlyStop.tCap,cfg.earlyStop.tHardMax);
fprintf('Output folder: %s\n',fullfile(pwd,cfg.outdir));
fprintf('============================================================\n');
disp(cfg);

%% --------------------------- CHECKPOINT STATE ---------------------------
signature = jsonencode(cfg);
blankRun = e3_blank_run();
blankRef = e3_blank_ref();
blankEq = struct('B',NaN,'node',NaN,'rel_M',NaN,'rel_F',NaN, ...
    'rel_DTV',NaN,'abs_DTV',NaN,'pass',false);
blankVal = struct('K',NaN,'N',NaN,'repeat',NaN, ...
    'best_restart_early',NaN,'best_restart_full',NaN, ...
    'same_best_restart',false,'early_best_loss',NaN,'full_best_loss',NaN, ...
    'selected_DTV_early',NaN,'selected_DTV_full',NaN);
blankFull = struct('key','','K',NaN,'N',NaN,'repeat',NaN,'restart',NaN, ...
    'full_loss',NaN,'DTV',NaN,'wall_clock_s',NaN);
blankCal = struct('K',NaN,'N',NaN,'B',NaN,'T',NaN,'wall_clock_s',NaN, ...
    'predicted_wall_s',NaN,'observed_to_predicted',NaN, ...
    'matlab_mem_before_mb',NaN,'matlab_mem_after_mb',NaN, ...
    'memory_note','');

if RESUME && exist(CKPT,'file')
    old = load(CKPT,'state');
    if ~isfield(old,'state') || ~isfield(old.state,'signature')
        % Preserve the previous toy-demo checkpoint without changing the
        % requested output folder or the formal checkpoint filename.
        backupCKPT=fullfile(cfg.outdir,'e3v3_formal_checkpoint_toy_backup.mat');
        if exist(backupCKPT,'file')
            error(['An incompatible toy checkpoint exists and the backup file also exists. ' ...
                'Please archive %s manually before continuing.'],backupCKPT);
        end
        movefile(CKPT,backupCKPT,'f');
        fprintf('Previous toy checkpoint preserved as %s\n',backupCKPT);
    else
        if ~strcmp(old.state.signature,signature)
            error(['Checkpoint signature mismatch. The existing formal checkpoint was created ' ...
                'with a different configuration. Back it up manually; do not mix runs.']);
        end
        state = old.state;
        fprintf('RESUME: GRID=%d rows, FIXED-BT=%d rows, REFERENCE=%d restarts.\n', ...
            numel(state.gridRuns),numel(state.fixedRuns),numel(state.refs));
    end
    if ~exist('state','var')
        state = e3_init_state(cfg,signature,blankRun,blankRef,blankEq,blankVal,blankFull,blankCal);
    end
else
    state = e3_init_state(cfg,signature,blankRun,blankRef,blankEq,blankVal,blankFull,blankCal);
    e3_save_state(CKPT,state);
end

e3_test_tv_implementation();

%% --------------------------- STEP 0a: EQUIVALENCE ---------------------------
if cfg.RUN_STEP0A_EQUIVALENCE && ~state.step0aDone
    fprintf('\n--- STEP 0a: checkpoint / independent-run equivalence ---\n');
    K = 3; N = 10000; rep = 1; p = K+1;
    dataSeed = e3_data_seed(K,rep,cfg);
    trainSeed = e3_train_seed(K,rep,cfg);
    tvSeed = e3_tv_seed(K,rep,cfg);
    [Y,M_true] = e3_make_noiseless_data(K,N,dataSeed);
    eqRows = repmat(blankEq,0,1);

    for B = [cfg.B_small cfg.B_large]
        [~,UpC,histC,ctxC] = e3_call_model(Y,p,B,max(cfg.T_values), ...
            trainSeed,cfg,cfg.T_values,struct('enabled',false),0);
        MtrueProj = UpC' * M_true;

        for j = 1:numel(cfg.T_values)
            node = cfg.T_values(j);
            Mckp = e3_recover_from_theta(histC.theta_snaps{j},ctxC);
            MckpProj = UpC' * Mckp;
            Fckp = histC.fullloss_nodes(j);
            DTVckp = e3_tv_dist_simplex(MtrueProj,MckpProj,cfg.TV_MC_FINAL,tvSeed);

            [Mind,UpI,histI,~] = e3_call_model(Y,p,B,node, ...
                trainSeed,cfg,node,struct('enabled',false),0);
            MindProj = UpI' * Mind;
            Find = histI.fullloss_nodes(end);
            DTVind = e3_tv_dist_simplex(UpI'*M_true,MindProj,cfg.TV_MC_FINAL,tvSeed);

            relM = norm(MckpProj-MindProj,'fro') / max(norm(MindProj,'fro'),1);
            relF = abs(Fckp-Find) / max(abs(Find),eps);
            absDTV = abs(DTVckp-DTVind);
            relDTV = absDTV / max(abs(DTVind),eps);
            pass = relM < 1e-12 && relF < 1e-12 && relDTV < 1e-12;

            row = blankEq;
            row.B = B; row.node = node; row.rel_M = relM;
            row.rel_F = relF; row.rel_DTV = relDTV;
            row.abs_DTV = absDTV; row.pass = pass;
            eqRows(end+1,1) = row; %#ok<SAGROW>
            fprintf('Step0a B=%d T=%d relM=%.3e relF=%.3e relDTV=%.3e %s\n', ...
                B,node,relM,relF,relDTV,e3_passstr(pass));
        end
    end
    state.step0aRows = eqRows;
    state.step0aDone = all([eqRows.pass]);
    e3_save_state(CKPT,state);
    if ~state.step0aDone
        error('Step 0a equivalence failed. Formal experiments are stopped; inspect e3v3_checkpoint_equiv.csv.');
    end
else
    fprintf('\nSTEP 0a already passed or disabled.\n');
end

%% --------------------------- STEP 0b: REFERENCE VALIDATION ---------------------------
if cfg.RUN_STEP0B_REFERENCE_VALIDATION && ~state.step0bDone
    fprintf('\n--- STEP 0b: early-stopped vs full 50k best-of-restarts validation ---\n');
    validationN = [10000 100000];
    for N = validationN
        K = 3;
        for rep = 1:cfg.refDataRepeats
            % The early-stop runs are also the official REFERENCE records
            % for these K=3, N=1e4/1e5 cells.
            for rs = 1:cfg.refRestarts
                refKey = sprintf('REF_K%d_N%d_R%d_RS%d',K,N,rep,rs);
                if ~e3_has_ref(state.refs,refKey)
                    rec = e3_run_reference(K,N,rep,rs,cfg);
                    state.refs(end+1,1) = rec;
                    e3_save_state(CKPT,state);
                    fprintf('Step0b early REF K=%d N=%d rep=%d restart=%d stop=%d reason=%s F=%.7g\n', ...
                        K,N,rep,rs,rec.t_stop,rec.reason,rec.full_loss);
                end

                fullKey = sprintf('FULL50K_K%d_N%d_R%d_RS%d',K,N,rep,rs);
                if ~e3_has_full(state.step0bFull,fullKey)
                    fullRec = e3_run_reference_full(K,N,rep,rs,cfg);
                    fullRec.key = fullKey;
                    state.step0bFull(end+1,1) = fullRec;
                    e3_save_state(CKPT,state);
                    fprintf('Step0b full REF K=%d N=%d rep=%d restart=%d F=%.7g\n', ...
                        K,N,rep,rs,fullRec.full_loss);
                end
            end

            valKeyExists = any([state.step0bRows.K]==K & ...
                [state.step0bRows.N]==N & [state.step0bRows.repeat]==rep);
            if ~valKeyExists
                er = state.refs([state.refs.K]==K & [state.refs.N]==N & ...
                    [state.refs.repeat]==rep);
                fr = state.step0bFull([state.step0bFull.K]==K & ...
                    [state.step0bFull.N]==N & [state.step0bFull.repeat]==rep);
                if numel(er)~=cfg.refRestarts || numel(fr)~=cfg.refRestarts
                    error('Step0b is missing restart records for K=%d N=%d rep=%d.',K,N,rep);
                end
                [earlyBest,ie] = min([er.full_loss]);
                [fullBest,ifull] = min([fr.full_loss]);
                row = blankVal;
                row.K=K; row.N=N; row.repeat=rep;
                row.best_restart_early=er(ie).restart;
                row.best_restart_full=fr(ifull).restart;
                row.same_best_restart=(row.best_restart_early==row.best_restart_full);
                row.early_best_loss=earlyBest; row.full_best_loss=fullBest;
                row.selected_DTV_early=er(ie).DTV;
                row.selected_DTV_full=fr(ifull).DTV;
                state.step0bRows(end+1,1)=row; %#ok<SAGROW>
                e3_save_state(CKPT,state);
            end
        end
    end
    state.step0bDone = numel(state.step0bRows)==numel(validationN)*cfg.refDataRepeats && ...
        all([state.step0bRows.same_best_restart]);
    e3_save_state(CKPT,state);
    if ~state.step0bDone
        error(['Step 0b failed: early-stop and full-50k selected different best restarts. ' ...
            'Increase the early-stop cap and rerun; formal production has not started.']);
    end
else
    fprintf('\nSTEP 0b already passed or disabled.\n');
end

%% --------------------------- STEP 0: COST CALIBRATION ---------------------------
if cfg.RUN_STEP0_CALIBRATION && ~state.calibrationDone
    fprintf('\n--- STEP 0: full-batch cost calibration (K=3, T=250) ---\n');
    calibrationN = [100000 1000000];
    for N = calibrationN
        K=3; rep=1; p=K+1;
        if any([state.calibrationRows.N]==N), continue; end
        dataSeed=e3_data_seed(K,rep,cfg);
        trainSeed=e3_train_seed(K,rep,cfg)+700000;
        [Y,~]=e3_make_noiseless_data(K,N,dataSeed);
        memBefore=e3_memory_used_mb();
        t0=tic;
        [~,~,hist,~]=e3_call_model(Y,p,N,250,trainSeed,cfg,250, ...
            struct('enabled',false),0);
        elapsed=toc(t0);
        memAfter=e3_memory_used_mb();
        predictedPerStepMs = 1.08 + 1.10e-3*N;
        predictedWall = 250*predictedPerStepMs/1000;
        row=blankCal;
        row.K=K; row.N=N; row.B=N; row.T=250;
        row.wall_clock_s=elapsed; row.predicted_wall_s=predictedWall;
        row.observed_to_predicted=elapsed/max(predictedWall,eps);
        row.matlab_mem_before_mb=memBefore;
        row.matlab_mem_after_mb=memAfter;
        row.memory_note='MATLAB memory snapshots before/after; not an OS peak-memory measurement.';
        state.calibrationRows(end+1,1)=row; %#ok<SAGROW>
        e3_save_state(CKPT,state);
        fprintf('Calibration N=%d B=N T=250 observed=%.1fs predicted=%.1fs ratio=%.2f\n', ...
            N,elapsed,predictedWall,row.observed_to_predicted);
        if row.observed_to_predicted>1.5
            warning('E3:CalibrationOverrun', ...
                'N=%d calibration is >1.5x the cost model; revise runtime estimates before production.',N);
        end
        clear Y;
    end
    state.calibrationDone = all(ismember(calibrationN,[state.calibrationRows.N]));
    e3_save_state(CKPT,state);
else
    fprintf('\nSTEP 0 calibration already completed or disabled.\n');
end

%% --------------------------- START CPU POOL ---------------------------
[useParallel,nWorkers] = e3_start_pool(cfg.PARALLEL_WORKERS);
fprintf('\nParallel execution: %d worker(s); parfor=%d\n',nWorkers,useParallel);

%% --------------------------- FORMAL GRID ---------------------------
fprintf('\n--- FORMAL GRID ---\n');
gridTasks = e3_build_grid_tasks(cfg,state.gridRuns);
fprintf('Remaining GRID trajectories: %d (target 140 trajectories / 840 nodes)\n',numel(gridTasks));
for i0 = 1:max(1,nWorkers):numel(gridTasks)
    if isempty(gridTasks), break; end
    i1=i0; i2=min(i0+max(1,nWorkers)-1,numel(gridTasks));
    batch=gridTasks(i1:i2);
    batchOut=e3_run_grid_batch(batch,cfg,useParallel);
    for j=1:numel(batchOut)
        state.gridRuns=e3_merge_run_records(state.gridRuns,batchOut{j});
    end
    e3_save_state(CKPT,state);
    fprintf('GRID batch %d-%d/%d checkpointed; current rows=%d\n', ...
        i1,i2,numel(gridTasks),numel(state.gridRuns));
end
if numel(state.gridRuns)~=840
    error('GRID count mismatch: expected 840 rows, found %d.',numel(state.gridRuns));
end

%% --------------------------- FORMAL FIXED-BT ---------------------------
fprintf('\n--- FORMAL FIXED-BT ---\n');
% Large-batch arms are reused from the GRID B=4096 trajectories.
state.fixedRuns=e3_add_fixed_large_from_grid(state.fixedRuns,state.gridRuns,cfg);
e3_save_state(CKPT,state);

fixedTasks=e3_build_fixed_small_tasks(cfg,state.fixedRuns);
fprintf('Remaining small-batch FIXED-BT trajectories: %d (target 30 trajectories / 90 nodes)\n', ...
    numel(fixedTasks));
for i0 = 1:max(1,nWorkers):numel(fixedTasks)
    if isempty(fixedTasks), break; end
    i1=i0; i2=min(i0+max(1,nWorkers)-1,numel(fixedTasks));
    batch=fixedTasks(i1:i2);
    batchOut=e3_run_fixed_small_batch(batch,cfg,useParallel);
    for j=1:numel(batchOut)
        state.fixedRuns=e3_merge_run_records(state.fixedRuns,batchOut{j});
    end
    e3_save_state(CKPT,state);
    fprintf('FIXED-BT small-batch %d-%d/%d checkpointed; current rows=%d\n', ...
        i1,i2,numel(fixedTasks),numel(state.fixedRuns));
end
if numel(state.fixedRuns)~=180
    error('FIXED-BT count mismatch: expected 180 rows, found %d.',numel(state.fixedRuns));
end

%% --------------------------- FORMAL REFERENCE REMAINDER ---------------------------
fprintf('\n--- FORMAL REFERENCE (remaining cells) ---\n');
refTasks=e3_build_reference_tasks(cfg,state.refs);
fprintf('Remaining REFERENCE restarts: %d (target 30 total)\n',numel(refTasks));
for i0 = 1:max(1,nWorkers):numel(refTasks)
    if isempty(refTasks), break; end
    i1=i0; i2=min(i0+max(1,nWorkers)-1,numel(refTasks));
    batch=refTasks(i1:i2);
    batchOut=e3_run_reference_batch(batch,cfg,useParallel);
    for j=1:numel(batchOut)
        state.refs=e3_merge_ref_records(state.refs,batchOut{j});
    end
    e3_save_state(CKPT,state);
    fprintf('REFERENCE batch %d-%d/%d checkpointed; current restarts=%d\n', ...
        i1,i2,numel(refTasks),numel(state.refs));
end
if numel(state.refs)~=30
    error('REFERENCE count mismatch: expected 30 restarts, found %d.',numel(state.refs));
end

%% --------------------------- FINAL OUTPUTS ---------------------------
fprintf('\n--- FINAL TABLES, MAT ARCHIVE AND FIGURES ---\n');
runTable=e3_run_table([state.gridRuns;state.fixedRuns]);
configTable=e3_config_summary(runTable);
refSummary=e3_ref_summary(state.refs);
refTrajectory=e3_ref_trajectory(state.refs);
plateauTable=e3_plateau_summary(state.refs,cfg);
slopeTable=e3_slope_summary(runTable,cfg);

writetable(runTable,fullfile(cfg.outdir,'e3v3_run_summary.csv'));
writetable(configTable,fullfile(cfg.outdir,'e3v3_config_summary.csv'));
writetable(refSummary,fullfile(cfg.outdir,'e3v3_reference_summary.csv'));
writetable(refTrajectory,fullfile(cfg.outdir,'e3v3_reference_earlystop.csv'));
writetable(struct2table(state.step0aRows),fullfile(cfg.outdir,'e3v3_checkpoint_equiv.csv'));
writetable(struct2table(state.step0bRows),fullfile(cfg.outdir,'e3v3_step0b_reference_validation.csv'));
writetable(struct2table(state.calibrationRows),fullfile(cfg.outdir,'e3v3_step0_calibration.csv'));
writetable(plateauTable,fullfile(cfg.outdir,'e3v3_plateau_summary.csv'));
writetable(slopeTable,fullfile(cfg.outdir,'e3v3_slope_summary.csv'));

e3_plot_figures(runTable,state.fixedRuns,cfg,cfg.outdir);

save(fullfile(cfg.outdir,'e3v3_formal_results.mat'), ...
    'cfg','state','runTable','configTable','refSummary','refTrajectory', ...
    'plateauTable','slopeTable','-v7.3');
e3_save_state(CKPT,state);

fprintf('\n========== E3 FORMAL ACCEPTANCE ==========\n');
fprintf('Step0a checkpoint equivalence: %s\n',e3_passstr(state.step0aDone));
fprintf('Step0b reference early-stop validation: %s\n',e3_passstr(state.step0bDone));
fprintf('Step0 calibration completed: %s\n',e3_passstr(state.calibrationDone));
fprintf('GRID rows: %d / 840\n',numel(state.gridRuns));
fprintf('FIXED-BT rows: %d / 180\n',numel(state.fixedRuns));
fprintf('REFERENCE restarts: %d / 30\n',numel(state.refs));
fprintf('Total formal result rows (GRID+FIXED-BT): %d / 1020\n',height(runTable));
fprintf('Elapsed wall time: %.2f hours\n',toc(tE3Start)/3600);
fprintf('All outputs saved in: %s\n',fullfile(pwd,cfg.outdir));
diary off;

%% ============================ LOCAL FUNCTIONS ============================

function state=e3_init_state(cfg,signature,blankRun,blankRef,blankEq,blankVal,blankFull,blankCal)
state = struct();
state.signature = signature;
state.cfg = cfg;
state.gridRuns = repmat(blankRun,0,1);
state.fixedRuns = repmat(blankRun,0,1);
state.refs = repmat(blankRef,0,1);
state.step0aRows = repmat(blankEq,0,1);
state.step0aDone = false;
state.step0bRows = repmat(blankVal,0,1);
state.step0bFull = repmat(blankFull,0,1);
state.step0bDone = false;
state.calibrationRows = repmat(blankCal,0,1);
state.calibrationDone = false;
end

function r=e3_blank_run()
r=struct('key','','source_key','','kind','','K',NaN,'p',NaN,'N',NaN, ...
    'B',NaN,'T',NaN,'BT',NaN,'repeat',NaN,'data_seed',NaN, ...
    'train_seed',NaN,'tv_seed',NaN,'warmup',NaN,'DTV',NaN, ...
    'vol_true',NaN,'vol_est',NaN,'full_loss',NaN,'wall_clock_s',NaN, ...
    'node_elapsed_s',NaN,'M_true_proj',[],'M_est_proj',[]);
end

function r=e3_blank_ref()
r=struct('key','','K',NaN,'N',NaN,'repeat',NaN,'restart',NaN, ...
    'B',NaN,'Tmax',NaN,'t_stop',NaN,'reason','','data_seed',NaN, ...
    'train_seed',NaN,'tv_seed',NaN,'DTV',NaN,'vol_true',NaN, ...
    'vol_est',NaN,'full_loss',NaN,'wall_clock_s',NaN, ...
    'n_eval',NaN,'eval_t',[],'eval_F',[],'M_true_proj',[],'M_est_proj',[]);
end

function seed=e3_data_seed(K,rep,cfg)
seed=cfg.DATA_SEED_BASE+10000*K+rep;
end

function seed=e3_train_seed(K,rep,cfg)
seed=cfg.TRAIN_SEED_BASE+100000*K+1000*rep;
end

function seed=e3_tv_seed(K,rep,cfg)
seed=cfg.TV_SEED_BASE+1000*K+rep;
end

function [Y,M_true]=e3_make_noiseless_data(K,N,seed)
% Haar-rotated regular K-simplex with p=K+1 vertices and diameter sqrt(2).
rng(seed,'twister');
p=K+1;
[Q,R]=qr(randn(p,p));
sg=sign(diag(R)); sg(sg==0)=1;
M_true=Q*diag(sg);
A=-log(max(rand(p,N),realmin));
A=A./sum(A,1);                 % Dirichlet(1,...,1)
Y=M_true*A;                    % strictly noiseless
clear A;
end

function [M_est,Up,hist,ctx]=e3_call_model(Y,p,B,T,seed,cfg,recordAt,earlyStop,verbose)
args={'MM_ITERS',T,'WARM_UP',cfg.WARM_UP,'LR',cfg.LR, ...
    'HIDDEN',cfg.HIDDEN,'LAMBDA_VOL',cfg.LAMBDA_VOL, ...
    'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG,'LAMBDA_EQ',cfg.LAMBDA_EQ, ...
    'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE,'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE, ...
    'BATCH_SIZE',B,'SEED',seed,'spherize',cfg.SPHERIZE, ...
    'COORD_MODE',cfg.COORD_MODE,'SKIP_ABUNDANCE_OUTPUT',true, ...
    'FULL_BATCH_CHUNK_SIZE',cfg.FULL_BATCH_CHUNK_SIZE,'verbose',verbose, ...
    'EARLY_STOP',earlyStop};
if ~isempty(recordAt)
    args=[args {'RECORD_AT',recordAt}]; %#ok<AGROW>
end
[M_est,~,Up,~,~,hist,ctx]=deep_mvsa_invflow_E3_ckpt(Y,p,args{:});
end

function rows=e3_run_grid_task(task,cfg)
[Y,M_true]=e3_make_noiseless_data(task.K,task.N,task.data_seed);
p=task.K+1;
t0=tic;
[~,Up,hist,ctx]=e3_call_model(Y,p,task.B,max(cfg.T_values), ...
    task.train_seed,cfg,cfg.T_values,struct('enabled',false),0);
totalWall=toc(t0);
MtrueProj=Up'*M_true;
rows=repmat(e3_blank_run(),numel(cfg.T_values),1);
for j=1:numel(cfg.T_values)
    T=cfg.T_values(j);
    if isempty(hist.theta_snaps{j})
        error('Missing GRID theta snapshot: K=%d N=%d B=%d T=%d rep=%d.', ...
            task.K,task.N,task.B,T,task.rep);
    end
    M_est=e3_recover_from_theta(hist.theta_snaps{j},ctx);
    MestProj=Up'*M_est;
    [tv,volT,volE]=e3_tv_dist_simplex(MtrueProj,MestProj, ...
        cfg.TV_MC_FINAL,task.tv_seed);
    r=e3_blank_run();
    r.key=sprintf('GRID_K%d_N%d_B%d_T%d_R%d',task.K,task.N,task.B,T,task.rep);
    r.kind='GRID'; r.K=task.K; r.p=p; r.N=task.N; r.B=task.B; r.T=T;
    r.BT=double(task.B)*double(T); r.repeat=task.rep;
    r.data_seed=task.data_seed; r.train_seed=task.train_seed; r.tv_seed=task.tv_seed;
    r.warmup=min(cfg.WARM_UP,T); r.DTV=tv; r.vol_true=volT; r.vol_est=volE;
    r.full_loss=hist.fullloss_nodes(j); r.wall_clock_s=totalWall;
    r.node_elapsed_s=hist.node_elapsed_s(j);
    r.M_true_proj=MtrueProj; r.M_est_proj=MestProj;
    rows(j)=r;
end
fprintf('GRID task K=%d N=%d B=%d rep=%d finished in %.1fs\n', ...
    task.K,task.N,task.B,task.rep,totalWall);
end

function tasks=e3_build_grid_tasks(cfg,existing)
template=struct('K',NaN,'N',NaN,'B',NaN,'rep',NaN, ...
    'data_seed',NaN,'train_seed',NaN,'tv_seed',NaN);
tasks=repmat(template,0,1);
for K=cfg.K_values
    for N=cfg.N_values
        if K==3
            Bs=unique([cfg.B_small cfg.B_large N],'stable');
        elseif K==5 && N<max(cfg.N_values)
            Bs=unique([cfg.B_small cfg.B_large],'stable');
        else
            Bs=cfg.B_large;
        end
        for B=Bs
            for rep=1:cfg.nRepeats
                done=true;
                for T=cfg.T_values
                    key=sprintf('GRID_K%d_N%d_B%d_T%d_R%d',K,N,B,T,rep);
                    done=done && e3_has_run(existing,key);
                end
                if ~done
                    t=template; t.K=K; t.N=N; t.B=B; t.rep=rep;
                    t.data_seed=e3_data_seed(K,rep,cfg);
                    t.train_seed=e3_train_seed(K,rep,cfg);
                    t.tv_seed=e3_tv_seed(K,rep,cfg);
                    tasks(end+1,1)=t; %#ok<AGROW>
                end
            end
        end
    end
end
end

function out=e3_run_grid_batch(tasks,cfg,useParallel)
out=cell(numel(tasks),1);
if useParallel
    parfor i=1:numel(tasks)
        out{i}=e3_run_grid_task(tasks(i),cfg);
    end
else
    for i=1:numel(tasks), out{i}=e3_run_grid_task(tasks(i),cfg); end
end
end

function rows=e3_run_fixed_small_task(task,cfg)
[Y,M_true]=e3_make_noiseless_data(task.K,task.N,task.data_seed);
p=task.K+1;
nodes=cfg.F_reference_T_small;
t0=tic;
[~,Up,hist,ctx]=e3_call_model(Y,p,cfg.B_small,max(nodes), ...
    task.train_seed,cfg,nodes,struct('enabled',false),0);
totalWall=toc(t0);
MtrueProj=Up'*M_true;
rows=repmat(e3_blank_run(),numel(nodes),1);
for j=1:numel(nodes)
    T=nodes(j);
    M_est=e3_recover_from_theta(hist.theta_snaps{j},ctx);
    MestProj=Up'*M_est;
    [tv,volT,volE]=e3_tv_dist_simplex(MtrueProj,MestProj, ...
        cfg.TV_MC_FINAL,task.tv_seed);
    r=e3_blank_run();
    r.key=sprintf('FIXEDBT_K%d_N%d_B%d_T%d_R%d',task.K,task.N,cfg.B_small,T,task.rep);
    r.kind='FIXEDBT'; r.K=task.K; r.p=p; r.N=task.N; r.B=cfg.B_small; r.T=T;
    r.BT=double(cfg.B_small)*double(T); r.repeat=task.rep;
    r.data_seed=task.data_seed; r.train_seed=task.train_seed; r.tv_seed=task.tv_seed;
    r.warmup=min(cfg.WARM_UP,T); r.DTV=tv; r.vol_true=volT; r.vol_est=volE;
    r.full_loss=hist.fullloss_nodes(j); r.wall_clock_s=totalWall;
    r.node_elapsed_s=hist.node_elapsed_s(j);
    r.M_true_proj=MtrueProj; r.M_est_proj=MestProj;
    rows(j)=r;
end
fprintf('FIXED-BT small task K=%d N=%d rep=%d finished in %.1fs\n', ...
    task.K,task.N,task.rep,totalWall);
end

function tasks=e3_build_fixed_small_tasks(cfg,existing)
template=struct('K',NaN,'N',NaN,'rep',NaN, ...
    'data_seed',NaN,'train_seed',NaN,'tv_seed',NaN);
tasks=repmat(template,0,1);
for K=cfg.K_values
    for N=cfg.N_values
        for rep=1:cfg.fixedBTRepeats
            done=true;
            for T=cfg.F_reference_T_small
                key=sprintf('FIXEDBT_K%d_N%d_B%d_T%d_R%d',K,N,cfg.B_small,T,rep);
                done=done && e3_has_run(existing,key);
            end
            if ~done
                t=template; t.K=K; t.N=N; t.rep=rep;
                t.data_seed=e3_data_seed(K,rep,cfg);
                t.train_seed=e3_train_seed(K,rep,cfg);
                t.tv_seed=e3_tv_seed(K,rep,cfg);
                tasks(end+1,1)=t; %#ok<AGROW>
            end
        end
    end
end
end

function out=e3_run_fixed_small_batch(tasks,cfg,useParallel)
out=cell(numel(tasks),1);
if useParallel
    parfor i=1:numel(tasks)
        out{i}=e3_run_fixed_small_task(tasks(i),cfg);
    end
else
    for i=1:numel(tasks), out{i}=e3_run_fixed_small_task(tasks(i),cfg); end
end
end

function fixed=e3_add_fixed_large_from_grid(fixed,grid,cfg)
for K=cfg.K_values
    for N=cfg.N_values
        for rep=1:cfg.fixedBTRepeats
            for T=cfg.F_reference_T_large
                key=sprintf('FIXEDBT_K%d_N%d_B%d_T%d_R%d',K,N,cfg.B_large,T,rep);
                if e3_has_run(fixed,key), continue; end
                sourceKey=sprintf('GRID_K%d_N%d_B%d_T%d_R%d',K,N,cfg.B_large,T,rep);
                idx=find(strcmp({grid.key},sourceKey),1);
                if isempty(idx)
                    error('Cannot reuse missing GRID result %s for FIXED-BT.',sourceKey);
                end
                r=grid(idx);
                r.key=key; r.source_key=sourceKey; r.kind='FIXEDBT';
                fixed(end+1,1)=r; %#ok<AGROW>
            end
        end
    end
end
end

function rec=e3_run_reference(K,N,rep,restart,cfg)
[Y,M_true]=e3_make_noiseless_data(K,N,e3_data_seed(K,rep,cfg));
p=K+1; trainSeed=e3_train_seed(K,rep,cfg)+10000*restart;
tvSeed=e3_tv_seed(K,rep,cfg);
t0=tic;
[M_est,Up,hist,~]=e3_call_model(Y,p,N,cfg.refT,trainSeed,cfg,[],cfg.earlyStop,0);
elapsed=toc(t0);
if isempty(hist.es.eval_F)
    error('REFERENCE has no full-objective evaluation history.');
end
MtrueProj=Up'*M_true; MestProj=Up'*M_est;
[tv,volT,volE]=e3_tv_dist_simplex(MtrueProj,MestProj,cfg.TV_MC_FINAL,tvSeed);
rec=e3_blank_ref();
rec.key=sprintf('REF_K%d_N%d_R%d_RS%d',K,N,rep,restart);
rec.K=K; rec.N=N; rec.repeat=rep; rec.restart=restart;
rec.B=N; rec.Tmax=cfg.refT; rec.t_stop=hist.es.t_stop; rec.reason=hist.es.reason;
rec.data_seed=e3_data_seed(K,rep,cfg); rec.train_seed=trainSeed; rec.tv_seed=tvSeed;
rec.DTV=tv; rec.vol_true=volT; rec.vol_est=volE;
rec.full_loss=hist.es.eval_F(end); rec.wall_clock_s=elapsed;
rec.n_eval=numel(hist.es.eval_t); rec.eval_t=hist.es.eval_t; rec.eval_F=hist.es.eval_F;
rec.M_true_proj=MtrueProj; rec.M_est_proj=MestProj;
end

function rec=e3_run_reference_full(K,N,rep,restart,cfg)
[Y,M_true]=e3_make_noiseless_data(K,N,e3_data_seed(K,rep,cfg));
p=K+1; trainSeed=e3_train_seed(K,rep,cfg)+10000*restart;
tvSeed=e3_tv_seed(K,rep,cfg);
t0=tic;
[M_est,Up,hist,~]=e3_call_model(Y,p,N,cfg.refT,trainSeed,cfg,cfg.refT, ...
    struct('enabled',false),0);
elapsed=toc(t0);
MtrueProj=Up'*M_true; MestProj=Up'*M_est;
[tv,~,~]=e3_tv_dist_simplex(MtrueProj,MestProj,cfg.TV_MC_FINAL,tvSeed);
rec=e3_blank_full();
rec.K=K; rec.N=N; rec.repeat=rep; rec.restart=restart;
rec.full_loss=hist.fullloss_nodes(end); rec.DTV=tv; rec.wall_clock_s=elapsed;
end

function r=e3_blank_full()
r=struct('key','','K',NaN,'N',NaN,'repeat',NaN,'restart',NaN, ...
    'full_loss',NaN,'DTV',NaN,'wall_clock_s',NaN);
end

function tasks=e3_build_reference_tasks(cfg,existing)
template=struct('K',NaN,'N',NaN,'rep',NaN,'restart',NaN);
tasks=repmat(template,0,1);
for K=cfg.K_values
    for N=cfg.N_values
        eligible=(K==3) || (K==5 && N<max(cfg.N_values));
        if ~eligible, continue; end
        for rep=1:cfg.refDataRepeats
            for rs=1:cfg.refRestarts
                key=sprintf('REF_K%d_N%d_R%d_RS%d',K,N,rep,rs);
                if ~e3_has_ref(existing,key)
                    t=template; t.K=K; t.N=N; t.rep=rep; t.restart=rs;
                    tasks(end+1,1)=t; %#ok<AGROW>
                end
            end
        end
    end
end
end

function out=e3_run_reference_batch(tasks,cfg,useParallel)
out=cell(numel(tasks),1);
if useParallel
    parfor i=1:numel(tasks)
        t=tasks(i);
        out{i}=e3_run_reference(t.K,t.N,t.rep,t.restart,cfg);
    end
else
    for i=1:numel(tasks)
        t=tasks(i);
        out{i}=e3_run_reference(t.K,t.N,t.rep,t.restart,cfg);
    end
end
end

function tf=e3_has_run(r,key)
tf=~isempty(r) && any(strcmp({r.key},key));
end

function tf=e3_has_ref(r,key)
tf=~isempty(r) && any(strcmp({r.key},key));
end

function tf=e3_has_full(r,key)
tf=~isempty(r) && any(strcmp({r.key},key));
end

function r=e3_merge_run_records(r,newRows)
for j=1:numel(newRows)
    if ~e3_has_run(r,newRows(j).key)
        r(end+1,1)=newRows(j); %#ok<AGROW>
    end
end
end

function r=e3_merge_ref_records(r,newRows)
for j=1:numel(newRows)
    if ~e3_has_ref(r,newRows(j).key)
        r(end+1,1)=newRows(j); %#ok<AGROW>
    end
end
end

function e3_save_state(path,state)
tmp=[path '.tmp'];
save(tmp,'state','-v7.3');
movefile(tmp,path,'f');
end

function [useParallel,nWorkers]=e3_start_pool(requested)
useParallel=false; nWorkers=1;
try
    hasToolbox=license('test','Distrib_Computing_Toolbox') && exist('parpool','file')==2;
    if ~hasToolbox
        warning('E3:NoParallelToolbox','Parallel Computing Toolbox unavailable; running serially.');
        return;
    end
    pool=gcp('nocreate');
    if isempty(pool)
        % Try the requested worker count first, then the largest smaller pool.
        for nw=requested:-1:2
            try
                pool=parpool('local',nw);
                break;
            catch
                pool=[];
            end
        end
    end
    if isempty(pool)
        warning('E3:ParallelFallback','Could not start a multi-worker pool; running serially.');
        return;
    end
    nWorkers=min(requested,pool.NumWorkers);
    useParallel=nWorkers>1;
    if useParallel && exist('addAttachedFiles','file')==2
        depFiles={which('deep_mvsa_invflow_E3_ckpt'),which('VCA')};
        depFiles=depFiles(~cellfun(@isempty,depFiles));
        if ~isempty(depFiles), addAttachedFiles(pool,depFiles); end
    end
catch ME
    warning('E3:ParallelFallback','Could not start requested pool (%s). Running serially.',ME.message);
    useParallel=false; nWorkers=1;
end
end

function M=e3_recover_from_theta(theta,ctx)
p=ctx.p;
Lmat=eye(p)+tril(theta.L,-1);
Rmat=diag(exp(theta.r_log))+triu(theta.R,1);
Q=Lmat*ctx.Q0*Rmat;
Msub=inv(Q);
if strcmp(ctx.spherize,'yes')
    Msub=Msub*sqrt(p);
    Msub=Msub(1:p-1,:);
    M=ctx.Up(:,1:p-1)*diag(sqrt(diag(ctx.D+ctx.lambda_reg*eye(p-1))))*Msub ...
        + repmat(ctx.my,1,p);
else
    M=ctx.Up*Msub;
end
end

function [DTV,volT,volE]=e3_tv_dist_simplex(MT,ME,nMC,seed)
% E2/Table-2 exact metric definition:
% DTV = max(1 - Vol(S_T intersect S_E)/max(Vol(S_T),Vol(S_E)), 0).
% Symmetric MC estimate of intersection volume, paired by resetting seed.
rng(seed,'twister');
p=size(MT,2); K=p-1;
if size(ME,2)~=p || size(MT,1)~=size(ME,1)
    error('E2 DTV: simplex matrices must have matching dimensions.');
end
ET=MT(:,2:p)-repmat(MT(:,1),1,K);
EE=ME(:,2:p)-repmat(ME(:,1),1,K);
volT=sqrt(max(det(ET'*ET),0))/factorial(K);
volE=sqrt(max(det(EE'*EE),0))/factorial(K);
if ~(isfinite(volT)&&isfinite(volE)&&volT>0&&volE>0)
    DTV=NaN; return;
end
G=-log(max(rand(p,nMC),realmin));
alpha=G./repmat(sum(G,1),p,1);
rT=mean(e3_inside(MT*alpha,ME));
G=-log(max(rand(p,nMC),realmin));
alpha=G./repmat(sum(G,1),p,1);
rE=mean(e3_inside(ME*alpha,MT));
volIntersection=0.5*(rT*volT+rE*volE);
DTV=max(1-volIntersection/max(volT,volE),0);
end

function inside=e3_inside(X,M)
tol=1e-8;
p=size(M,2);
m0=M(:,1);
E=M(:,2:end)-repmat(m0,1,p-1);
C=E\(X-repmat(m0,1,size(X,2)));
inside=all(C>=-tol,1)&(1-sum(C,1)>=-tol);
end

function e3_test_tv_implementation()
M=eye(4);
center=mean(M,2);
Msmall=center+0.5*(M-center);
v0=e3_tv_dist_simplex(M,M,2000,1234);
v1=e3_tv_dist_simplex(M,Msmall,100000,1234);
if abs(v0)>0.02 || abs(v1-0.875)>0.02
    error('E2 DTV self-test failed: identity=%g, nested=%g (expected 0.875).',v0,v1);
end
end

function mb=e3_memory_used_mb()
mb=NaN;
try
    s=memory;
    if isfield(s,'MemUsedMATLAB')
        mb=double(s.MemUsedMATLAB)/(1024^2);
    end
catch
    mb=NaN;
end
end

function s=e3_passstr(tf)
if tf, s='PASS'; else, s='FAIL'; end
end

function T=e3_run_table(r)
n=numel(r);
kind=strings(n,1); key=strings(n,1); source=strings(n,1);
K=zeros(n,1); N=K; B=K; steps=K; BT=K; rep=K;
dataSeed=K; trainSeed=K; tvSeed=K; warmup=K;
DTV=K; volT=K; volE=K; fullLoss=K; wall=K; nodeWall=K;
for i=1:n
    x=r(i); kind(i)=string(x.kind); key(i)=string(x.key); source(i)=string(x.source_key);
    K(i)=x.K; N(i)=x.N; B(i)=x.B; steps(i)=x.T; BT(i)=x.BT; rep(i)=x.repeat;
    dataSeed(i)=x.data_seed; trainSeed(i)=x.train_seed; tvSeed(i)=x.tv_seed;
    warmup(i)=x.warmup; DTV(i)=x.DTV; volT(i)=x.vol_true; volE(i)=x.vol_est;
    fullLoss(i)=x.full_loss; wall(i)=x.wall_clock_s; nodeWall(i)=x.node_elapsed_s;
end
T=table(kind,key,source,K,N,B,steps,BT,rep,dataSeed,trainSeed,tvSeed,warmup, ...
    DTV,volT,volE,fullLoss,wall,nodeWall, ...
    'VariableNames',{'kind','key','source_key','K','N','B','T','BT','repeat', ...
    'data_seed','train_seed','tv_seed','warmup','DTV','vol_true','vol_est', ...
    'full_loss','trajectory_wall_s','node_elapsed_s'});
end

function C=e3_config_summary(R)
rows=cell(0,12);
for kind=["GRID","FIXEDBT"]
    sub=R(R.kind==kind,:);
    if isempty(sub), continue; end
    combos=unique([sub.K sub.N sub.B sub.T],'rows');
    for i=1:size(combos,1)
        k=combos(i,1); n=combos(i,2); b=combos(i,3); t=combos(i,4);
        rr=sub(sub.K==k & sub.N==n & sub.B==b & sub.T==t,:);
        vals=rr.DTV(isfinite(rr.DTV));
        if isempty(vals), continue; end
        rows(end+1,:)={kind,k,n,b,t,height(rr),mean(vals),std(vals), ...
            1.96*std(vals)/sqrt(numel(vals)),mean(rr.full_loss), ...
            mean(rr.trajectory_wall_s),mean(rr.node_elapsed_s)}; %#ok<AGROW>
    end
end
C=cell2table(rows,'VariableNames',{'kind','K','N','B','T','n_repeats', ...
    'DTV_mean','DTV_sd','DTV_CI95_half','full_loss_mean', ...
    'trajectory_wall_mean_s','node_elapsed_mean_s'});
end

function T=e3_ref_summary(r)
n=numel(r);
K=zeros(n,1); N=K; rep=K; restart=K; B=K; Tmax=K; tstop=K;
DTV=K; fullLoss=K; wall=K; nEval=K; reason=strings(n,1);
for i=1:n
    x=r(i); K(i)=x.K; N(i)=x.N; rep(i)=x.repeat; restart(i)=x.restart;
    B(i)=x.B; Tmax(i)=x.Tmax; tstop(i)=x.t_stop; DTV(i)=x.DTV;
    fullLoss(i)=x.full_loss; wall(i)=x.wall_clock_s; nEval(i)=x.n_eval;
    reason(i)=string(x.reason);
end
T=table(K,N,rep,restart,B,Tmax,tstop,reason,DTV,fullLoss,wall,nEval, ...
    'VariableNames',{'K','N','repeat','restart','B','Tmax','t_stop','reason', ...
    'DTV','full_loss','wall_clock_s','n_eval'});
end

function T=e3_ref_trajectory(r)
rows=cell(0,7);
for i=1:numel(r)
    x=r(i);
    for j=1:numel(x.eval_t)
        rows(end+1,:)={x.K,x.N,x.repeat,x.restart,x.eval_t(j), ...
            x.eval_F(j),string(x.reason)}; %#ok<AGROW>
    end
end
T=cell2table(rows,'VariableNames',{'K','N','repeat','restart','eval_t','eval_F','final_reason'});
end

function P=e3_plateau_summary(r,cfg)
rows=cell(0,10);
for K=cfg.K_values
    eligibleN=cfg.N_values;
    if K==5, eligibleN=cfg.N_values(cfg.N_values<max(cfg.N_values)); end
    for N=eligibleN
        for rep=1:cfg.refDataRepeats
            sub=r([r.K]==K & [r.N]==N & [r.repeat]==rep);
            if isempty(sub), continue; end
            [bestLoss,idx]=min([sub.full_loss]);
            x=sub(idx);
            rows(end+1,:)={K,N,rep,x.restart,bestLoss,x.DTV,x.t_stop, ...
                string(x.reason),x.n_eval,x.wall_clock_s}; %#ok<AGROW>
        end
    end
end
P=cell2table(rows,'VariableNames',{'K','N','repeat','best_restart', ...
    'best_full_loss','plateau_DTV','t_stop','reason','n_eval','wall_clock_s'});
end

function S=e3_slope_summary(R,cfg)
% The final protocol's 0.72*SD interval is tied to 10 paired GRID repeats.
% Use K=3 full-batch GRID at the final T=12000 node across N; K=5 remains
% supplementary and is not assigned a full-scale reference-scaling slope.
rows=cell(0,9);
K=3; Tfinal=max(cfg.T_values);
slopes=[];
for rep=1:cfg.nRepeats
    xN=[]; xD=[];
    for N=cfg.N_values
        q=R(R.kind=="GRID" & R.K==K & R.N==N & R.B==N & ...
            R.T==Tfinal & R.repeat==rep,:);
        if ~isempty(q) && isfinite(q.DTV(1)) && q.DTV(1)>0
            xN(end+1)=N; xD(end+1)=q.DTV(1); %#ok<AGROW>
        end
    end
    if numel(xN)==numel(cfg.N_values)
        coeff=polyfit(log10(xN),log10(xD),1);
        slopes(end+1)=coeff(1); %#ok<AGROW>
    end
end
if ~isempty(slopes)
    rows(end+1,:)={K,'GRID_B_equals_N_T12000',Tfinal,numel(cfg.N_values), ...
        numel(slopes),mean(slopes),std(slopes),0.72*std(slopes), ...
        mat2str(slopes,6)}; %#ok<AGROW>
end
S=cell2table(rows,'VariableNames',{'K','source','T','n_N_levels', ...
    'n_repeats','slope_mean','slope_sd','slope_CI95_half_0p72SD','repeat_slopes'});
end

function e3_plot_figures(R,fixedRuns,cfg,outDir)
% Figure E: DTV versus presented samples B*T, by K and N/B cell.
fig=figure('Color','w','Position',[80 80 1400 600]);
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
for ik=1:numel(cfg.K_values)
    K=cfg.K_values(ik); ax=nexttile; hold(ax,'on');
    subK=R(R.kind=="GRID" & R.K==K,:);
    combos=unique([subK.N subK.B],'rows');
    for ic=1:size(combos,1)
        N=combos(ic,1); B=combos(ic,2);
        x=[]; y=[]; lo=[]; hi=[];
        for T=cfg.T_values
            rr=subK(subK.N==N & subK.B==B & subK.T==T,:);
            if isempty(rr), continue; end
            v=rr.DTV(isfinite(rr.DTV));
            if isempty(v), continue; end
            mu=mean(v); ci=1.96*std(v)/sqrt(numel(v));
            x(end+1)=B*T; y(end+1)=max(mu,realmin); %#ok<AGROW>
            lo(end+1)=max(mu-ci,realmin); hi(end+1)=mu+ci; %#ok<AGROW>
        end
        if isempty(x), continue; end
        [x,ord]=sort(x); y=y(ord); lo=lo(ord); hi=hi(ord);
        if B==N, bLabel='B=N'; else, bLabel=sprintf('B=%d',B); end
        errorbar(ax,x,y,y-lo,hi-y,'-o','LineWidth',1.1,'MarkerSize',4, ...
            'DisplayName',sprintf('N=%d, %s',N,bLabel));
    end
    set(ax,'XScale','log','YScale','log'); grid(ax,'on'); box(ax,'on');
    xlabel(ax,'Presented samples B \times T');
    ylabel(ax,'D_{TV} (E2 / Table-2)');
    title(ax,sprintf('Figure E: K=%d',K));
    legend(ax,'Location','eastoutside','FontSize',7);
end
sgtitle('E3 Figure E — D_{TV} versus training budget (formal data)');
print(fig,fullfile(outDir,'e3v3_figE_tv_vs_BT.png'),'-dpng','-r200');
print(fig,fullfile(outDir,'e3v3_figE_tv_vs_BT.svg'),'-dsvg');
close(fig);

% Figure F: matched B*T pairs, B=256 versus B=4096.
fig=figure('Color','w','Position',[60 60 1500 850]);
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
for K=cfg.K_values
    for N=cfg.N_values
        ax=nexttile; hold(ax,'on');
        vals=nan(3,2); errs=nan(3,2);
        for it=1:3
            tLarge=cfg.F_reference_T_large(it);
            tSmall=cfg.F_reference_T_small(it);
            a=fixedRuns([fixedRuns.K]==K & [fixedRuns.N]==N & ...
                [fixedRuns.B]==cfg.B_small & [fixedRuns.T]==tSmall);
            b=fixedRuns([fixedRuns.K]==K & [fixedRuns.N]==N & ...
                [fixedRuns.B]==cfg.B_large & [fixedRuns.T]==tLarge);
            va=[a.DTV]; vb=[b.DTV];
            va=va(isfinite(va)); vb=vb(isfinite(vb));
            if ~isempty(va), vals(it,1)=mean(va); errs(it,1)=1.96*std(va)/sqrt(numel(va)); end
            if ~isempty(vb), vals(it,2)=mean(vb); errs(it,2)=1.96*std(vb)/sqrt(numel(vb)); end
        end
        bh=bar(ax,vals,'grouped');
        for ib=1:2
            if isprop(bh(ib),'XEndPoints')
                xx=bh(ib).XEndPoints;
            else
                xx=(1:3)+(ib-1.5)*0.18;
            end
            errorbar(ax,xx(:),vals(:,ib),errs(:,ib),'k.','CapSize',3);
        end
        xticks(ax,1:3);
        xticklabels(ax,{'1.024e6','2.048e6','6.144e6'});
        xlabel(ax,'Matched presented samples B \times T');
        ylabel(ax,'D_{TV}');
        title(ax,sprintf('K=%d, N=%d',K,N));
        grid(ax,'on'); box(ax,'on');
        if K==cfg.K_values(1) && N==cfg.N_values(1)
            legend(ax,bh,{'B=256','B=4096'},'Location','best');
        end
    end
end
sgtitle('E3 Figure F — Fixed B \times T, variable batch size');
print(fig,fullfile(outDir,'e3v3_figF_minibatch.png'),'-dpng','-r200');
print(fig,fullfile(outDir,'e3v3_figF_minibatch.svg'),'-dsvg');
close(fig);
end
