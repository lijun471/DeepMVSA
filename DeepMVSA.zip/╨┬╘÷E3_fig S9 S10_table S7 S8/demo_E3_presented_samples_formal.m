%% FORMAL DEEPMVSA E3 — TV versus presented samples B*T
% Reproduces the E3 design and demo_E3.py in MATLAB, using the supplied
% DeepMVSA E2 architecture and E2/Table-2 TV definition.
%
% REQUIRED: deep_mvsa_invflow_E3.m (provided with this script).
% OPTIONAL: VCA.m on MATLAB path. If unavailable, E3 model has a fallback.
% No USGS file, spectMixGen, Python or ground-truth abundance files needed.
%
% Synthetic, noise-free Section 4.1 protocol:
%   Intrinsic simplex dimension K, p=K+1 vertices.
%   True vertices = columns of a Haar-rotated orthogonal p-by-p matrix.
%   This is a regular K-simplex embedded isometrically in R^(K+1), with
%   diameter sqrt(2), same Dirichlet(1,...,1) sampling as the Python demo.
%   Abundances A(:,n) ~ Dirichlet(ones(1,p)), Y = M_true*A; NO NOISE.
%   Fixed 1-D index coordinates [-1,1] in the training model.
%
% E3 primary grid: K=[3 5]; N=[1e4 1e5 1e6];
%     T=[250 500 1500 5000 15000 50000],
%     K=3: B=[256 4096 N]; K=5: B=[4096 N]; 20 repeats.
% Figure F auxiliary paired-budget runs hold B*T fixed exactly for B=256
% and B=4096 (unlike demo_E3.py's grouped-by-T toy chart).
%
% Model objective parameters follow demo_E3.py / deepmvsa_core.py defaults;
% To isolate B/T effects, warm-up is FIXED to 200 steps (T_min=250).
% Switch WARM_POLICY='python_demo' to reproduce the demo's T-based warm-up;
% the latter confounds Figure F with different warm-up lengths.
% E2 is used specifically for geometry (Up'*M projection and DTV formula).
%
% Outputs: compact checkpoint/final .mat (NO p-by-N abundance matrices),
%          run/config/reference/plateau/slope .csv, Figures E/F PNG + SVG.
% Resumption uses E3_formal_checkpoint.mat. Existing files are not deleted.

clear; close all; clc;

%% --------------------------- USER SETTINGS ------------------------------
RUN_MODE = 'formal';      % 'formal' (paper grid) or 'smoke' (quick validation)
OUT_DIR  = fullfile(pwd, 'E3_formal_outputs');
RESUME   = true;

cfg = struct();
cfg.RUN_MODE = RUN_MODE;
cfg.K_values = [3 5];
cfg.N_values = [10000 100000 1000000];
cfg.T_values = [250 500 1500 5000 15000 50000];
cfg.B_small = 256;
cfg.B_large = 4096;
cfg.nRepeats = 20;      %20
cfg.refRepeats = 10;    %10        % design: reference may use 10 repeats
cfg.refRestarts = 5;    %5       % full-batch 50k, five random restarts
cfg.refT = 50000;
cfg.doReference = true;
cfg.doFigureFControl = true;    % genuinely fixed B*T comparison
cfg.F_reference_T_large = [250 500 1500];
cfg.TV_MC_FINAL = 100000;      % identical to supplied E2 driver
cfg.TV_MC_TRAJ = 2000;         % cheaper intermediate checkpoints
cfg.TRAJ_TARGET_POINTS = 20;
cfg.HIDDEN = 32;
cfg.LR = 3e-4;
cfg.LAMBDA_VOL = 0.005;
cfg.LAMBDA_NONNEG = 3;
cfg.LAMBDA_EQ = 80;
cfg.LAMBDA_SUMONE = 2;
cfg.LAMBDA_ENCLOSE = 10;
cfg.WARM_POLICY = 'fixed';       % keep warm-up constant across T/B
cfg.WARM_FIXED = 200;          % 200 warm-up updates for every T/B
cfg.DATA_SEED_BASE = 31000;
cfg.TRAIN_SEED_BASE = 61000;
cfg.TV_SEED_BASE = 910000;
cfg.checkpointEvery = 1;
cfg.data_note = ['Noiseless regular K-simplex, K+1 vertices, Dirichlet(1), ' ...
    'independent repetitions, paired data across B/T and nested N; ' ...
    'E2 affine-projected MC TV.'];

if strcmpi(RUN_MODE,'smoke')
    cfg.K_values = 3;
    cfg.N_values = 10000;
    cfg.T_values = [250 500];
    cfg.nRepeats = 1;
    cfg.doReference = false;
    cfg.F_reference_T_large = 250;
    cfg.TV_MC_FINAL = 10000;
    cfg.TV_MC_TRAJ = 500;
end

if exist('deep_mvsa_invflow_E3','file') ~= 2
    error('Put deep_mvsa_invflow_E3.m in this folder or on the MATLAB path.');
end
if ~exist(OUT_DIR,'dir'), mkdir(OUT_DIR); end
CKPT = fullfile(OUT_DIR,'E3_formal_checkpoint.mat');

% Stable run settings signature. RESUME should not mix incompatible grids.
signature = jsonencode(cfg);  % include ALL numerical settings in resume check

runs = struct('key',{},'kind',{},'K',{},'p',{},'N',{},'B',{},'T',{}, ...
    'BT',{},'repeat',{},'data_seed',{},'train_seed',{},'tv_seed',{}, ...
    'warmup',{},'DTV',{},'vol_true',{},'vol_est',{},'wall_clock_s',{}, ...
    'loss_total',{},'loss_recon',{},'loss_vol',{},'loss_nonneg',{}, ...
    'loss_sumone',{},'loss_eq',{},'loss_enclose',{}, ...
    'M_true',{},'M_est',{},'M_true_proj',{},'M_est_proj',{}, ...
    'Up_projection',{},'history',{});
refs = struct('key',{},'K',{},'N',{},'repeat',{},'restart',{}, ...
    'B',{},'T',{},'data_seed',{},'train_seed',{},'DTV',{}, ...
    'loss_total',{},'vol_true',{},'vol_est',{},'wall_clock_s',{}, ...
    'M_true_proj',{},'M_est_proj',{});

if RESUME && exist(CKPT,'file')
    old = load(CKPT,'runs','refs','signature');
    if ~isfield(old,'signature') || ~strcmp(old.signature,signature)
        error(['Checkpoint signature mismatch. Move old checkpoint out of ' ...
            'the folder or choose a new OUT_DIR before rerunning.']);
    end
    runs=old.runs;
    refs=old.refs;
    fprintf('RESUME: %d grid/control runs and %d reference restarts already saved.\n', ...
        numel(runs),numel(refs));
end

% Smoke test the metric on two analytically known configurations.
e3_test_tv_implementation();

fprintf('\nDeepMVSA E3: K=%s N=%s T=%s repeats=%d\n', ...
    mat2str(cfg.K_values),mat2str(cfg.N_values), ...
    mat2str(cfg.T_values),cfg.nRepeats);
fprintf('Output folder: %s\n',OUT_DIR);
if strcmpi(RUN_MODE,'formal')
    fprintf('NOTE: formal grid includes full-batch, 50k-iteration runs; substantial CPU/RAM required.\n');
end

%% --------------------- FORMAL MAIN + FIG F CONTROL ----------------------
completedSinceCheckpoint = 0;
for ik = 1:numel(cfg.K_values)
    K = cfg.K_values(ik);
    p = K+1;
    for in = 1:numel(cfg.N_values)
        N = cfg.N_values(in);
        if K==3
            B_grid = unique([cfg.B_small cfg.B_large N],'stable');
        else
            B_grid = unique([cfg.B_large N],'stable');
        end

        for rep = 1:cfg.nRepeats
            % Same true simplex and first N Dirichlet points across B/T.
            % Same dataSeed for all N with the same K,rep makes datasets
            % nested; each repeat has its own independent realization.
            dataSeed = cfg.DATA_SEED_BASE + 10000*K + rep;
            [Y,M_true] = e3_make_noiseless_data(K,N,dataSeed);
            trainSeed0 = cfg.TRAIN_SEED_BASE + 100000*K + 1000*rep;
            tvSeed = cfg.TV_SEED_BASE + 1000*K + rep;

            for ib = 1:numel(B_grid)
                B = B_grid(ib);
                for it = 1:numel(cfg.T_values)
                    T = cfg.T_values(it);
                    key = sprintf('GRID_K%d_N%d_B%d_T%d_R%d',K,N,B,T,rep);
                    if e3_has_key(runs,key), continue; end
                    [rec,elapsed] = e3_train_one(Y,M_true,K,N,B,T,rep, ...
                        dataSeed,trainSeed0,tvSeed,key,'grid',cfg);
                    runs(end+1) = rec; %#ok<SAGROW>
                    completedSinceCheckpoint=completedSinceCheckpoint+1;
                    fprintf('GRID %4d | K=%d N=%d B=%d T=%d rep=%d TV=%.5f %6.1fs\n', ...
                        numel(runs),K,N,B,T,rep,rec.DTV,elapsed);
                    if completedSinceCheckpoint>=cfg.checkpointEvery
                        e3_save_ckpt(CKPT,cfg,runs,refs,signature);
                        completedSinceCheckpoint=0;
                    end
                end
            end

            % Exact fixed-B*T controls for Figure F:
            % B_large*T_large = B_small*T_small, with T_small an integer.
            % Existing B_large runs from the primary grid are reused.
            if cfg.doFigureFControl
                for tLarge = cfg.F_reference_T_large
                    if mod(cfg.B_large*tLarge,cfg.B_small)~=0
                        error('Figure F requires an integral T_small.');
                    end
                    Tsmall = cfg.B_large*tLarge/cfg.B_small;
                    B=cfg.B_small;
                    key=sprintf('FIXEDBT_K%d_N%d_B%d_T%d_R%d',K,N,B,Tsmall,rep);
                    if e3_has_key(runs,key), continue; end
                    [rec,elapsed] = e3_train_one(Y,M_true,K,N,B,Tsmall,rep, ...
                        dataSeed,trainSeed0,tvSeed,key,'fixedBT',cfg);
                    runs(end+1)=rec; %#ok<SAGROW>
                    completedSinceCheckpoint=completedSinceCheckpoint+1;
                    fprintf('FIXED-BT   | K=%d N=%d B=%d T=%d rep=%d TV=%.5f %6.1fs\n', ...
                        K,N,B,Tsmall,rep,rec.DTV,elapsed);
                    if completedSinceCheckpoint>=cfg.checkpointEvery
                        e3_save_ckpt(CKPT,cfg,runs,refs,signature);
                        completedSinceCheckpoint=0;
                    end
                end
            end

            % Long full-batch reference: five independent starts on SAME
            % training set; choose minimum exact full-data objective later.
            if cfg.doReference && rep<=cfg.refRepeats
                for rs=1:cfg.refRestarts
                    key=sprintf('REF_K%d_N%d_R%d_RS%d',K,N,rep,rs);
                    if e3_has_key(refs,key), continue; end
                    trainSeed = trainSeed0 + 10000*rs;
                    B=N; T=cfg.refT;
                    [rec,elapsed] = e3_train_one(Y,M_true,K,N,B,T,rep, ...
                        dataSeed,trainSeed,tvSeed,key,'reference',cfg);
                    newRef = struct('key',key,'K',K,'N',N,'repeat',rep, ...
                        'restart',rs,'B',N,'T',T,'data_seed',dataSeed, ...
                        'train_seed',trainSeed,'DTV',rec.DTV, ...
                        'loss_total',rec.loss_total,'vol_true',rec.vol_true, ...
                        'vol_est',rec.vol_est,'wall_clock_s',elapsed, ...
                        'M_true_proj',rec.M_true_proj,'M_est_proj',rec.M_est_proj);
                    refs(end+1)=newRef; %#ok<SAGROW>
                    completedSinceCheckpoint=completedSinceCheckpoint+1;
                    fprintf('REFERENCE  | K=%d N=%d rep=%d restart=%d TV=%.5f loss=%.5g %6.1fs\n', ...
                        K,N,rep,rs,rec.DTV,rec.loss_total,elapsed);
                    if completedSinceCheckpoint>=cfg.checkpointEvery
                        e3_save_ckpt(CKPT,cfg,runs,refs,signature);
                        completedSinceCheckpoint=0;
                    end
                end
            end
            clear Y M_true;
        end
    end
end

e3_save_ckpt(CKPT,cfg,runs,refs,signature);

%% ---------------------------- ANALYSIS ----------------------------------
% Make compact numeric/categorical summary tables; all raw trajectories and
% projected vertex matrices remain in the MAT file for later re-analysis.
runTable = e3_run_table(runs);
refTable = e3_ref_table(refs);
[runTable,configTable,plateauTable,slopeTable] = ...
    e3_summaries(runTable,refTable,cfg);

writetable(runTable,fullfile(OUT_DIR,'E3_run_summary.csv'));
writetable(configTable,fullfile(OUT_DIR,'E3_config_summary.csv'));
if ~isempty(refTable)
    writetable(refTable,fullfile(OUT_DIR,'E3_reference_summary.csv'));
end
if ~isempty(plateauTable)
    writetable(plateauTable,fullfile(OUT_DIR,'E3_plateau_summary.csv'));
end
if ~isempty(slopeTable)
    writetable(slopeTable,fullfile(OUT_DIR,'E3_slope_summary.csv'));
end

save(fullfile(OUT_DIR,'E3_formal_results.mat'), ...
    'cfg','runs','refs','runTable','configTable','refTable', ...
    'plateauTable','slopeTable','signature','-v7.3');

e3_plot_figures(runTable,plateauTable,slopeTable,cfg,OUT_DIR);

fprintf('\nE3 completed. %d grid/control runs, %d reference restarts.\n', ...
    numel(runs),numel(refs));
fprintf('MAT/CSV/PNG/SVG are in %s\n',OUT_DIR);

%% ============================ LOCAL FUNCTIONS ===========================
function [Y,M_true] = e3_make_noiseless_data(K,N,seed)
% p orthonormal vertices form a regular K-simplex in a p=K+1 ambient space.
% Its intrinsic simplex dimension is K, not p. An orthogonal embedding is an
% isometry and preserves volumes' ratios, barycentric coordinates and TV.
% This fixes the K-versus-vertex-count mismatch in the reduced Python demo.
rng(seed,'twister');
p=K+1;
[Q,R]=qr(randn(p,p));
s=sign(diag(R)); s(s==0)=1;
M_true=Q*diag(s);
A=-log(max(rand(p,N),realmin));
A=A./sum(A,1);               % Dirichlet(1,...,1)
Y=M_true*A;                  % strict noise-free linear mixtures
end

function tf=e3_has_key(records,key)
if isempty(records), tf=false; return; end
tf=any(strcmp({records.key},key));
end

function warmup=e3_warmup(T,cfg)
if strcmpi(cfg.WARM_POLICY,'python_demo')
    warmup=max(50,min(200,floor(T/5)));  % copied from demo_E3.py
elseif strcmpi(cfg.WARM_POLICY,'fixed')
    warmup=min(cfg.WARM_FIXED,T-1);
else
    error('Unknown WARM_POLICY.');
end
assert(warmup>=0 && warmup<T,'warmup must be less than T.');
end

function [rec,elapsed]=e3_train_one(Y,M_true,K,N,B,T,rep, ...
    dataSeed,trainSeed,tvSeed,key,kind,cfg)
p=K+1; warmup=e3_warmup(T,cfg);
monitorInterval=max(1,round(T/cfg.TRAJ_TARGET_POINTS));
t0=tic;
[M_est,~,Up,~,~,hist,loss] = deep_mvsa_invflow_E3(Y,p, ...
    'MM_ITERS',T,'WARM_UP',warmup,'LR',cfg.LR, ...
    'LAMBDA_VOL',cfg.LAMBDA_VOL,'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
    'LAMBDA_EQ',cfg.LAMBDA_EQ,'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
    'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE,'BATCH_SIZE',B, ...
    'SEED',trainSeed,'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
    'spherize','yes','verbose',0,'E1_MTRUE',M_true, ...
    'E1_MONITOR_INTERVAL',monitorInterval, ...
    'E1_TV_MC',cfg.TV_MC_TRAJ,'E1_TV_SEED',tvSeed, ...
    'E3_SKIP_ABUNDANCE_OUTPUT',true);
elapsed=toc(t0);
M_true_proj=Up'*M_true;
M_est_proj=Up'*M_est;
[DTV,volTrue,volEst]=e3_tv_dist_simplex( ...
    M_true_proj,M_est_proj,cfg.TV_MC_FINAL,tvSeed);
if ~isfinite(DTV)
    warning('E3:DegenerateSimplex','DTV NaN for %s; inspect M_est.',key);
end
rec=struct('key',key,'kind',kind,'K',K,'p',p,'N',N,'B',B,'T',T, ...
    'BT',double(B)*double(T),'repeat',rep, ...
    'data_seed',dataSeed,'train_seed',trainSeed,'tv_seed',tvSeed, ...
    'warmup',warmup,'DTV',DTV,'vol_true',volTrue,'vol_est',volEst, ...
    'wall_clock_s',elapsed,'loss_total',loss.total, ...
    'loss_recon',loss.recon,'loss_vol',loss.vol, ...
    'loss_nonneg',loss.nonneg,'loss_sumone',loss.sumone, ...
    'loss_eq',loss.eq,'loss_enclose',loss.enclose, ...
    'M_true',M_true,'M_est',M_est, ...
    'M_true_proj',M_true_proj,'M_est_proj',M_est_proj, ...
    'Up_projection',Up,'history',hist);
end

function [DTV,volT,volE]=e3_tv_dist_simplex(M_T,M_E,nMC,seed)
% Exact same formula, geometry and membership tolerance as supplied E2:
% DTV = 1 - Vol(S_true INTERSECT S_est)/max(Vol(S_true),Vol(S_est)).
% Paired MC points via identical random seed in every arm of each repeat.
rng(seed,'twister');
p=size(M_T,2); K=p-1;
assert(size(M_E,2)==p && size(M_T,1)==size(M_E,1), ...
    'Simplex matrices must have equal size.');
ET=M_T(:,2:p)-repmat(M_T(:,1),1,K);
EE=M_E(:,2:p)-repmat(M_E(:,1),1,K);
volT=sqrt(max(det(ET'*ET),0))/factorial(K);
volE=sqrt(max(det(EE'*EE),0))/factorial(K);
if ~(isfinite(volT) && isfinite(volE) && volT>0 && volE>0)
    DTV=NaN; return;
end
G=-log(max(rand(p,nMC),realmin));
a=G./sum(G,1);
rT=mean(e3_inside(M_T*a,M_E));
G=-log(max(rand(p,nMC),realmin));
a=G./sum(G,1);
rE=mean(e3_inside(M_E*a,M_T));
intersection=0.5*(rT*volT+rE*volE);
DTV=max(1-intersection/max(volT,volE),0);
end

function inside=e3_inside(X,M)
% E2's barycentric-coordinate membership test.
tol=1e-8;
p=size(M,2);
m0=M(:,1);
E=M(:,2:end)-repmat(m0,1,p-1);
C=E\(X-repmat(m0,1,size(X,2)));
inside=all(C>=-tol,1)&(1-sum(C,1)>=-tol);
end

function e3_test_tv_implementation()
% Self-test the estimator using nested regular simplices. Exact TV is
% 1-scale^K; allows MC finite-sample tolerance when 1e5 draws are used.
M=eye(4); center=mean(M,2); Msmall=center+0.5*(M-center);
[v0,~,~]=e3_tv_dist_simplex(M,M,2000,1234);
[v1,~,~]=e3_tv_dist_simplex(M,Msmall,10000,1234);
if abs(v0)>0.02 || abs(v1-(1-0.5^3))>0.04
    error('E3 TV self-test failed: identity=%g, nested=%g (expected 0.875).',v0,v1);
end
end

function e3_save_ckpt(path,cfg,runs,refs,signature)
save(path,'cfg','runs','refs','signature','-v7.3');
end

function T=e3_run_table(r)
if isempty(r), T=table(); return; end
n=numel(r);
kind=strings(n,1); K=zeros(n,1); N=K; B=K; steps=K; BT=K;
rep=K; dseed=K; tseed=K; tvseed=K; warmup=K; tv=K;
vt=K; ve=K; sec=K; total=K; rec=K; vol=K;
nonneg=K; sumone=K; eq=K; enc=K;
for i=1:n
    x=r(i); kind(i)=string(x.kind);
    K(i)=x.K;N(i)=x.N;B(i)=x.B;steps(i)=x.T;BT(i)=x.BT;
    rep(i)=x.repeat;dseed(i)=x.data_seed;
    tseed(i)=x.train_seed;tvseed(i)=x.tv_seed;warmup(i)=x.warmup;
    tv(i)=x.DTV;vt(i)=x.vol_true;ve(i)=x.vol_est;
    sec(i)=x.wall_clock_s;total(i)=x.loss_total;
    rec(i)=x.loss_recon;vol(i)=x.loss_vol;nonneg(i)=x.loss_nonneg;
    sumone(i)=x.loss_sumone;eq(i)=x.loss_eq;enc(i)=x.loss_enclose;
end
T=table(kind,K,N,B,steps,BT,rep,dseed,tseed,tvseed,warmup, ...
    tv,vt,ve,sec,total,rec,vol,nonneg,sumone,eq,enc, ...
    'VariableNames',{'kind','K','N','B','T','BT','repeat', ...
    'data_seed','train_seed','tv_seed','warmup', ...
    'DTV','vol_true','vol_est','wall_clock_s','loss_total', ...
    'loss_recon','loss_vol','loss_nonneg','loss_sumone', ...
    'loss_eq','loss_enclose'});
end

function T=e3_ref_table(r)
if isempty(r), T=table(); return; end
n=numel(r);
K=zeros(n,1);N=K;rep=K;restart=K;dseed=K;tseed=K;
tv=K;obj=K;sec=K;
for i=1:n
    x=r(i);K(i)=x.K;N(i)=x.N;rep(i)=x.repeat;
    restart(i)=x.restart;dseed(i)=x.data_seed;
    tseed(i)=x.train_seed;tv(i)=x.DTV;
    obj(i)=x.loss_total;sec(i)=x.wall_clock_s;
end
T=table(K,N,rep,restart,dseed,tseed,tv,obj,sec,...
    'VariableNames',{'K','N','repeat','restart','data_seed', ...
    'train_seed','DTV','loss_total','wall_clock_s'});
end

function [R,C,P,S]=e3_summaries(R,Ref,cfg)
% eta_opt is a full-objective gap to five restart long full-batch proxy.
% Negative gaps are retained (NOT silently clamped to zero): this proxy is
% not a certified optimum and may be worse than a grid run.
if isempty(R), C=table(); P=table(); S=table(); return; end
R.eta_opt_proxy=nan(height(R),1);
R.refbest_loss=nan(height(R),1);
R.refbest_tv=nan(height(R),1);
P=table('Size',[0 6], ...
    'VariableTypes',repmat({'double'},1,6), ...
    'VariableNames',{'K','N','repeat','plateau_DTV','refbest_loss','n_restarts'});
S=table('Size',[0 6], ...
    'VariableTypes',repmat({'double'},1,6), ...
    'VariableNames',{'K','n_slopes','slope_mean','slope_sd', ...
    'slope_CI95_half','reference_slope'});
if ~isempty(Ref)
    for i=1:height(R)
        f=Ref.K==R.K(i)&Ref.N==R.N(i)&Ref.repeat==R.repeat(i);
        if any(f)
            ref=Ref(f,:);
            [best,id]=min(ref.loss_total);
            R.refbest_loss(i)=best;
            R.refbest_tv(i)=ref.DTV(id);
            R.eta_opt_proxy(i)=R.loss_total(i)-best;
        end
    end
end

% Mean, std and approximate normal 95% CI half-width by configuration.
C=table('Size',[0 14], ...
    'VariableTypes',[{'string'},repmat({'double'},1,13)], ...
    'VariableNames',{'kind','K','N','B','T','BT', ...
    'n_repeats','DTV_mean','DTV_sd','DTV_CI95_half', ...
    'time_mean_s','time_sd_s','loss_mean','eta_opt_proxy_mean'});
for k=cfg.K_values
    for n=cfg.N_values
        f=(R.K==k)&(R.N==n);
        kinds=unique(R.kind(f));
        for iKind=1:numel(kinds)
            typ=kinds(iKind);
            Bs=unique(R.B(f&R.kind==typ));
            for b=Bs'
                Ts=unique(R.T(f&R.kind==typ&R.B==b));
                for t=Ts'
                    rr=R(f&R.kind==typ&R.B==b&R.T==t,:);
                    good=isfinite(rr.DTV);
                    vals=rr.DTV(good); nrep=numel(vals);
                    if nrep<1, continue; end
                    new=table(typ,k,n,b,t,double(b)*double(t),nrep, ...
                        mean(vals),std(vals),1.96*std(vals)/sqrt(nrep), ...
                        mean(rr.wall_clock_s),std(rr.wall_clock_s), ...
                        mean(rr.loss_total,'omitnan'), ...
                        mean(rr.eta_opt_proxy,'omitnan'), ...
                        'VariableNames',{'kind','K','N','B','T','BT', ...
                        'n_repeats','DTV_mean','DTV_sd','DTV_CI95_half', ...
                        'time_mean_s','time_sd_s','loss_mean', ...
                        'eta_opt_proxy_mean'});
                    C=[C;new]; %#ok<AGROW>
                end
            end
        end
    end
end

% Per-dataset near-converged reference = minimum EXACT full objective
% across five restarts; save its TV separately from its objective value.
% If no reference run exists, do not invent a statistical plateau.
if isempty(Ref), return; end
for k=cfg.K_values
    for n=cfg.N_values
        repvals=unique(Ref.repeat(Ref.K==k&Ref.N==n));
        for rep=repvals'
            rr=Ref(Ref.K==k&Ref.N==n&Ref.repeat==rep,:);
            if isempty(rr), continue; end
            [best,j]=min(rr.loss_total);
            new=table(k,n,rep,rr.DTV(j),best,height(rr), ...
                'VariableNames',{'K','N','repeat','plateau_DTV', ...
                'refbest_loss','n_restarts'});
            P=[P;new]; %#ok<AGROW>
        end
    end
end

% CI over independent repeat-wise log-log slopes (requires >= 3 N values).
% This prevents a 2-point fit being misleadingly presented with a CI.
for k=cfg.K_values
    rr=P(P.K==k,:);
    repvals=unique(rr.repeat);
    slopes=[];
    for rep=repvals'
        r=rr(rr.repeat==rep & isfinite(rr.plateau_DTV) & ...
            rr.plateau_DTV>0,:);
        [ns,ord]=sort(r.N);
        if numel(unique(ns))<3, continue; end
        vals=r.plateau_DTV(ord);
        coefs=polyfit(log(double(ns)),log(double(vals)),1);
        slopes(end+1,1)=coefs(1); %#ok<AGROW>
    end
    if isempty(slopes), continue; end
    ns=numel(slopes); smean=mean(slopes); ssd=std(slopes);
    new=table(k,ns,smean,ssd,1.96*ssd/sqrt(ns),-0.5, ...
        'VariableNames',{'K','n_slopes','slope_mean','slope_sd', ...
        'slope_CI95_half','reference_slope'});
    S=[S;new]; %#ok<AGROW>
end
end

function e3_plot_figures(R,P,S,cfg,outDir)
if isempty(R), return; end
C=lines(max(3,numel(cfg.N_values)));
for k=cfg.K_values
    f=figure('Color','w','Position',[60 60 1050 720]);
    hold on;
    styles={'-o','--s',':^'};
    handles=gobjects(0);labels={};
    for ni=1:numel(cfg.N_values)
        n=cfg.N_values(ni);
        Bs=unique(R.B(R.K==k&R.N==n&R.kind=="grid"));
        for ib=1:numel(Bs)
            b=Bs(ib);
            r=R(R.K==k&R.N==n&R.B==b&R.kind=="grid",:);
            if isempty(r), continue; end
            ts=unique(r.T);x=zeros(size(ts));y=x;
            for j=1:numel(ts)
                sel=r.DTV(r.T==ts(j));
                x(j)=double(b)*double(ts(j));
                y(j)=mean(sel,'omitnan');
            end
            [x,ord]=sort(x);y=y(ord);
            h=plot(x,max(y,realmin),styles{min(ib,3)},'Color',C(ni,:), ...
                'LineWidth',1.35,'MarkerSize',5);
            handles=[handles,h]; %#ok<AGROW>
            if b==n, bLabel='full';else,bLabel=num2str(b);end
            labels{end+1}=sprintf('N=%g, B=%s',n,bLabel); %#ok<AGROW>
        end
    end
    set(gca,'XScale','log','YScale','log'); grid on;box on;
    xlabel('Presented samples B x T');
    ylabel('D_{TV} (E2 / Table-2 definition)');
    title(sprintf('E3 Figure E: K=%d, noiseless synthetic simplex',k));
    if ~isempty(handles),legend(handles,labels,'Location','eastoutside');end

    % Inset: reference-based plateaus with a N^(-1/2) guide.
    rr=table();
    if ~isempty(P), rr=P(P.K==k,:); end
    if ~isempty(rr)
        ax2=axes('Position',[0.16 0.56 0.34 0.28]);hold(ax2,'on');
        ns=unique(rr.N);pl=zeros(size(ns));err=pl;
        for j=1:numel(ns)
            v=rr.plateau_DTV(rr.N==ns(j));
            pl(j)=mean(v,'omitnan');
            err(j)=1.96*std(v,'omitnan')/sqrt(sum(isfinite(v)));
        end
        errorbar(ns,max(pl,realmin),err,'ko-','LineWidth',1.2);
        if ~isempty(pl) && pl(1)>0
            plot(ns,pl(1)*(ns/ns(1)).^(-0.5),'r--','LineWidth',1.15);
        end
        set(ax2,'XScale','log','YScale','log');
        xlabel(ax2,'N');ylabel(ax2,'Reference TV'); grid(ax2,'on');
        s=table();
        if ~isempty(S), s=S(S.K==k,:); end
        if ~isempty(s)
            title(ax2,sprintf('slope %.3f +/- %.3f (95%%)', ...
                s.slope_mean(1),s.slope_CI95_half(1)),'FontSize',9);
        else
            title(ax2,'Near-converged proxy, not certificate','FontSize',9);
        end
    end
    saveas(f,fullfile(outDir,sprintf('E3_FigE_K%d.png',k)));
    print(f,fullfile(outDir,sprintf('E3_FigE_K%d.svg',k)),'-dsvg');
    close(f);
end

% Figure F: compare B=256 and B=4096 at exactly matching B*T.
if ~cfg.doFigureFControl, return; end
for k=cfg.K_values
    f=figure('Color','w','Position',[80 80 1280 500]);
    tL=cfg.F_reference_T_large;
    for ni=1:numel(cfg.N_values)
        n=cfg.N_values(ni);
        subplot(1,numel(cfg.N_values),ni);hold on;
        vals=nan(numel(tL),2); errs=vals;
        for it=1:numel(tL)
            for ib=1:2
                if ib==1
                    B=cfg.B_small; T=cfg.B_large*tL(it)/cfg.B_small;
                    kind="fixedBT";
                else
                    B=cfg.B_large;T=tL(it);kind="grid";
                end
                sub=R.DTV(R.K==k & R.N==n & R.B==B & R.T==T & R.kind==kind);
                if isempty(sub),continue;end
                vals(it,ib)=mean(sub,'omitnan');
                errs(it,ib)=1.96*std(sub,'omitnan')/sqrt(sum(isfinite(sub)));
            end
        end
        bh=bar(vals,'grouped');
        for ib=1:2
            x=bh(ib).XEndPoints;
            errorbar(x,vals(:,ib),errs(:,ib),'k.','CapSize',3);
        end
        xticks(1:numel(tL));
        xticklabels(string(cfg.B_large*tL));
        xtickangle(28);xlabel('Matched presented samples B x T');
        ylabel('D_{TV}');title(sprintf('K=%d, N=%g',k,n));
        grid on;box on;
        if ni==numel(cfg.N_values)
            legend(bh,{'B=256','B=4096'},'Location','best');
        end
    end
    sgtitle(sprintf('E3 Figure F: fixed B x T, variable batch, K=%d',k));
    saveas(f,fullfile(outDir,sprintf('E3_FigF_K%d.png',k)));
    print(f,fullfile(outDir,sprintf('E3_FigF_K%d.svg',k)),'-dsvg');
    close(f);
end
end
