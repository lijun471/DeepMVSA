%% FORMAL DEEPMVSA E2: A-Net width scan under 1-D index coordinates
% Based on the v127 AISM experiment design (E2) and the uploaded E1 runner.
% Requires: deep_mvsa_invflow_E2.m, USGS_1995_Library.mat (datalib),
%           spectMixGen.m, VCA.m.
%
% Design: K=5, p=6, N=10000; h=[4 8 16 32 64 128];
%         noiseless and SNR=30 dB; 20 paired repeats; 1500 Adam steps.
% IMPORTANT: E2 is the index-coordinate (d=1) floor experiment. It does
% NOT test the spatial h^(-1/d) approximation-rate proposition.
%
% Data protocol: same USGS material selection and spectMixGen abundance
% generator as the supplied E1 runner. max_purity=1 is intentional here:
% the analytic Dirichlet(1) covariance floor requires untruncated uniform
% simplex abundances. E1's max_purity=0.8 is therefore not copied.
%
% Geometry metrics (TV and vertex error) exactly follow the supplied
% Table-2 implementation and are evaluated in Up' * M affine-projection
% coordinates. Reconstruction RMSE and eta_floor remain in the model's
% spherized working space.
% Outputs in E2_formal_outputs/: checkpoint MAT, final MAT, CSV summaries,
% Figure C/D as PNG and editable SVG.

clear; close all; clc;

%% --------------------------- CONFIGURATION ----------------------------
cfg = struct();
cfg.K = 5; cfg.p = cfg.K + 1; cfg.N = 10000;
cfg.widths = [4 8 16 32 64 128];
cfg.arms = {'noiseless','SNR30'};
cfg.snrDb = [Inf 30];
cfg.nRepeats = 20;
cfg.MM_ITERS = 1500; cfg.WARM_UP = 600; cfg.LR = 1e-3;
cfg.BATCH_SIZE = 4096;
cfg.LAMBDA_VOL = 0.01; cfg.LAMBDA_ENCLOSE = 10;
cfg.LAMBDA_SUMONE = 2; cfg.LAMBDA_NONNEG = 5; cfg.LAMBDA_EQ = 80;
cfg.TV_MC = 1e5; % same Monte-Carlo sample count as Table-2
cfg.SHAPE_PARAMETER = 1; cfg.MAX_PURITY = 1.0;
cfg.OUTLIERS = 0; cfg.VIOLATION_EXTREMES = [1 1.2];
cfg.NOISE_SHAPE = 'uniform';
cfg.DATA_SEED_BASE = 31000;
cfg.TRAIN_SEED_BASE = 61000;
cfg.MONITOR_INTERVAL = 0;
cfg.NOTE = ['USGS + spectMixGen; max_purity=1 to preserve Dirichlet(1) ' ...
    'covariance-floor assumption; SNR30 noise generated with E1 Frobenius SNR convention.'];

outDir = fullfile(pwd,'E2_formal_outputs');
if ~exist(outDir,'dir'), mkdir(outDir); end

%% ------------------------- DEPENDENCY CHECKS --------------------------
if exist('USGS_1995_Library.mat','file')
    lib = load('USGS_1995_Library.mat','datalib');
elseif exist('USGS_1995_Library','file')
    lib = load('USGS_1995_Library','datalib');
else
    error('USGS_1995_Library.mat not found in current folder or MATLAB path.');
end
if ~isfield(lib,'datalib'), error('Library must contain variable datalib.'); end
datalib_all = lib.datalib;
[~,nMaterials] = size(datalib_all);
assert(nMaterials >= cfg.p+4,'Insufficient USGS materials.');
assert(exist('spectMixGen','file')==2,'spectMixGen.m is not on MATLAB path.');
assert(exist('VCA','file')==2,'VCA.m is not on MATLAB path.');
assert(exist('deep_mvsa_invflow_E2','file')==2,'deep_mvsa_invflow_E2.m is not on MATLAB path.');

%% -------------------------- RESULT STORAGE ----------------------------
nRuns = numel(cfg.widths)*numel(cfg.arms)*cfg.nRepeats;
blank = struct('arm','','snr_db',NaN,'h',NaN,'repeat',NaN, ...
    'data_seed',NaN,'training_seed',NaN,'selected_material_indices',[], ...
    'measured_snr_db',NaN,'eta_floor',NaN,'eta_floor_rmse',NaN, ...
    'rmse_work',NaN,'rmse_observed_work',NaN,'tv',NaN, ...
    'vertex_error',NaN,'vertex_perm',[], ...
    'M_true_proj',[],'M_est_proj',[],'Up_projection',[], ...
    'vol_true',NaN,'vol_est',NaN, ...
    'anet_params',NaN,'qflow_params',NaN,'total_params',NaN, ...
    'wall_clock_s',NaN,'M_true',[],'M_est',[],'A_true',[],'A_est',[]);
runs = repmat(blank,nRuns,1); runIndex=0;

fprintf('\n============================================================\n');
fprintf('FORMAL DEEPMVSA E2: INDEX-COORDINATE WIDTH SCAN\n');
fprintf('K=%d p=%d N=%d | widths=%s | arms=%d | repeats=%d | total=%d\n', ...
    cfg.K,cfg.p,cfg.N,mat2str(cfg.widths),numel(cfg.arms),cfg.nRepeats,nRuns);
fprintf('Iterations=%d warmup=%d batch=%d LR=%g\n', ...
    cfg.MM_ITERS,cfg.WARM_UP,cfg.BATCH_SIZE,cfg.LR);
fprintf('============================================================\n');

%% ------------------------- FORMAL EXPERIMENT --------------------------
for rep = 1:cfg.nRepeats
    % Paired data: same endmembers and abundance realization for every h
    % and both noise arms within this repeat.
    dataSeed = cfg.DATA_SEED_BASE + rep;
    rng(dataSeed,'twister');
    materialOrder = 4 + randperm(nMaterials-4);
    selectedMaterials = materialOrder(1:cfg.p);
    M_true = double(datalib_all(:,selectedMaterials));

    [Y_clean,A_true,~] = spectMixGen(M_true,cfg.N, ...
        'Source_pdf','Diri_id','pdf_pars',cfg.SHAPE_PARAMETER, ...
        'max_purity',cfg.MAX_PURITY*ones(1,cfg.p), ...
        'no_outliers',cfg.OUTLIERS, ...
        'violation_extremes',cfg.VIOLATION_EXTREMES, ...
        'snr',Inf,'noise_shape',cfg.NOISE_SHAPE);
    if isequal(size(A_true),[cfg.N,cfg.p]), A_true=A_true'; end
    if ~isequal(size(A_true),[cfg.p,cfg.N])
        error('spectMixGen returned unexpected A_true size %s.',mat2str(size(A_true)));
    end
    Y_clean = double(Y_clean); A_true=double(A_true);

    % Generate one fixed noise realization for this repeat; reuse it for
    % every h so the width comparison is paired rather than data-confounded.
    E = randn(size(Y_clean));
    noiseScale = norm(Y_clean,'fro') / max(norm(E,'fro'),eps) * 10^(-30/20);
    E30 = E*noiseScale;
    measuredSNR30 = 10*log10(norm(Y_clean,'fro')^2 / norm(E30,'fro')^2);

    for ia = 1:numel(cfg.arms)
        arm = cfg.arms{ia}; snrDb = cfg.snrDb(ia);
        if isinf(snrDb), Y=Y_clean; measuredSNR=Inf;
        else, Y=Y_clean+E30; measuredSNR=measuredSNR30;
        end

        % Compute the model's exact spherized working coordinates, matching
        % deep_mvsa_invflow_E2 preprocessing, for eta_floor and RMSE.
        [Y_work,M_true_work,Up,D,my,lambda_reg] = e2_working_space(Y,M_true,cfg.p);
        CovA = (eye(cfg.p)-ones(cfg.p)/cfg.p)/(cfg.p*(cfg.p+1));
        etaFloor = real(trace(M_true_work*CovA*M_true_work'));

        for ih = 1:numel(cfg.widths)
            h = cfg.widths(ih); runIndex=runIndex+1;
            trainingSeed = cfg.TRAIN_SEED_BASE + 10000*rep + 100*ia + h;
            fprintf('\nRun %03d/%03d | %s | rep %02d/%02d | h=%3d | ', ...
                runIndex,nRuns,arm,rep,cfg.nRepeats,h);
            fprintf('measured SNR=%g dB | floor RMSE=%.6g\n',measuredSNR,sqrt(etaFloor));

            t0=tic;
            [M_est,A_est,Up_model] = deep_mvsa_invflow_E2(Y,cfg.p, ...
                'MM_ITERS',cfg.MM_ITERS,'WARM_UP',cfg.WARM_UP, ...
                'LR',cfg.LR,'LAMBDA_VOL',cfg.LAMBDA_VOL, ...
                'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
                'LAMBDA_EQ',cfg.LAMBDA_EQ, ...
                'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
                'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE, ...
                'BATCH_SIZE',cfg.BATCH_SIZE,'SEED',trainingSeed, ...
                'HIDDEN',h,'COORD_MODE','index', ...
                'spherize','yes','verbose',0,'E1_MONITOR_INTERVAL',0);
            elapsed=toc(t0);

            M_est_work = [diag(1./sqrt(diag(D+lambda_reg*eye(cfg.p-1))))* ...
                Up(:,1:cfg.p-1)'*(M_est-repmat(my,1,cfg.p)); ones(1,cfg.p)]/sqrt(cfg.p);
            Yhat_work=M_est_work*A_est;
            rmseWork=sqrt(mean(sum((Yhat_work-Y_work).^2,1)));
            % Observed-data RMSE is separately recorded for noisy runs.
            rmseObserved=sqrt(mean(sum((Yhat_work-Y_work).^2,1)));
            % Paper/Table-2 geometry metrics are evaluated in the common
            % affine-projected spectral space, NOT in the spherized space.
            % This exactly matches Table-2's Mtrue=Up'*M and Mdeep=Up'*M.
            if size(Up_model,1) ~= size(M_true,1) || size(Up_model,2) ~= cfg.p
                error('Model returned an unexpected Up projection matrix.');
            end
            M_true_proj = Up_model' * M_true;
            M_est_proj  = Up_model' * M_est;

            % Paired Monte-Carlo seed: identical samples for every h within
            % the same repeat (and across both noise arms).
            tvSeed = 900000 + 1000*rep;
            [tv,volTrue,volEst] = e2_tv_dist_simplex( ...
                M_true_proj,M_est_proj,cfg.TV_MC,tvSeed);
            [vertexErr,vertexPerm] = e2_vertex_error_table2( ...
                M_true_proj,M_est_proj);
            anetParams = h^2 + (2*1 + 3 + 2*cfg.p)*h + 2*cfg.p + 1;
            qflowParams = cfg.p^2;

            runs(runIndex)=struct('arm',arm,'snr_db',snrDb,'h',h,'repeat',rep, ...
                'data_seed',dataSeed,'training_seed',trainingSeed, ...
                'selected_material_indices',selectedMaterials, ...
                'measured_snr_db',measuredSNR,'eta_floor',etaFloor, ...
                'eta_floor_rmse',sqrt(etaFloor),'rmse_work',rmseWork, ...
                'rmse_observed_work',rmseObserved,'tv',tv, ...
                'vertex_error',vertexErr,'vertex_perm',vertexPerm, ...
                'M_true_proj',M_true_proj,'M_est_proj',M_est_proj, ...
                'Up_projection',Up_model, ...
                'vol_true',volTrue,'vol_est',volEst, ...
                'anet_params',anetParams,'qflow_params',qflowParams, ...
                'total_params',anetParams+qflowParams,'wall_clock_s',elapsed, ...
                'M_true',M_true,'M_est',M_est,'A_true',A_true,'A_est',A_est);

            fprintf('   RMSE=%.6g | floor=%.6g | TV=%.5f | vertex=%.5g | P=%d | %.1fs\n', ...
                rmseWork,sqrt(etaFloor),tv,vertexErr,anetParams+qflowParams,elapsed);
            if mod(runIndex,5)==0 || runIndex==nRuns
                save(fullfile(outDir,'E2_formal_checkpoint.mat'), ...
                    'cfg','runs','runIndex','-v7.3');
            end
            clear M_est A_est M_est_work Yhat_work;
        end
    end
end

%% ------------------------- TABLES AND FIGURES -------------------------
T = struct2table(runs);
% Do not place large matrices into CSV.
Tcsv = removevars(T,{'M_true','M_est','A_true','A_est', ...
    'M_true_proj','M_est_proj','Up_projection','vertex_perm'});
writetable(Tcsv,fullfile(outDir,'E2_run_summary.csv'));

summaryRows={};
for ia=1:numel(cfg.arms)
    for ih=1:numel(cfg.widths)
        idx=strcmp(T.arm,cfg.arms{ia}) & T.h==cfg.widths(ih);
        r=T(idx,:);
        summaryRows(end+1,:)={cfg.arms{ia},cfg.widths(ih),height(r), ...
            mean(r.rmse_work),std(r.rmse_work),mean(r.eta_floor_rmse), ...
            mean(r.tv),std(r.tv),mean(r.vertex_error),std(r.vertex_error), ...
            mean(r.total_params),mean(r.wall_clock_s),std(r.wall_clock_s)}; %#ok<SAGROW>
    end
end
summary=cell2table(summaryRows,'VariableNames', ...
    {'arm','h','n_repeats','RMSE_mean','RMSE_sd','floor_RMSE_mean', ...
     'TV_mean','TV_sd','vertex_error_mean','vertex_error_sd', ...
     'total_params','time_mean_s','time_sd_s'});
writetable(summary,fullfile(outDir,'E2_config_summary.csv'));

% Figure C: log-log RMSE vs h; analytic noise-free floor; h^-1 is reference only.
figC=figure('Color','w','Position',[80 80 920 650]); hold on;
cc=[0.12 0.36 0.68;0.82 0.38 0.16];
for ia=1:2
    means=zeros(size(cfg.widths)); cis=zeros(size(cfg.widths)); floors=zeros(size(cfg.widths));
    for ih=1:numel(cfg.widths)
        idx=strcmp(T.arm,cfg.arms{ia}) & T.h==cfg.widths(ih);
        x=T.rmse_work(idx); means(ih)=mean(x); cis(ih)=0.47*std(x); floors(ih)=mean(T.eta_floor_rmse(idx));
    end
    errorbar(cfg.widths,means,cis,'-o','Color',cc(ia,:), ...
        'MarkerFaceColor',cc(ia,:),'LineWidth',1.8,'CapSize',5, ...
        'DisplayName',[cfg.arms{ia} ' mean +/- 0.47 SD']);
end
floor0=mean(T.eta_floor_rmse(strcmp(T.arm,'noiseless')));
yline(floor0,'k--','LineWidth',1.5,'DisplayName','analytic sqrt(eta_{floor}), noiseless');
idxRef=strcmp(T.arm,'noiseless') & T.h==32;
refMean=mean(T.rmse_work(idxRef));
plot(cfg.widths,refMean*(cfg.widths/32).^(-1),'k:','LineWidth',1.3, ...
    'DisplayName','h^{-1} reference slope (not a prediction)');
set(gca,'XScale','log','YScale','log','XTick',cfg.widths,'XTickLabel',string(cfg.widths));
xlabel('A-Net hidden width h'); ylabel('Working-space reconstruction RMSE');
title('E2 Figure C: reconstruction error versus network width'); grid on; box on; legend('Location','best');
saveas(figC,fullfile(outDir,'E2_FigC_RMSE_vs_width.png'));
print(figC,fullfile(outDir,'E2_FigC_RMSE_vs_width.svg'),'-dsvg');

% Figure D: TV distributions for both noise arms.
figD=figure('Color','w','Position',[80 80 1050 650]); hold on;
positions=[]; data={}; labels={}; group=[];
for ia=1:2
    for ih=1:numel(cfg.widths)
        idx=strcmp(T.arm,cfg.arms{ia}) & T.h==cfg.widths(ih);
        data{end+1}=T.tv(idx); %#ok<SAGROW>
        positions(end+1)=ih+(ia-1)*0.34; %#ok<SAGROW>
        labels{end+1}=sprintf('%d',cfg.widths(ih)); %#ok<SAGROW>
        group(end+1)=ia; %#ok<SAGROW>
    end
end
for ia=1:2
    ids=find(group==ia);
    for jj=ids
        boxchart(positions(jj)*ones(size(data{jj})),data{jj}, ...
            'BoxWidth',0.25,'BoxFaceColor',cc(ia,:),'MarkerStyle','.', ...
            'MarkerColor',cc(ia,:));
    end
end
xticks(1.17:1:6.17); xticklabels(string(cfg.widths));
xlabel('A-Net hidden width h'); ylabel('TV(estimated simplex, true simplex)');
title('E2 Figure D: total-variation distance versus network width');
grid on; box on;
legend([plot(nan,nan,'s','MarkerFaceColor',cc(1,:),'MarkerEdgeColor',cc(1,:)), ...
        plot(nan,nan,'s','MarkerFaceColor',cc(2,:),'MarkerEdgeColor',cc(2,:))], ...
        {'noiseless','SNR=30 dB'},'Location','best');
saveas(figD,fullfile(outDir,'E2_FigD_TV_vs_width.png'));
print(figD,fullfile(outDir,'E2_FigD_TV_vs_width.svg'),'-dsvg');

save(fullfile(outDir,'E2_formal_results.mat'),'cfg','runs','Tcsv','summary','-v7.3');
fprintf('\nE2 COMPLETE: %d runs. Results: %s\n',runIndex,outDir);

%% ============================ LOCAL FUNCTIONS =========================
function [Yw,Mw,Up,D,my,lambda_reg]=e2_working_space(Y,M,p)
[L,N]=size(Y); my=mean(Y,2); Yc=Y-my;
[Up,D]=svds(Yc*Yc'/N,p-1);
Yp=Up*Up'*Yc+my; my_ortho=my-Up*Up'*my;
Up=[Up,my_ortho/sqrt(sum(my_ortho.^2))];
lambda_reg=1e-10;
C=diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
Yw=C*Up(:,1:p-1)'*(Yp-my); Yw(p,:)=1; Yw=Yw/sqrt(p);
Mw=C*Up(:,1:p-1)'*(M-repmat(my,1,p)); Mw(p,:)=1; Mw=Mw/sqrt(p);
end

function [D_TV,vol_T,vol_E]=e2_tv_dist_simplex(M_T,M_E,M_MC,seed)
% Same estimator as tv_dist_simplex in the supplied Table-2 script.
% D_TV = 1 - Vol(S_T intersect S_E)/max(Vol(S_T),Vol(S_E)).
% Resetting the seed makes the Monte-Carlo points paired across widths.
rng(seed,'twister');
p_local=size(M_T,2);
K_local=p_local-1;
if size(M_E,2)~=p_local || size(M_T,1)~=size(M_E,1)
    error('TV requires two vertex matrices with matching dimensions.');
end
E_T=M_T(:,2:p_local)-repmat(M_T(:,1),1,K_local);
E_E=M_E(:,2:p_local)-repmat(M_E(:,1),1,K_local);
vol_T=sqrt(max(det(E_T'*E_T),0))/factorial(K_local);
vol_E=sqrt(max(det(E_E'*E_E),0))/factorial(K_local);
if ~(isfinite(vol_T)&&isfinite(vol_E)&&vol_T>0&&vol_E>0)
    D_TV=NaN; return;
end
G=-log(rand(p_local,M_MC));
alpha=G./repmat(sum(G,1),p_local,1);
r_T=mean(e2_in_simplex(M_T*alpha,M_E));
G=-log(rand(p_local,M_MC));
alpha=G./repmat(sum(G,1),p_local,1);
r_E=mean(e2_in_simplex(M_E*alpha,M_T));
vol_int=0.5*(r_T*vol_T+r_E*vol_E);
D_TV=max(1-vol_int/max(vol_T,vol_E),0);
end

function inside=e2_in_simplex(X,M)
% Same barycentric membership test and tolerance as Table-2 script.
tol=1e-8;
m0=M(:,1);
E=M(:,2:end)-repmat(m0,1,size(M,2)-1);
C=E\(X-repmat(m0,1,size(X,2)));
inside=all(C>=-tol,1)&(1-sum(C,1)>=-tol);
end

function [best_err,best_perm]=e2_vertex_error_table2(M_T,M_E)
% Same optimal-permutation normalized RMS vertex error as Table-2 script:
% sqrt(min_perm sum_k ||m_k-mhat_perm(k)||_2^2 / (K*(K+1))).
p_local=size(M_T,2);
K_local=p_local-1;
if size(M_E,2)~=p_local || size(M_T,1)~=size(M_E,1)
    error('Vertex matrices must have matching dimensions and vertex counts.');
end
Pset=perms(1:p_local);
best_err=inf;
best_perm=1:p_local;
for r=1:size(Pset,1)
    perm=Pset(r,:);
    D=M_T-M_E(:,perm);
    err=sqrt(sum(D(:).^2)/(K_local*p_local));
    if err<best_err
        best_err=err;
        best_perm=perm;
    end
end
end
