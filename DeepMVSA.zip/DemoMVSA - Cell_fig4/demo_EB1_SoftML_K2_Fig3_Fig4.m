%% E-B / Soft-ML Section 4.2: Reproduce Figures 3 and 4 (K=2, noiseless)
% Based on Najafi et al. (2021), Section 4.2, Figures 3-4.
%
% Paper-specified:
%   K=2; n=100; noiseless points uniformly sampled inside a 2-D simplex;
%   Fig. 3: one run from a completely random initial simplex;
%   Fig. 4: error curve averaged over 100 trials, with standard deviation.
%
% Not specified numerically in the paper:
%   exact true triangle coordinates, random seeds, random-initialization
%   distribution, gamma, alpha, and the exact iteration numbers shown in Fig. 3.
% These are exposed below as explicit user choices. Do not describe them as
% the authors' exact hidden settings.
%
% This is a standalone MATLAB SCRIPT (local functions are at the end).
% It does not require USGS data or Optimization Toolbox.
%
% Output:
%   - Figure 3-style snapshots (editable SVG + PNG)
%   - Figure 4-style mean +/- SD curve (editable SVG + PNG)
%   - MAT file containing all data, settings, and histories
%
clear; close all; clc;

%% ---------------------- User-adjustable settings -------------------------
K = 2;
p = K + 1;
N = 100;
nTrials = 100;
maxIter = 1500;

% A non-degenerate example triangle. The paper does not publish coordinates.
Vtrue = [-1.0,  1.2, -0.2;
         -0.6, -0.4,  1.1];

% The paper states gamma and alpha were adjusted to optimize performance,
% but does not publish their exact values for Fig. 4.
% Set these explicitly; do not use automatic values when reporting results.
Gamma = 0.01;
Alpha = 0.5;

% Figure 3 uses a completely random initial simplex, unlike the convex-hull
% initialization recommended in Section 4.1.
% Here each initial vertex is sampled uniformly from an expanded data box.
InitBoxExpansion = 1.5;

% Figure 3 snapshot iterations. These are illustrative because exact
% iteration indices are not specified in the paper text/caption.
Fig3Iterations = [0 150 300 600];
%Fig3Iterations = [0 300 600 3000];
% Reproducible random streams (chosen by us; not supplied by the paper).
DataSeedFig3 = 31001;
InitSeedFig3 = 31002;
FirstTrialSeed = 41000;

% The paper suggests an infinitesimal perturbation to avoid degenerate cases.
JitterRelativeToDiameter = 1e-12;

% Output folder
outDir = fullfile(pwd, 'EB1_SoftML_K2_Fig3_Fig4');
if ~exist(outDir, 'dir'), mkdir(outDir); end

%% ---------------------- Figure 3: one illustrative run ------------------
rng(DataSeedFig3, 'twister');
[X3, A3] = sample_uniform_simplex(Vtrue, N);

diam3 = exact_diameter(X3);
beta3 = 1 / diam3;

rng(InitSeedFig3, 'twister');
Theta0_3 = random_initial_simplex(X3, InitBoxExpansion);

[Theta3, hist3] = softml_run_2d(X3, Theta0_3, beta3, Gamma, Alpha, ...
    maxIter, JitterRelativeToDiameter, Vtrue);

fig3 = figure('Color','w','Name','Soft-ML Figure 3 reproduction');
tiledlayout(2,2,'Padding','compact','TileSpacing','compact');
for q = 1:numel(Fig3Iterations)
    it = Fig3Iterations(q);
    nexttile;
    plot(X3(1,:), X3(2,:), '.', 'Color',[0.35 0.35 0.35], ...
        'MarkerSize',10); hold on;
    plot_polygon(Vtrue, 'k-', 2.0);
    if it == 0
        Tshow = Theta0_3;
    else
        Tshow = hist3.Theta(:,:,it);
    end
    plot_polygon(Tshow, 'r-', 2.0);
    axis equal; grid on;
    xlabel('Coordinate 1'); ylabel('Coordinate 2');
    title(sprintf('Iteration %d',it));
    if q == 1
        legend('Data','True simplex','Estimated simplex', ...
            'Location','best');
    end
end
sgtitle('K=2, N=100, noiseless: Soft-ML simplex evolution');

%% ---------------------- Figure 4: 100 independent trials ----------------
allErrors = nan(nTrials, maxIter+1);
allObjectives = nan(nTrials, maxIter);
allSeeds = (FirstTrialSeed : FirstTrialSeed+nTrials-1)';

for r = 1:nTrials
    rng(FirstTrialSeed + r - 1, 'twister');
    [Xr, ~] = sample_uniform_simplex(Vtrue, N);
    diam = exact_diameter(Xr);
    beta = 1 / diam;

    % Each trial starts from an independently generated random simplex.
    Tr0 = random_initial_simplex(Xr, InitBoxExpansion);

    [~, hr] = softml_run_2d(Xr, Tr0, beta, Gamma, Alpha, ...
        maxIter, JitterRelativeToDiameter, Vtrue);

    % Include iteration 0, then errors after each update.
    allErrors(r,1) = vertex_error(Vtrue, Tr0);
    allErrors(r,2:end) = hr.Error(2:end);
    allObjectives(r,:) = hr.Objective(:)';
end

meanError = mean(allErrors,1,'omitnan');
stdError  = std(allErrors,0,1,'omitnan');
iterAxis = 0:maxIter;

fig4 = figure('Color','w','Name','Soft-ML Figure 4 reproduction');
hold on;
lo = max(meanError - stdError, 0);
hi = meanError + stdError;
fill([iterAxis fliplr(iterAxis)], [lo fliplr(hi)], ...
    [0.78 0.86 0.95], 'EdgeColor','none', 'FaceAlpha',0.65);
plot(iterAxis, meanError, 'b-', 'LineWidth',2);
xlabel('Iteration number');
ylabel('Vertex error (Eq. 4.1)');
title(sprintf('Mean and standard deviation over %d trials',nTrials));
legend('Mean \pm 1 SD','Mean error','Location','northeast');
grid on; box on;

%% ---------------------- Report and save reproducibility data -------------
finalErr = allErrors(:,end);
fprintf('\n===== Soft-ML Section 4.2: K=2, noiseless =====\n');
fprintf('K=%d, p=%d, N=%d, trials=%d, iterations=%d\n',K,p,N,nTrials,maxIter);
fprintf('Gamma=%.8g, Alpha=%.8g\n',Gamma,Alpha);
fprintf('Final vertex error: mean=%.8g, SD=%.8g, median=%.8g\n', ...
    mean(finalErr,'omitnan'), std(finalErr,0,'omitnan'), median(finalErr,'omitnan'));
fprintf('Min=%.8g, Max=%.8g\n',min(finalErr),max(finalErr));

settings = struct('K',K,'p',p,'N',N,'nTrials',nTrials, ...
    'maxIter',maxIter,'Vtrue',Vtrue,'Gamma',Gamma,'Alpha',Alpha, ...
    'InitBoxExpansion',InitBoxExpansion,'Fig3Iterations',Fig3Iterations, ...
    'DataSeedFig3',DataSeedFig3,'InitSeedFig3',InitSeedFig3, ...
    'FirstTrialSeed',FirstTrialSeed, ...
    'JitterRelativeToDiameter',JitterRelativeToDiameter, ...
    'note','Coordinates, seeds, initialization distribution, Gamma and Alpha are explicit choices; exact values are not published in the paper.');

save(fullfile(outDir,'EB1_SoftML_K2_Fig3_Fig4_results.mat'), ...
    'settings','X3','A3','Theta0_3','Theta3','hist3', ...
    'allErrors','allObjectives','allSeeds','iterAxis','meanError','stdError');

writematrix([(0:maxIter)', meanError(:), stdError(:)], ...
    fullfile(outDir,'Fig4_mean_SD.csv'));
writematrix([(1:nTrials)', allSeeds, finalErr], ...
    fullfile(outDir,'Fig4_trial_final_errors.csv'));

% Export editable vector SVG and PNG previews.
exportgraphics(fig3, fullfile(outDir,'Fig3_simplex_snapshots.svg'), ...
    'ContentType','vector');
exportgraphics(fig3, fullfile(outDir,'Fig3_simplex_snapshots.png'), ...
    'Resolution',300);
exportgraphics(fig4, fullfile(outDir,'Fig4_vertex_error_convergence.svg'), ...
    'ContentType','vector');
exportgraphics(fig4, fullfile(outDir,'Fig4_vertex_error_convergence.png'), ...
    'Resolution',300);

fprintf('Results saved in: %s\n',outDir);

%% ============================ Local functions ============================

function [X,A] = sample_uniform_simplex(V,n)
% Uniform distribution over a triangle via Dirichlet(1,1,1) barycentric
% coordinates. This is a standard implementation of uniform simplex sampling.
p = size(V,2);
E = -log(max(rand(p,n),realmin));
A = E ./ sum(E,1);
X = V*A;
end

function T = random_initial_simplex(X,expansion)
% Random initial triangle; the paper does not specify its exact distribution.
lo = min(X,[],2);
hi = max(X,[],2);
span = max(hi-lo);
pad = expansion*span;
for k = 1:10000
    T = lo-pad + (hi-lo+2*pad).*rand(2,3);
    if abs(det(T(:,2:3)-T(:,1))) > 1e-8*max(span^2,1)
        return;
    end
end
error('Could not generate a non-degenerate random initial simplex.');
end

function [T,h] = softml_run_2d(X,T,beta,gamma,alpha,maxIter,jitterRel,Ttrue)
n = size(X,2);
h.Theta = nan(2,3,maxIter);
h.Error = nan(1,maxIter+1);
h.Objective = nan(maxIter,1);
h.Error(1) = vertex_error(Ttrue,T);

diam = exact_diameter(X);
for t = 1:maxIter
    T = T + jitterRel*diam*randn(size(T));
    [W,b] = facets_2d(T);
    [dataLoss,Gdata] = data_loss_gradient_2d(X,T,W,b,beta);
    [vol,Gvol] = volume_gradient_2d(T);
    G = Gdata + gamma*Gvol;
    h.Objective(t) = dataLoss + gamma*vol;
    T = T - alpha*G;
    h.Theta(:,:,t) = T;
    h.Error(t+1) = vertex_error(Ttrue,T);
end
end

function [W,b] = facets_2d(T)
W = zeros(2,3); b = zeros(3,1);
for k = 1:3
    other = setdiff(1:3,k);
    B = T(:,other);
    c = mean(B,2);
    e = B(:,2)-B(:,1);
    w = [e(2);-e(1)];
    w = w/norm(w);
    if w'*(T(:,k)-c) > 0, w = -w; end
    W(:,k) = w;
    b(k) = -w'*c;
end
end

function [loss,G] = data_loss_gradient_2d(X,T,W,b,beta)
n = size(X,2);
V = W'*X + b;
[maxv,kstar] = max(V,[],1);
d = max(0,maxv);
loss = sum(1-exp(-beta*d))/sqrt(n);
G = zeros(2,3);
outside = maxv > 0;
for k = 1:3
    idx = find(outside & kstar==k);
    if isempty(idx), continue; end
    other = setdiff(1:3,k);
    B = T(:,other);
    c = mean(B,2);
    w = W(:,k);
    Xk = X(:,idx);
    Xproj = Xk - w*(w'*(Xk-c));
    Pstar = pinv(B)*Xproj;
    lp = beta*exp(-beta*maxv(idx));
    weightedP = Pstar*lp(:);
    G(:,other) = G(:,other) - w*weightedP';
end
G = G/sqrt(n);
end

function [vol,G] = volume_gradient_2d(T)
A = T(:,2:3)-T(:,1);
dA = det(A);
vol = abs(dA)/2;
gradDet = dA*(A'\eye(2));
GA = sign(dA)*gradDet/2;
G = zeros(2,3);
G(:,2:3) = GA;
G(:,1) = -sum(GA,2);
end

function e = vertex_error(Ttrue,Test)
C = zeros(3,3);
for i = 1:3
    for j = 1:3
        z = Ttrue(:,i)-Test(:,j);
        C(i,j) = sum(z.^2);
    end
end
P = perms(1:3);
best = inf;
for r = 1:size(P,1)
    ix = sub2ind([3 3],1:3,P(r,:));
    best = min(best,sum(C(ix)));
end
e = sqrt(best/(2*3));
end

function d = exact_diameter(X)
d = 0;
for i = 1:size(X,2)
    dif = X(:,i+1:end)-X(:,i);
    if ~isempty(dif)
        d = max(d,max(sqrt(sum(dif.^2,1))));
    end
end
end

function plot_polygon(T,style,lw)
ix = [1 2 3 1];
plot(T(1,ix),T(2,ix),style,'LineWidth',lw);
end
