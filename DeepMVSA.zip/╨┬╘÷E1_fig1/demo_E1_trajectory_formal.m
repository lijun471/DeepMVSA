%% demo_E1_trajectory_formal.m
% FORMAL E1: Optimization trajectory and objective decomposition.
%
% Data generation is explicitly USGS-1995 + spectMixGen, following the
% user's selected USGS protocol (same generator settings as the Table-2
% USGS script). The E1 grid and diagnostics follow dmvsa-aism experiment
% design, Section 3, E1.
%
% Main grid:
%   (K,SNR) = (3,20), (3,30), (5,20), (5,30), (7,20), (7,30)
%   plus K=5, SNR=Inf noiseless control.
% Mechanism control:
%   K=5, SNR=30, gamma_enc = 0.25 * 10 = 2.5.
% Each cell: 20 independent repetitions; N=10000; 2500 Adam steps.
%
% Formal outputs:
%   E1_trajectory_checkpoints.csv
%   E1_run_summary.csv
%   E1_config_summary.csv
%   E1_formal_results.mat
%   E1_FigA_loss_components.(png/svg)
%   E1_FigB_tv_volume_trajectory.(png/svg)
%   E1_FigC_gammaEnc_underweight.(png/svg)
%
% NOTE ON spectMixGen:
%   noise_shape='uniform' means equal noise variance across spectral bands.
%   spectMixGen itself generates Gaussian random noise (randn), not a
%   uniform-distribution noise amplitude.

clear; close all; clc;

%% ====================== FORMAL E1 CONFIGURATION ======================
cfg = struct();
cfg.N = 10000;
cfg.nRepeats = 20;

% Model training settings for production execution.
% The E1-specific grid paragraph lists 1500 iterations, while the same
% design document's production/demo distinction explicitly states that
% production MATLAB runs use 2500 iterations. This formal runner follows
% the production requirement (2500); set this to 1500 only for a protocol
% comparison against the reduced E1 demo.
cfg.MM_ITERS = 1500;
cfg.WARM_UP = 600;          % inherited MATLAB model default; E1 design requires warm-up/joint phases
cfg.LR = 1e-3;
cfg.BATCH_SIZE = 4096;
cfg.MONITOR_INTERVAL = 25;
cfg.TV_MC = 2000;
cfg.TV_SEED = 12345;

% E1 default weights: (gamma_vol, gamma_enc, gamma_so, lambda_nn,
%                      lambda_eq, kappa_0) = (0.01, 10, 2, 5, 80, 0.05).
cfg.LAMBDA_VOL = 0.01;
cfg.LAMBDA_ENCLOSE = 10;
cfg.LAMBDA_SUMONE = 2;
cfg.LAMBDA_NONNEG = 5;
cfg.LAMBDA_EQ = 80;
cfg.KAPPA0 = 0.05;

% USGS + spectMixGen protocol (same synthesis settings as the Table-2 script).
cfg.SHAPE_PARAMETER = 1;    % Dirichlet(1)
cfg.MAX_PURITY = 0.8;
cfg.OUTLIERS = 0;
cfg.VIOLATION_EXTREMES = [1, 1.2];
cfg.NOISE_SHAPE = 'uniform'; % equal variance across bands; Gaussian randn noise

% Six noisy grid cells, one noiseless control, and one gamma_enc underweight cell.
% Columns: label, K, SNR_dB, gamma_enc, experiment_group
configRows = {
    'K3_SNR20',                  3, 20, 10.0, 'main';
    'K3_SNR30',                  3, 30, 10.0, 'main';
    'K5_SNR20',                  5, 20, 10.0, 'main';
    'K5_SNR30',                  5, 30, 10.0, 'main';
    'K7_SNR20',                  7, 20, 10.0, 'main';
    'K7_SNR30',                  7, 30, 10.0, 'main';
    'K5_noisefree',              5, Inf, 10.0, 'noiseless_control';
    'K5_SNR30_gammaEnc_quarter', 5, 30,  2.5, 'gamma_enc_underweight'
};

nConfigs = size(configRows,1);
nRunsExpected = nConfigs * cfg.nRepeats;

%% ====================== DEPENDENCY CHECKS ============================
if exist('USGS_1995_Library.mat','file')
    lib = load('USGS_1995_Library.mat','datalib');
elseif exist('USGS_1995_Library','file')
    lib = load('USGS_1995_Library','datalib');
else
    error(['USGS_1995_Library.mat was not found. Put it in the current ', ...
           'folder or add its folder to the MATLAB path.']);
end
if ~isfield(lib,'datalib')
    error('USGS_1995_Library must contain variable "datalib".');
end
datalib_all = lib.datalib;
[~, nMaterials] = size(datalib_all);

if exist('spectMixGen','file') ~= 2
    error('spectMixGen.m was not found on the MATLAB path.');
end
if exist('deep_mvsa_invflow_E1','file') ~= 2
    error('deep_mvsa_invflow_E1.m was not found on the MATLAB path.');
end
if exist('VCA','file') ~= 2
    error('VCA.m was not found on the MATLAB path.');
end

for ic = 1:nConfigs
    K = configRows{ic,2};
    p = K + 1;
    if nMaterials < p + 4
        error('USGS library has insufficient materials for K=%d (p=%d).',K,p);
    end
end

outDir = fullfile(pwd,'E1_formal_outputs');
if ~exist(outDir,'dir'), mkdir(outDir); end

fprintf('\n============================================================\n');
fprintf('FORMAL DEEPMVSA E1: USGS DATA + OPTIMIZATION TRAJECTORIES\n');
fprintf('Configurations: %d | repeats/config: %d | total runs: %d\n', ...
    nConfigs,cfg.nRepeats,nRunsExpected);
fprintf('N=%d | iterations=%d | warm-up=%d | batch=%d | checkpoint=%d\n', ...
    cfg.N,cfg.MM_ITERS,cfg.WARM_UP,cfg.BATCH_SIZE,cfg.MONITOR_INTERVAL);
fprintf('============================================================\n');

%% ====================== RUN FORMAL E1 GRID ===========================
runTemplate = struct('condition','','group','','K',[],'p',[],'SNR_dB',[], ...
    'gamma_enc',[],'repeat',[],'data_seed',[],'training_seed',[], ...
    'selected_material_indices',[],'measured_snr_db',[],'signal_fro',[], ...
    'noise_fro',[],'wall_clock_s',[],'M_true',[],'M_est',[],'history',[]);
runs = repmat(runTemplate,nRunsExpected,1);
runIndex = 0;

for ic = 1:nConfigs
    label = configRows{ic,1};
    K = configRows{ic,2};
    p = K + 1;
    snrDb = configRows{ic,3};
    gammaEnc = configRows{ic,4};
    groupName = configRows{ic,5};

    fprintf('\n================ CONFIG %d/%d: %s ================\n', ...
        ic,nConfigs,label);

    for rep = 1:cfg.nRepeats
        runIndex = runIndex + 1;

        % Paired data seed: for the same K and repeat, SNR20/SNR30/noiseless
        % and gamma_enc control share the same selected endmembers and A_true.
        dataSeed = 200000 + 1000*K + rep;
        trainingSeed = 500000 + 1000*K + rep;

        rng(dataSeed,'twister');

        % Match the USGS Table-2 material-selection protocol:
        % choose p spectra randomly from material indices 5:end.
        materialOrder = 4 + randperm(nMaterials - 4);
        selectedMaterials = materialOrder(1:p);
        M_true = datalib_all(:,selectedMaterials);

        % USGS synthetic mixtures using the common spectMixGen protocol.
        [Y,A_true,noise] = spectMixGen( ...
            M_true,cfg.N, ...
            'Source_pdf','Diri_id', ...
            'pdf_pars',cfg.SHAPE_PARAMETER, ...
            'max_purity',cfg.MAX_PURITY*ones(1,p), ...
            'no_outliers',cfg.OUTLIERS, ...
            'violation_extremes',cfg.VIOLATION_EXTREMES, ...
            'snr',snrDb, ...
            'noise_shape',cfg.NOISE_SHAPE);

        if ~isequal(size(A_true),[p,cfg.N])
            if isequal(size(A_true),[cfg.N,p])
                A_true = A_true';
            else
                error('Unexpected A_true dimensions in %s repeat %d.',label,rep);
            end
        end

        Y_clean = M_true*A_true;
        signalFro = norm(Y_clean,'fro');
        noiseFro = norm(noise,'fro');
        if noiseFro <= eps
            measuredSNR = Inf;
        else
            measuredSNR = 10*log10(signalFro^2/noiseFro^2);
        end

        fprintf('Run %03d/%03d | %s | rep %02d/%02d | K=%d p=%d | ', ...
            runIndex,nRunsExpected,label,rep,cfg.nRepeats,K,p);
        fprintf('requested SNR=%g dB, measured SNR=%.4f dB\n',snrDb,measuredSNR);

        % E1 model call. The estimator's numerical path is unchanged;
        % dedicated E1 model copy only records checkpoint diagnostics.
        t0 = tic;
        [M_est,~,~,~,~,hist] = deep_mvsa_invflow_E1(Y,p, ...
            'MM_ITERS',cfg.MM_ITERS, ...
            'WARM_UP',cfg.WARM_UP, ...
            'LR',cfg.LR, ...
            'LAMBDA_VOL',cfg.LAMBDA_VOL, ...
            'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
            'LAMBDA_EQ',cfg.LAMBDA_EQ, ...
            'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
            'LAMBDA_ENCLOSE',gammaEnc, ...
            'KAPPA0',cfg.KAPPA0, ...
            'BATCH_SIZE',cfg.BATCH_SIZE, ...
            'SEED',trainingSeed, ...
            'spherize','yes', ...
            'verbose',0, ...
            'E1_MONITOR_INTERVAL',cfg.MONITOR_INTERVAL, ...
            'E1_MTRUE',M_true, ...
            'E1_TV_MC',cfg.TV_MC, ...
            'E1_TV_SEED',cfg.TV_SEED);
        elapsed = toc(t0);

        runs(runIndex).condition = label;
        runs(runIndex).group = groupName;
        runs(runIndex).K = K;
        runs(runIndex).p = p;
        runs(runIndex).SNR_dB = snrDb;
        runs(runIndex).gamma_enc = gammaEnc;
        runs(runIndex).repeat = rep;
        runs(runIndex).data_seed = dataSeed;
        runs(runIndex).training_seed = trainingSeed;
        runs(runIndex).selected_material_indices = selectedMaterials;
        runs(runIndex).measured_snr_db = measuredSNR;
        runs(runIndex).signal_fro = signalFro;
        runs(runIndex).noise_fro = noiseFro;
        runs(runIndex).wall_clock_s = elapsed;
        runs(runIndex).M_true = M_true;
        runs(runIndex).M_est = M_est;
        runs(runIndex).history = hist;

        fprintf('   final TV=%.6g | volume ratio=%.6g | enc_N=%.6g | %.1f s\n', ...
            hist.tv(end),hist.volume_ratio(end),hist.enc_N(end),elapsed);

        % Incremental checkpoint save preserves completed runs for manual recovery.
        if mod(runIndex,5)==0 || runIndex==nRunsExpected
            save(fullfile(outDir,'E1_formal_checkpoint.mat'), ...
                'cfg','configRows','runs','runIndex','-v7.3');
        end
    end
end

%% ====================== BUILD CHECKPOINT TABLE =======================
checkpointTables = cell(numel(runs),1);
for ir = 1:numel(runs)
    r = runs(ir);
    h = r.history;
    n = numel(h.iteration);
    checkpointTables{ir} = table( ...
        repmat({r.condition},n,1),repmat({r.group},n,1), ...
        repmat(r.K,n,1),repmat(r.p,n,1),repmat(r.SNR_dB,n,1), ...
        repmat(r.gamma_enc,n,1),repmat(r.repeat,n,1), ...
        repmat(r.data_seed,n,1),repmat(r.training_seed,n,1), ...
        h.iteration,h.warm_up,h.total,h.recon,h.vol,h.nonneg,h.sumone, ...
        h.eq,h.enclose,h.kappa,h.logdetQ,h.estimated_volume, ...
        repmat(h.true_volume,n,1),h.volume_ratio,h.enc_N,h.tv, ...
        h.vertex_error_mean,h.vertex_error_max,h.eta_opt_proxy, ...
        'VariableNames',{'condition','group','K','p','SNR_dB','gamma_enc', ...
        'repeat','data_seed','training_seed','iteration','warm_up','total', ...
        'recon','vol','nonneg','sumone','eq','enclose','kappa','logdetQ', ...
        'estimated_volume','true_volume','volume_ratio','enc_N','tv', ...
        'vertex_error_mean','vertex_error_max','eta_opt_proxy'});
end
checkpointTable = vertcat(checkpointTables{:});
writetable(checkpointTable,fullfile(outDir,'E1_trajectory_checkpoints.csv'));

%% ====================== BUILD RUN SUMMARY ============================
nRuns = numel(runs);
condition = cell(nRuns,1);
group = cell(nRuns,1);
Kcol = zeros(nRuns,1);
pcol = zeros(nRuns,1);
SNRcol = zeros(nRuns,1);
gammaCol = zeros(nRuns,1);
repeatCol = zeros(nRuns,1);
dataSeedCol = zeros(nRuns,1);
trainSeedCol = zeros(nRuns,1);
measuredSNRCol = zeros(nRuns,1);
wallCol = zeros(nRuns,1);
finalTV = zeros(nRuns,1);
finalVolRatio = zeros(nRuns,1);
finalLogdetQ = zeros(nRuns,1);
finalEncN = zeros(nRuns,1);
finalVertexMean = zeros(nRuns,1);
finalVertexMax = zeros(nRuns,1);
finalEtaOpt = zeros(nRuns,1);
finalKappa = zeros(nRuns,1);
finalTotal = zeros(nRuns,1);
for ir = 1:nRuns
    r = runs(ir); h = r.history;
    condition{ir}=r.condition; group{ir}=r.group;
    Kcol(ir)=r.K; pcol(ir)=r.p; SNRcol(ir)=r.SNR_dB;
    gammaCol(ir)=r.gamma_enc; repeatCol(ir)=r.repeat;
    dataSeedCol(ir)=r.data_seed; trainSeedCol(ir)=r.training_seed;
    measuredSNRCol(ir)=r.measured_snr_db; wallCol(ir)=r.wall_clock_s;
    finalTV(ir)=h.tv(end); finalVolRatio(ir)=h.volume_ratio(end);
    finalLogdetQ(ir)=h.logdetQ(end); finalEncN(ir)=h.enc_N(end);
    finalVertexMean(ir)=h.vertex_error_mean(end);
    finalVertexMax(ir)=h.vertex_error_max(end);
    finalEtaOpt(ir)=h.eta_opt_proxy(end); finalTotal(ir)=h.total(end);
    finalKappa(ir)=h.kappa(end);
end
runSummary = table(condition,group,Kcol,pcol,SNRcol,gammaCol,repeatCol, ...
    dataSeedCol,trainSeedCol,measuredSNRCol,wallCol,finalTV,finalVolRatio, ...
    finalLogdetQ,finalEncN,finalVertexMean,finalVertexMax,finalEtaOpt,finalKappa,finalTotal, ...
    'VariableNames',{'condition','group','K','p','SNR_dB','gamma_enc','repeat', ...
    'data_seed','training_seed','measured_SNR_dB','wall_clock_s','final_TV', ...
    'final_volume_ratio','final_logdetQ','final_enc_N','final_vertex_error_mean', ...
    'final_vertex_error_max','final_eta_opt_proxy','final_kappa','final_total'});
writetable(runSummary,fullfile(outDir,'E1_run_summary.csv'));

%% ====================== CONFIGURATION-LEVEL SUMMARY ==================
labels = configRows(:,1);
nLabels = numel(labels);
configName = labels;
configGroup = configRows(:,5);
configK = cell2mat(configRows(:,2));
configSNR = cell2mat(configRows(:,3));
configGamma = cell2mat(configRows(:,4));
nRepCol = zeros(nLabels,1);
meanTV = nan(nLabels,1); stdTV = nan(nLabels,1);
meanVolRatio = nan(nLabels,1); stdVolRatio = nan(nLabels,1);
meanEncN = nan(nLabels,1); stdEncN = nan(nLabels,1);
meanVertex = nan(nLabels,1); stdVertex = nan(nLabels,1);
meanTime = nan(nLabels,1); stdTime = nan(nLabels,1);
meanKappa = nan(nLabels,1); stdKappa = nan(nLabels,1);
for ic = 1:nLabels
    idx = strcmp(runSummary.condition,labels{ic});
    nRepCol(ic)=sum(idx);
    meanTV(ic)=mean(runSummary.final_TV(idx),'omitnan'); stdTV(ic)=std(runSummary.final_TV(idx),'omitnan');
    meanVolRatio(ic)=mean(runSummary.final_volume_ratio(idx),'omitnan');
    stdVolRatio(ic)=std(runSummary.final_volume_ratio(idx),'omitnan');
    meanEncN(ic)=mean(runSummary.final_enc_N(idx),'omitnan'); stdEncN(ic)=std(runSummary.final_enc_N(idx),'omitnan');
    meanVertex(ic)=mean(runSummary.final_vertex_error_mean(idx),'omitnan');
    stdVertex(ic)=std(runSummary.final_vertex_error_mean(idx),'omitnan');
    meanTime(ic)=mean(runSummary.wall_clock_s(idx),'omitnan'); stdTime(ic)=std(runSummary.wall_clock_s(idx),'omitnan');
    meanKappa(ic)=mean(runSummary.final_kappa(idx),'omitnan'); stdKappa(ic)=std(runSummary.final_kappa(idx),'omitnan');
end
configSummary = table(configName,configGroup,configK,configSNR,configGamma,nRepCol, ...
    meanTV,stdTV,meanVolRatio,stdVolRatio,meanEncN,stdEncN,meanVertex,stdVertex, ...
    meanTime,stdTime,meanKappa,stdKappa, ...
    'VariableNames',{'condition','group','K','SNR_dB','gamma_enc','n_repeats', ...
    'TV_mean','TV_std','volume_ratio_mean','volume_ratio_std','enc_N_mean', ...
    'enc_N_std','vertex_error_mean','vertex_error_std','time_mean_s','time_std_s', ...
    'kappa_mean','kappa_std'});
writetable(configSummary,fullfile(outDir,'E1_config_summary.csv'));

%% ====================== FIGURE A: SIX LOSS COMPONENTS ================
% Required SI Figure A: K=5, SNR=30 dB, default gamma_enc=10.
figA = figure('Color','w','Position',[60 60 1350 820]);
lossFields = {'recon','vol','nonneg','sumone','eq','enclose'};
lossTitles = {'Reconstruction','Volume','Nonnegativity', ...
    'Sum-to-one','Equality','Enclosure'};
idxA = find(strcmp({runs.condition},'K5_SNR30'));
if numel(idxA) ~= cfg.nRepeats
    error('Figure A requires exactly %d K5_SNR30 runs; found %d.',cfg.nRepeats,numel(idxA));
end
for k = 1:6
    ax = subplot(2,3,k); hold(ax,'on');
    values = zeros(numel(runs(idxA(1)).history.iteration),numel(idxA));
    for j = 1:numel(idxA)
        h = runs(idxA(j)).history;
        y = max(h.(lossFields{k}),1e-16);
        values(:,j)=y(:);
        semilogy(ax,h.iteration,y,'Color',[0.72 0.76 0.82],'LineWidth',0.8,'HandleVisibility','off');
    end
    it = runs(idxA(1)).history.iteration;
    semilogy(ax,it,mean(values,2,'omitnan'),'r-','LineWidth',2.0,'DisplayName','Mean over repeats');
    xline(ax,cfg.WARM_UP,'k--','LineWidth',1.1,'HandleVisibility','off');
    title(ax,lossTitles{k});
    xlabel(ax,'Adam iteration'); ylabel(ax,'Loss (log scale)');
    grid(ax,'on'); box(ax,'on');
    if k==1
        legend(ax,{'Mean over repeats'}, ...
            'Location','best','FontSize',8);
    end
end
sgtitle('E1 Figure A: Objective-component trajectories (K=5, SNR=30 dB, 20 repeats)');
save_figure_pair_e1(figA,outDir,'E1_FigA_loss_components');

%% ====================== FIGURE B: TV AND VOLUME TRAJECTORIES ==========
% Required SI Figure B: 20 individual trajectories plus mean.
figB = figure('Color','w','Position',[80 80 1120 560]);
tvMat = zeros(numel(runs(idxA(1)).history.iteration),numel(idxA));
vrMat = zeros(size(tvMat));
for j = 1:numel(idxA)
    h = runs(idxA(j)).history;
    tvMat(:,j)=h.tv(:);
    vrMat(:,j)=h.volume_ratio(:);
end
it = runs(idxA(1)).history.iteration;
yyaxis left; hold on;
for j=1:size(tvMat,2)
    plot(it,tvMat(:,j),'Color',[0.72 0.78 0.88],'LineWidth',0.8);
end
plot(it,mean(tvMat,2,'omitnan'),'b-','LineWidth',2.2);
ylabel('TV(\hat{S}_t,S_T)');
yyaxis right; hold on;
for j=1:size(vrMat,2)
    plot(it,vrMat(:,j),'Color',[0.76 0.86 0.76],'LineWidth',0.8);
end
plot(it,mean(vrMat,2,'omitnan'),'Color',[0.10 0.55 0.20],'LineWidth',2.2);
yline(1,'k:','LineWidth',1);
ylabel('Vol(\hat{S}_t) / V_T');
xline(cfg.WARM_UP,'k--','LineWidth',1.1);
xlabel('Adam iteration');
title('E1 Figure B: TV and simplex-volume ratio (K=5, SNR=30 dB)');
grid on; box on;
save_figure_pair_e1(figB,outDir,'E1_FigB_tv_volume_trajectory');

%% ====================== FIGURE C: ENCLOSURE UNDERWEIGHT CONTROL =======
% Additional diagnostic for gamma_enc=10 versus gamma_enc=2.5.
figC = figure('Color','w','Position',[80 80 1250 520]);
idxUnder = find(strcmp({runs.condition},'K5_SNR30_gammaEnc_quarter'));
idxDefault = idxA;
if numel(idxUnder) ~= cfg.nRepeats
    error('Expected %d gamma_enc-underweight runs; found %d.',cfg.nRepeats,numel(idxUnder));
end

subplot(1,2,1); hold on;
for j=1:numel(idxDefault)
    h=runs(idxDefault(j)).history;
    plot(h.iteration,h.tv,'Color',[0.72 0.78 0.88],'LineWidth',0.7,'HandleVisibility','off');
end
for j=1:numel(idxUnder)
    h=runs(idxUnder(j)).history;
    plot(h.iteration,h.tv,'Color',[0.92 0.75 0.68],'LineWidth',0.7,'HandleVisibility','off');
end
h0=runs(idxDefault(1)).history; h1=runs(idxUnder(1)).history;
% Histories are stored as structures; assemble means explicitly.
tvDefault=zeros(numel(h0.iteration),numel(idxDefault));
tvUnder=zeros(numel(h1.iteration),numel(idxUnder));
for j=1:numel(idxDefault), tvDefault(:,j)=runs(idxDefault(j)).history.tv; end
for j=1:numel(idxUnder), tvUnder(:,j)=runs(idxUnder(j)).history.tv; end
plot(h0.iteration,mean(tvDefault,2,'omitnan'),'b-','LineWidth',2.2,'DisplayName','gamma_{enc}=10 mean');
plot(h1.iteration,mean(tvUnder,2,'omitnan'),'r-','LineWidth',2.2,'DisplayName','gamma_{enc}=2.5 mean');
xline(cfg.WARM_UP,'k--','HandleVisibility','off');
xlabel('Adam iteration'); ylabel('TV'); title('TV trajectory');
legend('Location','best');
grid on; box on;

subplot(1,2,2); hold on;
vrDefault=zeros(numel(h0.iteration),numel(idxDefault));
vrUnder=zeros(numel(h1.iteration),numel(idxUnder));
for j=1:numel(idxDefault), vrDefault(:,j)=runs(idxDefault(j)).history.volume_ratio; end
for j=1:numel(idxUnder), vrUnder(:,j)=runs(idxUnder(j)).history.volume_ratio; end
plot(h0.iteration,mean(vrDefault,2,'omitnan'),'b-','LineWidth',2.2,'DisplayName','gamma_{enc}=10');
plot(h1.iteration,mean(vrUnder,2,'omitnan'),'r-','LineWidth',2.2,'DisplayName','gamma_{enc}=2.5');
xline(cfg.WARM_UP,'k--','HandleVisibility','off');
yline(1,'k:','HandleVisibility','off');
xlabel('Adam iteration'); ylabel('Vol(\hat{S}_t) / V_T');
title('Simplex-volume ratio');
legend({'\gamma_{enc}=10','\gamma_{enc}=2.5'},'Location','best');
grid on; box on;
sgtitle('E1 mechanism control: enclosure-weight underweighting');
save_figure_pair_e1(figC,outDir,'E1_FigC_gammaEnc_underweight');

%% ====================== SAVE FORMAL RESULTS ===========================
save(fullfile(outDir,'E1_formal_results.mat'), ...
    'cfg','configRows','runs','checkpointTable','runSummary','configSummary','-v7.3');

fprintf('\n============================================================\n');
fprintf('FORMAL E1 COMPLETED: %d runs, %d configurations.\n',nRuns,nConfigs);
fprintf('Results directory: %s\n',outDir);
fprintf('============================================================\n');

%% ====================== LOCAL PLOTTING HELPER ========================
function save_figure_pair_e1(fig,outDir,baseName)
pngFile=fullfile(outDir,[baseName '.png']);
svgFile=fullfile(outDir,[baseName '.svg']);
if exist('exportgraphics','file')
    exportgraphics(fig,pngFile,'Resolution',300);
else
    set(fig,'PaperPositionMode','auto');
    print(fig,pngFile,'-dpng','-r300');
end
print(fig,svgFile,'-dsvg');
end
