%% RECOVER_E5_MISSING_RUNS -- resume only missing E5 runs into a NEW folder.
% This recovery driver imports the existing E5_formal_checkpoint.mat,
% preserves every saved record/vertex, runs only run_id entries absent from
% that checkpoint, and writes the combined complete dataset to a new folder.
% The original checkpoint is read-only and is never overwritten.
%
% Confirm source_checkpoint below points to the original E5 output folder.
% Required on MATLAB path: VCA.m, dataProj.m, quadProg1.m and the three
% e5_*_memory.m estimators. Windows MATLAB is required for memory().
clear; clc; close all;

%% --------- PATHS: ORIGINAL CHECKPOINT -> NEW RECOVERY FOLDER ---------
script_dir=fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir=pwd; end

% Original checkpoint created by the previous formal E5 run.
source_checkpoint=fullfile(script_dir, ...
    'E5_output_formal_E4synthetic','E5_formal_checkpoint.mat');
if ~isfile(source_checkpoint)
    source_checkpoint=fullfile(pwd, ...
        'E5_output_formal_E4synthetic','E5_formal_checkpoint.mat');
end

% All recovered/combined outputs are written here; original folder untouched.
recovery_out_dir=fullfile(script_dir, ...
    'E5_output_formal_E4synthetic_recovered');

%% --------- EXPERIMENT CONFIGURATION (must match original E5) ---------
cfg=struct();
cfg.MODE='formal';
cfg.REPLOT_SOURCE='formal';
cfg.OUT_DIR=recovery_out_dir;
cfg.RESUME=true;
cfg.MEASURE_MEMORY=true;
cfg.DATA_PROTOCOL='E4_orthonormal_Dirichlet1';
cfg.NOISE_PROTOCOL='E4_paired_gaussian_FroSNR';
cfg.DATA_SEED_BASE=41000;
cfg.GEN_BLOCK=100000;
cfg.DEEP_LR=1e-3;cfg.DEEP_VOL=0.01;cfg.DEEP_NONNEG=5;
cfg.DEEP_EQ=80;cfg.DEEP_SUMONE=2;cfg.DEEP_ENCLOSE=10;
cfg.DEEP_BATCH=4096; cfg.DEEP_WARM_UP=600;
cfg.DEEP_COORD_MODE='index1d';
cfg.VCA_INIT_SAMPLES=200000;
cfg.MEMORY_BASELINE_SAMPLES=7;
cfg.MEMORY_CHECKPOINT_DEEP=100;
cfg.MEMORY_CHECKPOINT_MVSA=1;
cfg.MEMORY_CHECKPOINT_SOFTML=1;
cfg.TV_BATCH=50000; cfg.TV_MIN_SAMPLES=200000;
cfg.TV_MAX_SAMPLES=2000000;
cfg.TV_RELATIVE_CI=0.1;cfg.TV_ABSOLUTE_CI=1e-5;
cfg.TV_MEMBERSHIP_TOL=1e-8;
cfg.TV_MC_PROTOCOL='E4_symmetric_two_direction_adaptive_v1';
cfg.TV_COORD_PROTOCOL='E4_common_Y_whitened_work_v2_synthetic';
cfg.TV_WHITEN_REG=1e-10;
cfg.SELF_TEST_TV=true;

cfg.K_VALUES=[3 5];cfg.N_VALUES=[1e4 1e6 1e7];
cfg.NOISE_MODES={'clean','snr30'};
cfg.REPEATS=10;
cfg.DEEP_ITERS=[250 500 1500 5000 15000];
cfg.MVSA_ITERS=[1 2 4 8];cfg.MVSA_TOLS=[1e-2 1e-3];
cfg.SOFTML_ITERS=[1 5 20 100];

%% --------- PRECONDITIONS ---------
here=script_dir; addpath(here,'-begin');
required={'e5_deep_mvsa_invflow_memory', ...
    'e5_mvsa_memory','e5_softml_memory', ...
    'VCA','quadProg1','dataProj'};
for ii=1:numel(required)
    if exist(required{ii},'file')~=2
        error('Required dependency missing from MATLAB path: %s',required{ii});
    end
end
if ~cfg.MEASURE_MEMORY
    error('The E5 recovery driver requires enabled memory monitoring.');
end
if ~ispc
    error('Peak local workspace memory monitoring requires Windows MATLAB memory().');
end
if ~isfile(source_checkpoint)
    error(['Original checkpoint not found: %s\n' ...
        'Place the original E5_formal_checkpoint.mat in the original ' ...
        'E5_output_formal_E4synthetic folder, or edit source_checkpoint.'], ...
        source_checkpoint);
end
if ~exist(cfg.OUT_DIR,'dir'), mkdir(cfg.OUT_DIR); end
if cfg.SELF_TEST_TV, e5_tv_selftest(cfg); end

run_mat=fullfile(cfg.OUT_DIR,'E5_formal_checkpoint.mat');
run_csv=fullfile(cfg.OUT_DIR,'E5_run_summary.csv');
recovery_log=fullfile(cfg.OUT_DIR,'E5_recovery_log.txt');
run_failure_log=fullfile(cfg.OUT_DIR,'E5_run_failures.log');

%% --------- LOAD EXISTING CHECKPOINT OR PREVIOUS RECOVERY ---------
if ~cfg.RESUME
    error('cfg.RESUME must remain true for this recovery task.');
end

if isfile(run_mat)
    % A previous recovery attempt exists: resume from the NEW folder.
    loaded=load(run_mat,'records','vertices','config');
    checkpoint_source='existing recovery checkpoint';
    if ~isfield(loaded,'config') || ~e5_config_compatible(loaded.config,cfg)
        error('The recovery checkpoint configuration does not match this script.');
    end
else
    % First recovery run: import the original checkpoint without modifying it.
    loaded=load(source_checkpoint,'records','vertices','config');
    checkpoint_source=source_checkpoint;
    if ~isfield(loaded,'config') || ~e5_config_compatible(loaded.config,cfg)
        error(['Original checkpoint configuration does not match this recovery ' ...
            'script (apart from OUT_DIR). Do not run until settings are reconciled.']);
    end
end

if ~isfield(loaded,'records') || ~isfield(loaded,'vertices')
    error('Checkpoint must contain both records and vertices.');
end
records=loaded.records;
vertices=loaded.vertices;
if numel(records)~=numel(vertices)
    error('Checkpoint inconsistency: %d records but %d vertex entries.', ...
        numel(records),numel(vertices));
end
if isempty(records)
    error('The source checkpoint contains no saved E5 records.');
end
saved_ids={records.run_id};
if numel(unique(saved_ids))~=numel(saved_ids)
    error('Checkpoint contains duplicate run_id values; refusing unsafe merge.');
end

% This exact row was verified in the supplied checkpoint and must be retained.
preserved_key=sprintf('%s_K3_N10000_clean_R01_DeepMVSA_T250',cfg.DATA_PROTOCOL);
preserved_idx=find(strcmp(saved_ids,preserved_key),1);
if isempty(preserved_idx)
    error('Expected saved DeepMVSA T250 row was not found in the checkpoint.');
end
if ~strcmp(records(preserved_idx).status,'ok')
    error('Saved DeepMVSA T250 row exists but status is %s, not ok.', ...
        records(preserved_idx).status);
end

% The output checkpoint uses the NEW output path; source checkpoint remains intact.
config=cfg; %#ok<NASGU>
save(run_mat,'records','vertices','config','-v7.3');
% Recreate the CSV from the MAT records before running anything. This restores
% rows that were in MAT but never made it into the old CSV.
writetable(e5_records_to_table(records),run_csv);

budgets=make_e5_budgets(cfg);
expected_ids=e5_expected_run_ids(cfg);
missing_before=expected_ids(~ismember(expected_ids,saved_ids));

fid=fopen(recovery_log,'w');
if fid>=0
    fprintf(fid,'E5 recovery started: %s\n',datestr(now,31));
    fprintf(fid,'Loaded checkpoint: %s\n',checkpoint_source);
    fprintf(fid,'New output folder: %s\n',cfg.OUT_DIR);
    fprintf(fid,'Existing records imported: %d\n',numel(records));
    fprintf(fid,'Expected total records: %d\n',numel(expected_ids));
    fprintf(fid,'Missing run_id count before recovery: %d\n',numel(missing_before));
    fprintf(fid,'Preserved existing row: %s\n',preserved_key);
    for q=1:numel(missing_before)
        fprintf(fid,'MISSING %s\n',missing_before{q});
    end
    fclose(fid);
end

fprintf('E5 recovery mode: %s\n',cfg.MODE);
fprintf('Imported existing records: %d\n',numel(records));
fprintf('Expected total records: %d\n',numel(expected_ids));
fprintf('Missing runs to execute: %d\n',numel(missing_before));
fprintf('Preserved DeepMVSA T250: runtime=%.6fs, TV=%.9g, peak=%.6f MB\n', ...
    records(preserved_idx).runtime_s,records(preserved_idx).tv, ...
    records(preserved_idx).peak_local_workspace_MB);
fprintf('New output folder: %s\n',cfg.OUT_DIR);

%% --------- E4 SYNTHETIC BENCHMARK: RUN MISSING RUN_IDS ONLY ---------
for iK=1:numel(cfg.K_VALUES)
    K=cfg.K_VALUES(iK);p=K+1;
    for iN=1:numel(cfg.N_VALUES)
        N=cfg.N_VALUES(iN);
        for ir=1:cfg.REPEATS
            scene_seed=cfg.DATA_SEED_BASE + 100000*K + 1000*iN + ir;
            rng(scene_seed,'twister');
            [Mtrue,~]=qr(randn(p,p),0);
            if rank(Mtrue(:,2:end)-Mtrue(:,1),1e-10)~=K
                error('E4 synthetic true simplex unexpectedly degenerate.');
            end
            for inoise=1:numel(cfg.NOISE_MODES)
                noise=cfg.NOISE_MODES{inoise};
                scene=struct('K',K,'N',N,'noise',noise,'seed',scene_seed);
                fprintf('\n[E5 recovery] K=%d N=%d %s rep=%d/%d\n', ...
                    K,N,noise,ir,cfg.REPEATS);

                % Identify precisely which budgets are absent for this scene.
                scene_missing={};
                for jb=1:numel(budgets)
                    key=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
                        cfg.DATA_PROTOCOL,K,N,noise,ir, ...
                        budgets(jb).method,budgets(jb).label);
                    if ~any(strcmp({records.run_id},key))
                        scene_missing{end+1}=key; %#ok<AGROW>
                    end
                end
                if isempty(scene_missing)
                    fprintf('  All 17 budget records already present; skipping scene.\n');
                    continue;
                end

                % Rebuild the identical synthetic scene only when it has missing runs.
                try
                    [Y,scene_meta]=e5_generate_dataset(Mtrue,N,noise,scene_seed,cfg);
                    if any(~isfinite(Y(:))) || ~isequal(size(Y),[p,N])
                        error('Synthetic scene invalid.');
                    end
                    tvmap=e5_common_e4_workmap(Y,p,cfg.GEN_BLOCK,cfg.TV_WHITEN_REG);
                    Mtrue_tv=e5_to_e4_work(Mtrue,tvmap);
                    trueRcond=rcond(Mtrue_tv);
                    if ~isfinite(trueRcond) || trueRcond<1e-12
                        error('E4 synthetic true simplex is singular AFTER the TV work-map: rcond=%.3e.',trueRcond);
                    end
                catch ME
                    e5_log_recovery_error(recovery_log, ...
                        sprintf('SCENE K=%d N=%d noise=%s rep=%d seed=%d', ...
                        K,N,noise,ir,scene_seed),ME);
                    warning('E5 scene generation failed; scene skipped: %s',ME.message);
                    continue;
                end

                methods={'DeepMVSA','MVSA','SoftML'};
                for im=1:numel(methods)
                    method=methods{im};
                    method_budget_idx=find(strcmp({budgets.method},method));
                    method_missing=false;
                    for jj=method_budget_idx
                        key=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
                            cfg.DATA_PROTOCOL,K,N,noise,ir,method,budgets(jj).label);
                        if ~any(strcmp({records.run_id},key))
                            method_missing=true;break;
                        end
                    end
                    if ~method_missing, continue; end

                    proj=struct('Yproj',[],'Up',[],'my',[]);
                    if strcmp(method,'SoftML')
                        try
                            [proj.Yproj,proj.Up,proj.my,~]= ...
                                dataProj(Y,p,'proj_type','affine');
                        catch ME
                            e5_log_recovery_error(run_failure_log, ...
                                sprintf('PREPROCESS %s K=%d N=%d noise=%s rep=%d', ...
                                method,K,N,noise,ir),ME);
                            warning('SoftML preprocessing failed for this scene: %s',ME.message);
                            continue;
                        end
                    end

                    for jb=method_budget_idx
                        key=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
                            cfg.DATA_PROTOCOL,K,N,noise,ir,method,budgets(jb).label);
                        if any(strcmp({records.run_id},key))
                            continue; % Preserve every already-saved run; never rerun it.
                        end

                        fprintf('  RUN MISSING: %s %s\n',method,budgets(jb).label);
                        try
                            [r,v]=e5_run_one(Y,Mtrue,Mtrue_tv,tvmap,proj, ...
                                cfg,scene,method,budgets(jb),ir);
                            r.achieved_snr_db=scene_meta.achieved_snr_db;
                        catch ME
                            % Do not abort the other missing budgets in this scene.
                            e5_log_recovery_error(run_failure_log,key,ME);
                            warning('Run %s threw an exception and will remain missing: %s', ...
                                key,ME.message);
                            continue;
                        end

                        % Align field order with imported checkpoint before appending.
                        if ~isempty(records)
                            if ~isequal(sort(fieldnames(records)),sort(fieldnames(r)))
                                error('Record schema mismatch for %s; refusing to corrupt checkpoint.',key);
                            end
                            r=orderfields(r,records);
                            records(end+1)=r; %#ok<SAGROW>
                        else
                            records=r;
                        end
                        vertices{end+1}=v; %#ok<SAGROW>

                        % MAT is authoritative and saved FIRST. CSV failure cannot
                        % interrupt the remaining runs; CSV is rebuilt again at end.
                        config=cfg; %#ok<NASGU>
                        save(run_mat,'records','vertices','config','-v7.3');
                        try
                            writetable(e5_records_to_table(records),run_csv);
                        catch csvME
                            e5_log_recovery_error(run_failure_log, ...
                                sprintf('CSV EXPORT after %s (MAT already saved)',key),csvME);
                            warning('CSV export failed, but MAT checkpoint is safe: %s',csvME.message);
                        end

                        fprintf('    time=%.3fs TV=%.6g [%.6g, %.6g] peak=%.3f MB status=%s\n', ...
                            r.runtime_s,r.tv,r.tv_ci_low,r.tv_ci_high, ...
                            r.peak_local_workspace_MB,r.status);
                    end
                    clear proj;
                end
                clear Y tvmap Mtrue_tv;
            end
        end
    end
end

%% --------- FINALIZE COMPLETE COMBINED DATASET IN THE NEW FOLDER ---------
% Rebuild the CSV from the final MAT checkpoint (including the imported 2024 rows).
writetable(e5_records_to_table(records),run_csv);
save(run_mat,'records','vertices','config','-v7.3');

final_ids={records.run_id};
missing_after=expected_ids(~ismember(expected_ids,final_ids));
if isempty(missing_after)
    fprintf('\nRECOVERY COMPLETE: all %d/%d expected runs are present.\n', ...
        numel(final_ids),numel(expected_ids));
else
    fprintf('\nRECOVERY INCOMPLETE: %d/%d expected runs are present; %d remain missing.\n', ...
        numel(final_ids),numel(expected_ids),numel(missing_after));
    fid=fopen(fullfile(cfg.OUT_DIR,'E5_missing_runs_after_recovery.txt'),'w');
    if fid>=0
        for q=1:numel(missing_after),fprintf(fid,'%s\n',missing_after{q});end
        fclose(fid);
    end
end

% Generate config summary, target-time summary, MAT report data, SVG and PNG.
e5_make_reports(run_csv,cfg.OUT_DIR);
fprintf('\nCombined E5 CSV: %s\n',run_csv);
fprintf('Combined E5 checkpoint: %s\n',run_mat);
fprintf('All recovery outputs: %s\n',cfg.OUT_DIR);

%% --------- Script-local helpers (only estimator algorithms are external) ---------

function tf=e5_config_compatible(saved_cfg,current_cfg)
%E5_CONFIG_COMPATIBLE Compare all experiment settings, ignoring OUT_DIR only.
tf=false;
if ~isstruct(saved_cfg) || ~isstruct(current_cfg), return; end
fs=sort(fieldnames(saved_cfg));
fc=sort(fieldnames(current_cfg));
if ~isequal(fs,fc), return; end
for ii=1:numel(fs)
    name=fs{ii};
    if strcmp(name,'OUT_DIR'), continue; end
    if ~isequaln(saved_cfg.(name),current_cfg.(name)), return; end
end
tf=true;
end

function T=e5_records_to_table(records)
%E5_RECORDS_TO_TABLE Convert scalar struct to one-row table safely.
if isempty(records)
    T=table();
elseif isscalar(records)
    T=struct2table(records,'AsArray',true);
else
    T=struct2table(records);
end
end

function ids=e5_expected_run_ids(cfg)
%E5_EXPECTED_RUN_IDS Enumerate every run_id in the formal E5 design.
budgets=make_e5_budgets(cfg);
nTotal=numel(cfg.K_VALUES)*numel(cfg.N_VALUES)*cfg.REPEATS* ...
    numel(cfg.NOISE_MODES)*numel(budgets);
ids=cell(nTotal,1); q=0;
for iK=1:numel(cfg.K_VALUES)
    K=cfg.K_VALUES(iK);
    for iN=1:numel(cfg.N_VALUES)
        N=cfg.N_VALUES(iN);
        for ir=1:cfg.REPEATS
            for inoise=1:numel(cfg.NOISE_MODES)
                noise=cfg.NOISE_MODES{inoise};
                for jb=1:numel(budgets)
                    q=q+1;
                    ids{q}=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
                        cfg.DATA_PROTOCOL,K,N,noise,ir, ...
                        budgets(jb).method,budgets(jb).label);
                end
            end
        end
    end
end
end

function e5_log_recovery_error(log_path,context,ME)
%E5_LOG_RECOVERY_ERROR Append a per-scene/per-run failure without aborting others.
fid=fopen(log_path,'a');
if fid>=0
    fprintf(fid,'[%s] %s | %s: %s\n',datestr(now,31), ...
        context,ME.identifier,regexprep(ME.message,'[\r\n\t]',' '));
    fclose(fid);
end
end

function budgets=make_e5_budgets(cfg)
budgets=struct('method',{},'label',{},'iter',{},'tol',{});
for T=cfg.DEEP_ITERS
    budgets(end+1)=struct('method','DeepMVSA','label',sprintf('T%d',T), ...
        'iter',T,'tol',NaN); %#ok<AGROW>
end
for T=cfg.MVSA_ITERS
    for tol=cfg.MVSA_TOLS
        budgets(end+1)=struct('method','MVSA', ...
            'label',sprintf('I%d_tol%.0e',T,tol),'iter',T,'tol',tol); %#ok<AGROW>
    end
end
for T=cfg.SOFTML_ITERS
    budgets(end+1)=struct('method','SoftML', ...
        'label',sprintf('I%d',T),'iter',T,'tol',NaN); %#ok<AGROW>
end
end

function [rec,vert] = e5_run_one(Y,Mtrue,Mtrue_tv,tvmap,proj,cfg,scene,method,budget,rep)
%E5_RUN_ONE Single, timed instrumented estimator call for BOTH time and MB.
% Timer brackets whole monitored function call: initialization + optimization
% + recovery. Monitoring is INCLUDED in wall-clock. Dataset generation and
% external SoftML affine dataProj are EXCLUDED (same as uploaded Table-2 code).
% Memory metric is peak_local_workspace_bytes/1e6 (decimal MB).
rec=e5_blank_record();
vert=struct('Mtrue',Mtrue,'Mest',[],'Mtrue_work',Mtrue_tv, ...
    'Mest_work',[],'eval_mean',tvmap.my,'eval_basis',tvmap.Up_sub, ...
    'eval_eigenvalues',tvmap.eigvals,'eval_lambda_reg',tvmap.lambda_reg, ...
    'run_id','');
rec.K=scene.K; rec.p=scene.K+1; rec.N=scene.N; rec.noise=scene.noise;
rec.rep=rep; rec.scene_seed=scene.seed; rec.method=method;
rec.data_protocol=cfg.DATA_PROTOCOL; rec.noise_protocol=cfg.NOISE_PROTOCOL;
rec.budget_iter=budget.iter; rec.tolerance=budget.tol;
rec.budget_id=budget.label;
rec.run_id=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
    cfg.DATA_PROTOCOL,scene.K,scene.N,scene.noise,rep,method,budget.label);
vert.run_id=rec.run_id;
rec.algo_seed=scene.seed+300000+rep*1000;
rec.tv_target=scene.N^(-0.5);
rec.tv_metric='E4_symmetric_projected_uniform_simplex_TV';
rec.tv_coord_protocol=cfg.TV_COORD_PROTOCOL;
rec.tv_mc_protocol=cfg.TV_MC_PROTOCOL;
rec.runtime_protocol='monitored_full_function_call';
rec.status='started';
if strcmp(method,'DeepMVSA')
    warm=min(cfg.DEEP_WARM_UP,max(1,floor(0.4*budget.iter))); % E4: T=1500 -> warm 600
    rec.warmup_iter=warm;
else
    warm=NaN;
end
% Require memory instrumented call, no duplicated second training.
try
    rng(rec.algo_seed,'twister');
    timer=tic;
    switch method
        case 'DeepMVSA'
            [Mest,~,~,~,theta]=e5_deep_mvsa_invflow_memory(Y,scene.K+1, ...
                'spherize','yes','verbose',0, ...
                'MM_ITERS',budget.iter,'WARM_UP',warm, ...
                'LR',cfg.DEEP_LR,'LAMBDA_VOL',cfg.DEEP_VOL, ...
                'LAMBDA_NONNEG',cfg.DEEP_NONNEG,'LAMBDA_EQ',cfg.DEEP_EQ, ...
                'LAMBDA_SUMONE',cfg.DEEP_SUMONE, ...
                'LAMBDA_ENCLOSE',cfg.DEEP_ENCLOSE, ...
                'BATCH_SIZE',cfg.DEEP_BATCH, ...
                'VCA_INIT_SAMPLES',cfg.VCA_INIT_SAMPLES, ...
                'COORD_MODE',cfg.DEEP_COORD_MODE, ...
                'RETURN_FULL_ABUNDANCE',false, ...
                'MEASURE_OPT_MEMORY',cfg.MEASURE_MEMORY, ...
                'MEMORY_BASELINE_SAMPLES',cfg.MEMORY_BASELINE_SAMPLES, ...
                'MEMORY_CHECKPOINT_EVERY',cfg.MEMORY_CHECKPOINT_DEEP);
            st=theta.memory_stats;
        case 'MVSA'
            [Mest,~,~,~,~,st]=e5_mvsa_memory(Y,scene.K+1, ...
                'spherize','yes','verbose',0, ...
                'MM_ITERS',budget.iter,'TOLF',budget.tol, ...
                'MEASURE_OPT_MEMORY',cfg.MEASURE_MEMORY, ...
                'MEMORY_BASELINE_SAMPLES',cfg.MEMORY_BASELINE_SAMPLES, ...
                'MEMORY_CHECKPOINT_EVERY',cfg.MEMORY_CHECKPOINT_MVSA);
        case 'SoftML'
            [Mest,~,omem]=e5_softml_memory(Y,scene.K+1, ...
                'YProj',proj.Yproj,'Up',proj.Up,'my',proj.my, ...
                'MTrue',Mtrue,'MaxIter',budget.iter, ...
                'Gamma',[],'Alpha',[], ...
                'UseConvexHullInit',true,'UseHullGradient',true, ...
                'Seed',rec.algo_seed,'Plot',false,'Verbose',false, ...
                'MEASURE_OPT_MEMORY',cfg.MEASURE_MEMORY, ...
                'MEMORY_BASELINE_SAMPLES',cfg.MEMORY_BASELINE_SAMPLES, ...
                'MEMORY_CHECKPOINT_EVERY',cfg.MEMORY_CHECKPOINT_SOFTML);
            st=omem.memory_stats;
        otherwise
            error('Unknown E5 method: %s',method);
    end
    rec.runtime_s=toc(timer);
    vert.Mest=Mest;
    if ~isequal(size(Mest),size(Mtrue)) || any(~isfinite(Mest(:)))
        error('Estimator returned invalid M of size %s',mat2str(size(Mest)));
    end
    if ~isstruct(st) || ~isfield(st,'peak_local_workspace_bytes')
        error('Instrumented estimator did not return Peak local workspace arrays.');
    end
    rec.peak_local_workspace_bytes=double(st.peak_local_workspace_bytes);
    rec.peak_local_workspace_MB=rec.peak_local_workspace_bytes/1e6;
    if ~isfinite(rec.peak_local_workspace_MB) || rec.peak_local_workspace_MB<0
        error('Invalid Peak local workspace arrays measurement.');
    end
    rec.peak_local_label=st.peak_local_workspace_label;
    rec.local_memory_samples=st.local_samples;
    rec.memory_status='ok';
    rec.status='model_ok';
catch ME
    % A failure never receives a fake finite TV or MB.
    rec.status='model_failed'; rec.error_text=e5_errtext(ME);
    return;
end
% TV is deliberately OUTSIDE the model wall-clock and peak workspace interval.
try
    % Both methods use the SAME E4-style affine work coordinate map.
    % E4: W(p,:) = 1; W = W/sqrt(p) after whitening Up'*(M-my).
    % Off-subspace components are deliberately projected away in BOTH.
    Mest_tv=e5_to_e4_work(Mest,tvmap);
    vert.Mest_work=Mest_tv;
    centered=bsxfun(@minus,double(Mest),tvmap.my);
    off=centered-tvmap.Up_sub*(tvmap.Up_sub'*centered);
    rec.tv_est_out_of_subspace_rel=norm(off,'fro')/max(norm(centered,'fro'),realmin);
    tv=e5_tv_distance(Mtrue_tv,Mest_tv,rec.tv_target,rec.algo_seed+111,cfg);
    rec.tv=tv.tv; rec.tv_ci_low=tv.ci_low; rec.tv_ci_high=tv.ci_high;
    rec.tv_samples=tv.n_samples; rec.tv_samples_each_direction=tv.samples_per_direction;
    rec.target_status=tv.target_status;
    rec.volume_ratio=tv.volume_ratio; rec.tv_status=tv.status;
    if strcmp(tv.status,'ok') || strcmp(tv.status,'degenerate_est')
        rec.status='ok';
    else
        rec.status='tv_invalid';
    end
catch ME
    rec.status='tv_failed'; rec.error_text=e5_errtext(ME);
end
end
function rec=e5_blank_record()
rec=struct('run_id','','method','','K',NaN,'p',NaN,'N',NaN, ...
    'noise','','rep',NaN,'scene_seed',NaN,'algo_seed',NaN, ...
    'data_protocol','','noise_protocol','','budget_id','', ...
    'budget_iter',NaN,'tolerance',NaN,'warmup_iter',NaN, ...
    'runtime_s',NaN,'runtime_protocol','', ...
    'peak_local_workspace_bytes',NaN, ...
    'peak_local_workspace_MB',NaN,'peak_local_label','', ...
    'local_memory_samples',NaN,'memory_status','not_measured', ...
    'tv',NaN,'tv_ci_low',NaN,'tv_ci_high',NaN, ...
    'tv_samples',NaN,'tv_samples_each_direction',NaN, ...
    'tv_target',NaN,'target_status',NaN, ...
    'volume_ratio',NaN,'tv_metric','','tv_coord_protocol','', ...
    'tv_mc_protocol','', ...
    'tv_est_out_of_subspace_rel',NaN,'tv_status','', ...
    'status','','error_text','');
end
function s=e5_errtext(ME)
s=sprintf('%s: %s',ME.identifier,ME.message);
s=regexprep(s,'[\r\n\t]',' ');
if numel(s)>700,s=s(1:700);end
end


function [Y,meta] = e5_generate_dataset(Mtrue,N,noise_mode,seed,cfg)
%E5_GENERATE_DATASET Same E4 v2 synthetic-data protocol, blockwise.
% E4: rng(seed); [Mtrue,~]=qr(randn(p,p),0);
%     G=-log(max(rand(p,N),realmin)); A=G./sum(G,1); Yclean=Mtrue*A;
%     E=randn(size(Yclean)); E=E*norm(Yclean,'fro')/norm(E,'fro');
%     Y=Yclean+E*10^(-snrDb/20).
% Re-run identical RNG states for the paired clean/snr30 arms.
% Two-pass noise construction avoids a second persistent p-by-N array.
[pL,p]=size(Mtrue);
if pL~=p, error('E4 synthetic endmembers must be square p-by-p.'); end
rng(seed,'twister');
[checkM,~]=qr(randn(p,p),0);
if norm(checkM-double(Mtrue),'fro')>1e-11
    error('E4 synthetic seed mismatch between Mtrue and generated scene.');
end
Y=zeros(p,N,'double');
for j=1:cfg.GEN_BLOCK:N
    idx=j:min(j+cfg.GEN_BLOCK-1,N);
    G=-log(max(rand(p,numel(idx)),realmin));
    A=bsxfun(@rdivide,G,sum(G,1));
    Y(:,idx)=double(Mtrue)*A;
end
meta=struct('data_protocol',cfg.DATA_PROTOCOL,'noise_protocol',cfg.NOISE_PROTOCOL, ...
    'scene_seed',seed,'target_snr_db',Inf,'achieved_snr_db',Inf);
if strcmpi(noise_mode,'clean'), return; end
if ~strcmpi(noise_mode,'snr30'), error('Unknown E5 noise mode: %s',noise_mode); end
% E4 draws Gaussian E immediately after its Dirichlet random matrix.
% Save RNG state here; first pass gets its norm and second pass adds noise.
stateBeforeNoise=rng;
signalSq=0; noiseSq=0;
for j=1:cfg.GEN_BLOCK:N
    idx=j:min(j+cfg.GEN_BLOCK-1,N);
    cleanBlock=Y(:,idx); signalSq=signalSq+sum(cleanBlock(:).^2);
end
for j=1:cfg.GEN_BLOCK:N
    cols=min(cfg.GEN_BLOCK,N-j+1);
    R=randn(p,cols); noiseSq=noiseSq+sum(R(:).^2);
end
if ~isfinite(signalSq) || ~isfinite(noiseSq) || noiseSq<=0
    error('E4 Gaussian Frobenius-normalization failed.');
end
noiseScale=sqrt(signalSq/noiseSq)*10^(-30/20);
rng(stateBeforeNoise);
for j=1:cfg.GEN_BLOCK:N
    idx=j:min(j+cfg.GEN_BLOCK-1,N);
    Y(:,idx)=Y(:,idx)+noiseScale*randn(p,numel(idx));
end
meta.target_snr_db=30;
meta.achieved_snr_db=30;
end


function map=e5_common_e4_workmap(Y,p,blockSize,lambda_reg)
%E5_COMMON_E4_WORKMAP Same coordinate convention as E4 e4_to_work().
% E4 maps Z to [C*Up(:,1:K)'*(Z-my);1]/sqrt(p), where
% C=diag(1./sqrt(diag(D)+lambda_reg)). DeepMVSA derives Up/D from the
% top K sample-covariance eigenpairs. The E5 evaluation map is computed
% once on the FULL shared scene, then applied to ALL methods (no leakage
% of method-dependent subspace estimators into a cross-method metric).
% Accumulate covariance in blocks to avoid full-sized double Y copies.
[L,N]=size(Y); K=p-1;
if N<2 || L<K, error('Cannot build E4 work-map for L=%d N=%d K=%d.',L,N,K);end
sy=zeros(L,1); YYt=zeros(L,L);
for j=1:blockSize:N
    ids=j:min(j+blockSize-1,N);
    X=double(Y(:,ids));
    sy=sy+sum(X,2);
    YYt=YYt+X*X';
end
my=sy/double(N);
Cov=YYt/double(N)-my*my';
Cov=(Cov+Cov')/2;
[Vec,vals]=eig(Cov,'vector');
[vals,order]=sort(real(vals),'descend');
if numel(vals)<K || any(~isfinite(vals(1:K)))
    error('E4 TV coordinate map: invalid covariance eigenvalues.');
end
Up_sub=real(Vec(:,order(1:K)));
eigvals=max(vals(1:K),0);
% E4 uses this exact regularization in the model working transform.
scale=1./sqrt(eigvals+lambda_reg);
if any(~isfinite(scale))
    error('E4 TV coordinate map: nonfinite whitening scale.');
end
map=struct('my',my,'Up_sub',Up_sub,'eigvals',eigvals, ...
    'lambda_reg',lambda_reg,'p',p, ...
    'W',(bsxfun(@times,Up_sub',scale))/sqrt(p));
end

function W=e5_to_e4_work(Z,map)
%E5_TO_E4_WORK  Algebraically equivalent to E4's e4_to_work().
if size(Z,1)~=numel(map.my) || size(Z,2)~=map.p
    error('TV work-map input must be L-by-p with p=%d.',map.p);
end
W=[map.W*bsxfun(@minus,double(Z),map.my); ...
    ones(1,size(Z,2))/sqrt(map.p)];
end

function r = e5_tv_distance(Mtrue,Mest,target,seed,cfg)
%E5_TV_DISTANCE E4's SYMMETRIC 2-way MC intersection-volume estimate.
% E4: TV=1-0.5*(Vtrue*p_true_to_est+Vest*p_est_to_true)/max(Vtrue,Vest).
% Same E4 work coordinates, Dirichlet(1) sampling, and barycentric tolerance.
% E5 additions: adaptive MC and conservative simultaneous Wilson 95% CI.
% For Bonferroni 95% joint coverage, each Bernoulli CI is 97.5% (z=2.2414).
r=struct('tv',NaN,'ci_low',NaN,'ci_high',NaN, ...
    'n_samples',0,'samples_per_direction',0,'target_status',-1, ...
    'volume_ratio',NaN,'metric','E4_symmetric_projected_uniform_simplex_TV', ...
    'status','invalid');
if isempty(Mest) || ~isequal(size(Mest),size(Mtrue)) || ...
        any(~isfinite(Mtrue(:))) || any(~isfinite(Mest(:)))
    return;
end
[L,p]=size(Mtrue); K=p-1;
if L~=p || max(abs(Mtrue(p,:)-1/sqrt(p)))>1e-8 || ...
        max(abs(Mest(p,:)-1/sqrt(p)))>1e-8
    r.status='invalid_e4_work_coordinates'; return;
end
V1=e5_simplex_volume(Mtrue); V2=e5_simplex_volume(Mest);
if V1<=0 || ~isfinite(V1)
    r.status='degenerate_true'; return;
end
r.volume_ratio=V2/V1;
if V2<=0 || ~isfinite(V2) || rcond(Mest)<1e-12
    r.tv=1; r.ci_low=1; r.ci_high=1;
    r.target_status=0; r.status='degenerate_est'; return;
end
if rcond(Mtrue)<1e-12
    r.status='degenerate_true'; return;
end
Q1=Mtrue\eye(p); Q2=Mest\eye(p);
stream=RandStream('mt19937ar','Seed',seed);
Ndir=0; inside12=0; inside21=0;
% norminv(0.9875) = 2.241402727604947: 97.5% two-sided CI for each arm.
z=2.241402727604947;
while Ndir<cfg.TV_MAX_SAMPLES
    batch=min(cfg.TV_BATCH,cfg.TV_MAX_SAMPLES-Ndir);
    A=-log(max(rand(stream,p,batch),realmin));
    A=bsxfun(@rdivide,A,sum(A,1));
    bary2=Q2*(Mtrue*A);
    inside12=inside12+sum(all(bary2>=-cfg.TV_MEMBERSHIP_TOL,1));
    B=-log(max(rand(stream,p,batch),realmin));
    B=bsxfun(@rdivide,B,sum(B,1));
    bary1=Q1*(Mest*B);
    inside21=inside21+sum(all(bary1>=-cfg.TV_MEMBERSHIP_TOL,1));
    Ndir=Ndir+batch;
    p12=inside12/Ndir; p21=inside21/Ndir;
    r.tv=max(0,min(1,1-0.5*(V1*p12+V2*p21)/max(V1,V2)));
    if Ndir>=cfg.TV_MIN_SAMPLES
        [lo12,hi12]=wilson_ci(inside12,Ndir,z);
        [lo21,hi21]=wilson_ci(inside21,Ndir,z);
        r.ci_low=max(0,1-0.5*(V1*hi12+V2*hi21)/max(V1,V2));
        r.ci_high=min(1,1-0.5*(V1*lo12+V2*lo21)/max(V1,V2));
        goal=max(cfg.TV_RELATIVE_CI*max(r.tv,target),cfg.TV_ABSOLUTE_CI);
        if (r.ci_high-r.ci_low)/2<=goal, break; end
    end
end
if ~isfinite(r.ci_low) || ~isfinite(r.ci_high)
    [lo12,hi12]=wilson_ci(inside12,Ndir,z);
    [lo21,hi21]=wilson_ci(inside21,Ndir,z);
    r.ci_low=max(0,1-0.5*(V1*hi12+V2*hi21)/max(V1,V2));
    r.ci_high=min(1,1-0.5*(V1*lo12+V2*lo21)/max(V1,V2));
end
r.n_samples=2*Ndir;  % BOTH directions combined
r.samples_per_direction=Ndir;
r.status='ok';
if r.ci_high<=target, r.target_status=1;
elseif r.ci_low>target, r.target_status=0;
else, r.target_status=-1;
end
end

function V=e5_simplex_volume(M)
%E5_SIMPLEX_VOLUME Exactly E4's singular-value simplex-volume formula.
p=size(M,2);
E=M(:,2:p)-M(:,1);
sv=svd(E,'econ');
V=prod(sv)/factorial(p-1);
end


function [lo,hi]=wilson_ci(x,n,z)
p=x/n; d=1+z^2/n;
mid=(p+z^2/(2*n))/d;
half=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/d;
lo=max(0,mid-half); hi=min(1,mid+half);
end


function e5_tv_selftest(cfg)
%E5_TV_SELFTEST Analytic references, E4 work-map equivalence, and E4 data synthesis.
K=3;p=K+1;
M=[zeros(K,1),eye(K); ones(1,p)/sqrt(p)];
c=mean(M,2);
r0=e5_tv_distance(M,M,0.01,123,cfg);
if ~isfinite(r0.tv) || r0.tv>0.001
    error('E5 TV self-test failed: identical simplices TV must be zero.');
end
small=bsxfun(@plus,0.5*bsxfun(@minus,M,c),c);
r1=e5_tv_distance(M,small,0.01,456,cfg);
expected=1-0.5^K;
if ~isfinite(r1.tv) || abs(r1.tv-expected)>0.02
    error('E5 TV self-test failed: expected %.6g, observed %.6g.',expected,r1.tv);
end
large=bsxfun(@plus,2*bsxfun(@minus,M,c),c);
r2=e5_tv_distance(M,large,0.01,789,cfg);
if ~isfinite(r2.tv) || abs(r2.tv-expected)>0.02
    error('E5 TV self-test failed: encompassing simplex expected %.6g.',expected);
end
% Check a FULL Y-derived E4 work map, including scale and homogeneous row.
rng(8024,'twister');
L=6; K=3; p=4; V=randn(L,p);
A=-log(max(rand(p,1200),realmin)); A=bsxfun(@rdivide,A,sum(A,1));
map=e5_common_e4_workmap(V*A,p,217,cfg.TV_WHITEN_REG);
W=e5_to_e4_work(V,map);
C=diag(1./sqrt(map.eigvals+map.lambda_reg));
Wref=C*map.Up_sub'*bsxfun(@minus,V,map.my);
Wref(p,:)=1; Wref=Wref/sqrt(p);
if norm(W-Wref,'fro')>1e-11
    error('E5 TV self-test failed: not equivalent to E4 e4_to_work.');
end
% A component perpendicular to E4's data subspace must be projected out
% equally for all methods, including in the presence of noise.
Z=null(map.Up_sub');
if ~isempty(Z)
    Woff=e5_to_e4_work(V+0.25*Z(:,1)*ones(1,p),map);
    if norm(Woff-W,'fro')>1e-10
        error('E5 TV self-test failed: off-subspace projection mismatch.');
    end
end
% Verify E4 synthetic protocol against the original unchunked formula.
seed=61021; n=1027;
rng(seed,'twister'); [Q,~]=qr(randn(p,p),0);
G=-log(max(rand(p,n),realmin)); A=bsxfun(@rdivide,G,sum(G,1));
Yref=Q*A; noise=randn(size(Yref));
noise=noise*norm(Yref,'fro')/norm(noise,'fro');
[Ye4clean,~]=e5_generate_dataset(Q,n,'clean',seed,cfg);
[Ye4noise,~]=e5_generate_dataset(Q,n,'snr30',seed,cfg);
if norm(Ye4clean-Yref,'fro')/max(norm(Yref,'fro'),eps)>1e-12 || ...
        norm(Ye4noise-(Yref+noise*10^(-30/20)),'fro') / ...
        max(norm(Yref,'fro'),eps)>1e-12
    error('E5 data self-test failed: generation differs from E4 v2.');
end
fprintf('E5 self-test passed: E4 synthesis, E4 work coordinates, symmetric TV.\n');
end


function e5_make_reports(run_csv,out_dir)
%E5_MAKE_REPORTS Read saved E5 runs; no model calls; vector SVG and PNG.
% E5 Figure I: log-log wall-clock vs symmetric E4 TV, per noise mode.
if ~isfile(run_csv),error('E5 run CSV does not exist: %s',run_csv);end
T=readtable(run_csv,'TextType','string');
if ~ismember('tv_coord_protocol',T.Properties.VariableNames)
    error('E5 CSV lacks tv_coord_protocol: refusing to label old TV as E4-aligned.');
end
if any(T.tv_coord_protocol ~= "E4_common_Y_whitened_work_v2_synthetic")
    error('E5 CSV contains older or mixed TV evaluation protocols.');
end
if any(T.data_protocol ~= "E4_orthonormal_Dirichlet1")
    error('E5 CSV contains non-E4 data protocols.');
end
planned_repeats=NaN;
checkpoint=fullfile(out_dir,'E5_formal_checkpoint.mat');
if isfile(checkpoint)
    cc=load(checkpoint,'config');
    if isfield(cc,'config') && isfield(cc.config,'REPEATS')
        planned_repeats=cc.config.REPEATS;
    end
end
if ~exist(out_dir,'dir'),mkdir(out_dir);end
ok=(T.status=="ok") & isfinite(T.runtime_s) & T.runtime_s>0 & isfinite(T.tv);
T=T(ok,:);
if isempty(T),warning('No valid completed E5 runs to report.');return;end
keys=strcat(string(T.K),"|",string(T.N),"|",T.noise,"|",T.method,"|",T.budget_id);
[uniq,~,grp]=unique(keys,'stable');
S=table();
for g=1:numel(uniq)
    gidx=find(grp==g); tr=T(gidx,:);
    row=table();
    row.K=tr.K(1);row.N=tr.N(1);row.noise=tr.noise(1);
    row.method=tr.method(1);row.budget_id=tr.budget_id(1);
    row.budget_iter=tr.budget_iter(1);row.tolerance=tr.tolerance(1);
    row.n_runs=height(tr);
    [row.time_mean_s,row.time_sd_s,row.time_ci95_half_s]=e5_mean_ci(tr.runtime_s);
    [row.tv_mean,row.tv_sd,row.tv_ci95_half]=e5_mean_ci(tr.tv);
    [row.peak_local_workspace_mean_MB,row.peak_local_workspace_sd_MB, ...
        row.peak_local_workspace_ci95_half_MB]=e5_mean_ci(tr.peak_local_workspace_MB);
    row.n_memory_valid=sum(isfinite(tr.peak_local_workspace_MB));
    row.tv_target=tr.tv_target(1);
    row.target_confident_reached_fraction=mean(tr.target_status==1);
    row.pareto=false;
    if isempty(S),S=row;else,S=[S;row];end %#ok<AGROW>
end
% Non-dominated mean points: any earlier/equal time with lower/equal TV
% dominates the current one (strict inequality on at least one dimension).
allscene=strcat(string(S.K),"|",string(S.N),"|",S.noise,"|",S.method);
scenes=unique(allscene,'stable');
for gg=1:numel(scenes)
    ii=find(allscene==scenes(gg));
    for j=ii(:)'
        domination=(S.time_mean_s(ii)<=S.time_mean_s(j)) & ...
            (S.tv_mean(ii)<=S.tv_mean(j)) & ...
            ((S.time_mean_s(ii)<S.time_mean_s(j)) | (S.tv_mean(ii)<S.tv_mean(j)));
        S.pareto(j)=~any(domination);
    end
end
writetable(S,fullfile(out_dir,'E5_config_summary.csv'));
% First *confidently* reached TV <= N^-0.5 per REP and METHOD, not across
% average curves. Not-reached repeats stay explicit, not imputed.
Tkey=strcat(string(T.K),"|",string(T.N),"|",T.noise,"|",T.method);
Ukey=unique(Tkey,'stable');
R=table();
for u=1:numel(Ukey)
    ii=find(Tkey==Ukey(u)); tr=T(ii,:);
    repids=unique(tr.rep); earliest=NaN(numel(repids),1);
    for j=1:numel(repids)
        sub=tr(tr.rep==repids(j) & tr.target_status==1,:);
        if ~isempty(sub),earliest(j)=min(sub.runtime_s);end
    end
    good=earliest(isfinite(earliest));
    row=table();row.K=tr.K(1);row.N=tr.N(1);
    row.noise=tr.noise(1);row.method=tr.method(1);
    row.tv_target=tr.tv_target(1);
    row.n_repeats_observed=numel(repids);row.n_repeats_reached=numel(good);
    if isfinite(planned_repeats)
        row.n_repeats_planned=planned_repeats;
    else
        row.n_repeats_planned=numel(repids);
    end
    row.reach_fraction=numel(good)/row.n_repeats_planned;
    [row.earliest_time_mean_s,row.earliest_time_sd_s, ...
        row.earliest_time_ci95_half_s]=e5_mean_ci(good);
    if isempty(good),row.earliest_time_median_s=NaN;
    else,row.earliest_time_median_s=median(good);end
    if isempty(R),R=row;else,R=[R;row];end %#ok<AGROW>
end
writetable(R,fullfile(out_dir,'E5_target_time_summary.csv'));
% Materialized summary MAT is small: no Y, no full abundance maps.
save(fullfile(out_dir,'E5_reports_data.mat'),'S','R','-v7');
colors=[0.10 0.38 0.78;0.88 0.43 0.15;0.06 0.58 0.40];
methods=["DeepMVSA","MVSA","SoftML"];
noises=unique(S.noise,'stable');
Ks=unique(S.K);Ns=unique(S.N);
for inoise=1:numel(noises)
    fig=figure('Color','w','Position',[60 60 1500 790],'Visible','off');
    til=tiledlayout(numel(Ks),numel(Ns),'TileSpacing','compact','Padding','compact');
    for ik=1:numel(Ks)
        for in=1:numel(Ns)
            ax=nexttile(til);hold(ax,'on');box(ax,'on');grid(ax,'on');
            slice=S(S.K==Ks(ik) & S.N==Ns(in) & S.noise==noises(inoise),:);
            for im=1:numel(methods)
                d=slice(slice.method==methods(im),:);
                if isempty(d),continue;end
                xx=d.time_mean_s; yy=d.tv_mean;
                % A zero-count TV is a censored MC estimate for log plotting.
                yyplot=max(yy,1e-6);
                plot(ax,xx,yyplot,'o','Color',colors(im,:), ...
                    'MarkerFaceColor','w','MarkerSize',4,'HandleVisibility','off');
                front=d(d.pareto,:);
                [xf,order]=sort(front.time_mean_s);
                yf=max(front.tv_mean(order),1e-6);
                plot(ax,xf,yf,'-o','LineWidth',1.6, ...
                    'Color',colors(im,:),'MarkerFaceColor',colors(im,:), ...
                    'MarkerSize',5,'DisplayName',char(methods(im)));
                % Mean repeat-level TV uncertainty (t CI); MC CI stored
                % separately in E5_run_summary.csv.
                for q=1:numel(xf)
                    er=max(front.tv_ci95_half(order(q)),0);
                    if ~isfinite(er),continue;end
                    hi=max(yf(q)+er,1e-8);lo=max(yf(q)-er,1e-8);
                    line(ax,[xf(q) xf(q)],[lo hi],'Color',colors(im,:), ...
                        'LineWidth',1,'HandleVisibility','off');
                end
            end
            target=Ns(in)^(-1/2);
            yline(ax,target,'k--',sprintf('N^{-1/2}=%.2g',target), ...
                'LabelHorizontalAlignment','left','HandleVisibility','off');
            set(ax,'XScale','log','YScale','log');
            title(ax,sprintf('K=%d, N=%g',Ks(ik),Ns(in)),'FontWeight','normal');
            xlabel(ax,'Wall-clock time (s)');ylabel(ax,'TV distance');
            ylim(ax,[1e-6 1.1]);
        end
    end
    title(til,sprintf('E5 Time-accuracy Pareto front | %s',char(noises(inoise))));
    % Draw a simple legend on the final tile, independent of Pareto subsets.
    hx=gobjects(1,numel(methods));
    for il=1:numel(methods)
        hx(il)=plot(ax,nan,nan,'-o','Color',colors(il,:), ...
            'MarkerFaceColor',colors(il,:),'DisplayName',char(methods(il)));
    end
    legend(ax,hx,cellstr(methods),'Location','best');
    % Editable vector SVG; no raster image embedded inside.
    fbase=fullfile(out_dir,['E5_FigureI_' char(noises(inoise))]);
    print(fig,[fbase '.svg'],'-dsvg','-painters');
    print(fig,[fbase '.png'],'-dpng','-r180');
    close(fig);
end
end
function [m,s,half]=e5_mean_ci(x)
x=x(isfinite(x)); n=numel(x);
if n==0,m=NaN;s=NaN;half=NaN;return;end
m=mean(x);
if n==1,s=NaN;half=NaN;return;end
s=std(x,0);
if n==10, q=2.262157; % t_{9,0.975}
elseif n==20,q=2.093024; % t_{19,0.975}
elseif exist('tinv','file')==2,q=tinv(0.975,n-1);
else, q=1.96*sqrt(n/(n-2));end
half=q*s/sqrt(n);
end

