function [M_est, Sest, Up, my, theta] = deep_mvsa_invflow_streaming(Y, p, varargin)
%% DeepMVSA-InvFlow streaming/low-working-memory version
% This version preserves the optimization objective and mini-batch training
% logic of deep_mvsa_invflow, but removes the main O(L*N) and O(p*N)
% auxiliary allocations from the measured algorithm path.
%
% Key memory changes:
%   1) centered covariance is accumulated in fixed-size chunks; no full Yc;
%   2) projected/spherized data are generated on demand; no full Yp/Y_work;
%   3) q_m is accumulated in one streaming pass;
%   4) VCA initialization uses at most VCA_INIT_SAMPLES columns;
%   5) sample coordinates are generated from indices on demand;
%   6) full abundance output is optional. For Table 1 memory benchmarking,
%      set RETURN_ABUNDANCES=false so no p-by-N Sest matrix is materialized.
%
% The input Y itself is still a full L-by-N MATLAB array. Its storage is
% common input storage and should be included in the benchmark baseline,
% not in Peak Working Memory.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);
addParameter(pStruct, 'BATCH_SIZE', 4096, @isnumeric);
addParameter(pStruct, 'PREPROCESS_CHUNK', 4096, @isnumeric);
addParameter(pStruct, 'VCA_INIT_SAMPLES', 10000, @isnumeric);
addParameter(pStruct, 'OUTPUT_CHUNK', 65536, @isnumeric);
addParameter(pStruct, 'RETURN_ABUNDANCES', true, @(x)islogical(x) || (isnumeric(x) && isscalar(x)));
addParameter(pStruct, 'SEED', [], @isnumeric);
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
parse(pStruct, varargin{:});

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

[L, N] = size(Y);
B = min(max(1, floor(pStruct.Results.BATCH_SIZE)), N);
full_batch = (B >= N);
prep_chunk = min(max(1, floor(pStruct.Results.PREPROCESS_CHUNK)), N);
vca_init_samples = min(max(p, floor(pStruct.Results.VCA_INIT_SAMPLES)), N);
output_chunk = min(max(1, floor(pStruct.Results.OUTPUT_CHUNK)), N);
spherize_yes = strcmpi(pStruct.Results.spherize, 'yes');

%% --------------------- Streaming preprocessing ---------------------
% Accumulate the centered L-by-L covariance using only L-by-prep_chunk
% temporary storage. This is algebraically the same covariance used by:
%   Yc = Y - mean(Y,2);  Yc*Yc'/N
[my, Uc, D] = stream_preprocess_covariance(Y, p, prep_chunk);

my_ortho = my - Uc*(Uc'*my);
my_ortho_norm = norm(my_ortho, 2);
if my_ortho_norm <= eps(class(my_ortho))
    error('Cannot construct affine basis: mean vector lies in the centered subspace.');
end
u_last = my_ortho / my_ortho_norm;
Up = [Uc, u_last];

lambda_reg = 0;
C = [];
if spherize_yes
    lambda_reg = 1e-10;
    C = diag(1 ./ sqrt(diag(D + lambda_reg*eye(p-1))));
end

proj = struct();
proj.Uc = Uc;
proj.Up = Up;
proj.my = my;
proj.UcTmy = Uc' * my;
proj.last_const = u_last' * my;
proj.C = C;
proj.spherize = spherize_yes;

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    % Keep VCA as the initialization mechanism, but bound its memory by
    % using a fixed-size deterministic subset. Thus VCA contributes a
    % constant-in-N working-memory term in the Table 1 upper-panel test.
    idx0 = fixed_subset_indices(N, vca_init_samples);
    Y_init = project_raw_chunk(Y(:, idx0), proj, p);
    M0 = VCA(Y_init, 'Endmembers', p, 'verbose', 'off');
    clear Y_init idx0
else
    M0 = transform_initial_endmembers(pStruct.Results.M0, proj, p);
end
Q0 = inv(M0);

% q_m = 1' * Y_work' * inv(Y_work*Y_work') without materializing Y_work.
qm = stream_compute_qm(Y, proj, p, prep_chunk);

%% --------------------- Coordinate metadata ---------------------
grid_info = build_grid_info(N);
coord_dim = grid_info.coord_dim;

%% --------------------- A-Net parameters ---------------------
hidden = 32;
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = 0.05;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);
theta.R = zeros(p,p);
theta.r_log = zeros(p,1);

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

if pStruct.Results.verbose
    fprintf(['Streaming mini-batch training: N=%d, batch=%d, prep_chunk=%d, ' ...
             'VCA_init=%d, steps/epoch=%.1f\n'], ...
        N, B, prep_chunk, vca_init_samples, N/B);
end

%% --------------------- Warm-up ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    [Yb, cb] = next_batch_streaming(Y, proj, grid_info, N, B, full_batch, p);
    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, true, N);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, pStruct.Results.WARM_UP, loss);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
for k = 1:n_joint
    [Yb, cb] = next_batch_streaming(Y, proj, grid_info, N, B, full_batch, p);
    [loss, grad] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, false, N);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

%% --------------------- Recover endmembers ---------------------
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);

% For Table 1 memory measurement use RETURN_ABUNDANCES=false. When true,
% the returned Sest is necessarily p-by-N and therefore its output storage
% is O(pN); this is an output requirement, not optimizer-state memory.
if pStruct.Results.RETURN_ABUNDANCES
    Sest = zeros(p, N);
    for i1 = 1:output_chunk:N
        i2 = min(i1 + output_chunk - 1, N);
        idx = i1:i2;
        cb = coords_from_indices(idx, N, grid_info);
        Sest(:, idx) = abundance_net_forward_nl(cb, theta, false);
    end
else
    Sest = [];
end

if spherize_yes
    M_sub = M_sub * sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Uc * diag(sqrt(diag(D + lambda_reg*eye(p-1)))) * M_sub + repmat(my,1,p);
else
    M_est = Up * M_sub;
end
end

%% ===================== Streaming helpers =====================
function [my, Uc, D] = stream_preprocess_covariance(Y, p, chunk_size)
%STREAM_PREPROCESS_COVARIANCE Centered covariance without full Yc/Yp.
    [L, N] = size(Y);
    my = mean(Y, 2);
    Cyy = zeros(L, L, 'like', Y);
    for i1 = 1:chunk_size:N
        i2 = min(i1 + chunk_size - 1, N);
        Yc_chunk = Y(:, i1:i2) - my;
        Cyy = Cyy + Yc_chunk * Yc_chunk';
    end
    Cyy = Cyy / N;
    Cyy = 0.5 * (Cyy + Cyy');
    [Uc, D] = svds(Cyy, p-1);
end

function Yw = project_raw_chunk(Ychunk, proj, p)
%PROJECT_RAW_CHUNK Generate the low-dimensional working representation.
% For spherization this is algebraically equivalent to the original
% C*Uc'*(Yp-my), followed by the affine last coordinate and /sqrt(p), but
% no L-by-N projected matrix is formed.
    n = size(Ychunk, 2);
    if proj.spherize
        Z = proj.Uc' * Ychunk - repmat(proj.UcTmy, 1, n);
        Yw = zeros(p, n, 'like', Z);
        Yw(1:p-1,:) = proj.C * Z;
        Yw(p,:) = 1;
        Yw = Yw / sqrt(p);
    else
        Yw = zeros(p, n, 'like', Ychunk);
        Yw(1:p-1,:) = proj.Uc' * Ychunk;
        Yw(p,:) = proj.last_const;
    end
end

function qm = stream_compute_qm(Y, proj, p, chunk_size)
%STREAM_COMPUTE_QM Streaming equivalent of 1'*Yw'*inv(Yw*Yw').
    N = size(Y, 2);
    sum_y = zeros(p, 1);
    gram = zeros(p, p);
    for i1 = 1:chunk_size:N
        i2 = min(i1 + chunk_size - 1, N);
        Yw = project_raw_chunk(Y(:, i1:i2), proj, p);
        sum_y = sum_y + sum(Yw, 2);
        gram = gram + Yw * Yw';
    end
    qm = sum_y' / gram;
end

function M0w = transform_initial_endmembers(M0, proj, p)
%TRANSFORM_INITIAL_ENDMEMBERS Preserve the original M0 coordinate mapping.
    if proj.spherize
        Z = proj.Uc' * (M0 - repmat(proj.my, 1, p));
        M0w = proj.C * Z;
        M0w(p,:) = 1;
        M0w = M0w / sqrt(p);
    else
        M0w = proj.Up' * M0;
    end
end

function idx = fixed_subset_indices(N, n_keep)
%FIXED_SUBSET_INDICES Deterministic bounded-size subset for VCA init.
    if N <= n_keep
        idx = 1:N;
    else
        idx = round(linspace(1, N, n_keep));
        idx = unique(idx, 'stable');
    end
end

function info = build_grid_info(N)
%BUILD_GRID_INFO Store O(1) metadata; do not materialize N coordinates.
    H = round(sqrt(N));
    W = round(N / H);
    info.H = H;
    info.W = W;
    info.is_grid = (H * W == N);
    if info.is_grid
        info.coord_dim = 2;
    else
        info.coord_dim = 1;
    end
end

function coords = coords_from_indices(idx, N, info)
%COORDS_FROM_INDICES Reproduce the original linspace/meshgrid coordinates
% only for requested sample indices.
    idx = double(idx);
    if info.is_grid
        row = mod(idx - 1, info.H) + 1;
        col = floor((idx - 1) / info.H) + 1;
        if info.W > 1
            x = -1 + 2 * (col - 1) / (info.W - 1);
        else
            x = zeros(size(col));
        end
        if info.H > 1
            y = -1 + 2 * (row - 1) / (info.H - 1);
        else
            y = zeros(size(row));
        end
        coords = [x; y];
    else
        if N > 1
            coords = -1 + 2 * (idx - 1) / (N - 1);
        else
            coords = zeros(size(idx));
        end
    end
end

function [Yb, cb] = next_batch_streaming(Y, proj, grid_info, N, B, full_batch, p)
%NEXT_BATCH_STREAMING Draw raw columns, then project only that mini-batch.
    if full_batch
        idx = 1:N;
    else
        idx = randi(N, 1, B);
    end
    Yb = project_raw_chunk(Y(:, idx), proj, p);
    cb = coords_from_indices(idx, N, grid_info);
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function grad = abundance_net_backward_nl(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);
end

function [loss, grad] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, warm_up, N_total)
% Y is a BATCH of Nb columns drawn from the full data set of N_total
% samples. Per-sample SUM penalties are scaled by s = N_total/Nb so that
% all stochastic losses/gradients are unbiased estimates of the original
% full-batch versions (s = 1 recovers them exactly).
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

[A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
s = N_total / Nb;              % unbiased scaling for per-sample SUM penalties

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));         % per-sample MEAN: no rescaling

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

penalty = min(A_eff,0);
loss_nonneg = s * sum(penalty.^2, 'all');                 % <<< scaled

sum_A = sum(A_eff,1);
loss_sumone = s * sum((sum_A-1).^2, 'all');               % <<< scaled

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');   % data-free (q_m precomputed)

% --- optional data-enclosure penalty QY >= 0 ---
QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = s * sum(pen_enclose.^2, 'all');            % <<< scaled

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

dY_hat = 2*diff/Nb;                        % gradient of the batch MEAN
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * s * pen_enclose * Y';                % <<< scaled
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Backprop to abundance network
dA_eff = M' * dY_hat + s * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));               % <<< scaled
grad_net = abundance_net_backward_nl(dA_eff, cache, theta);
grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
