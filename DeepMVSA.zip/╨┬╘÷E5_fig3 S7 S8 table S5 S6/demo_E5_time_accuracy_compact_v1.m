%% DEMO_E5_TIME_ACCURACY_COMPACT -- single MATLAB script + 3 estimator files.
% E5: Three *real* estimators, not toy/proxy baselines.
% Main memory metric: Peak local workspace arrays (decimal MB=bytes/1e6).
% Runtime: one instrumented model invocation, monitored overhead INCLUDED.
% Only ONE model training per configuration, iteration budget, and repeat.
% TV: E4-equivalent common Y-derived work-coordinate projection; adaptive MC.
%     Metric is PROJECTED work-space simplex TV, NOT full ambient TV.
%     TV mapping and MC run after/before each timed estimator call, NOT in timing.
% Windows MATLAB required for memory() instrumented copies.
% Required on MATLAB path: USGS_1995_Library.mat, VCA.m, dataProj.m,
% quadProg1.m; spectMixGen.m only for DATA_PROTOCOL='table2_spectmixgen'.
% Results: E5_run_summary.csv, E5_formal_checkpoint.mat,
% E5_config_summary.csv, E5_target_time_summary.csv, E5_reports_data.mat,
% plus vector SVG/PNG for each noise condition.
clear; clc; close all;

%% --------- USER SETTINGS (CHANGE 'pilot' TO 'formal') ---------
cfg=struct();
cfg.MODE='formal';                   % 'pilot', 'formal', or 'replot'
% For replot, set cfg.MODE='replot' and cfg.REPLOT_SOURCE='formal'
cfg.REPLOT_SOURCE='formal';
cfg.OUT_DIR=fullfile(pwd, ['E5_output_' cfg.MODE '_E4coords']);
cfg.RESUME=true;
cfg.MEASURE_MEMORY=true;          % Must remain true for Peak local workspace MB
cfg.DATA_PROTOCOL='uniform_simplex_v127';   % or 'table2_spectmixgen'
cfg.NOISE_PROTOCOL='gaussian_v127';          % or table2_uniform with table2_spectmixgen
cfg.TARGET_L=30;                 % actual uploaded Table-2 scripts use 30 (despite '20' comment)
cfg.SHAPE_PARAMETER=1; cfg.MAX_PURITY=0.8;
cfg.GEN_BLOCK=100000;
cfg.DEEP_LR=1e-3;cfg.DEEP_VOL=0.01;cfg.DEEP_NONNEG=5;
cfg.DEEP_EQ=80;cfg.DEEP_SUMONE=2;cfg.DEEP_ENCLOSE=10;
cfg.DEEP_BATCH=4096; cfg.DEEP_WARM_UP=400;
cfg.DEEP_COORD_MODE='index1d';
cfg.VCA_INIT_SAMPLES=200000;
cfg.MEMORY_BASELINE_SAMPLES=7;
cfg.MEMORY_CHECKPOINT_DEEP=100;
cfg.MEMORY_CHECKPOINT_MVSA=1;
cfg.MEMORY_CHECKPOINT_SOFTML=1;
cfg.TV_BATCH=50000; cfg.TV_MIN_SAMPLES=200000;
cfg.TV_MAX_SAMPLES=2000000;
cfg.TV_RELATIVE_CI=0.1;cfg.TV_ABSOLUTE_CI=1e-5;
cfg.TV_MEMBERSHIP_TOL=1e-8; % Match E4 barycentric membership tolerance
% E4 e4_to_work map: W = [diag((eigvals+1e-10)^-1/2)*Up'*(Z-my); 1]/sqrt(p).
% Compute ONE common map from Y for ALL algorithms/budgets in each scene.
cfg.TV_COORD_PROTOCOL='E4_common_Y_whitened_work_v1';
cfg.TV_WHITEN_REG=1e-10;
cfg.SELF_TEST_TV=true;

if strcmpi(cfg.MODE,'pilot')
    cfg.K_VALUES=3; cfg.N_VALUES=10000; cfg.NOISE_MODES={'clean'};
    cfg.REPEATS=1;
    cfg.DEEP_ITERS=[250 500];
    cfg.MVSA_ITERS=[1 2];cfg.MVSA_TOLS=1e-2;
    cfg.SOFTML_ITERS=[1 5];
elseif strcmpi(cfg.MODE,'formal')
    cfg.K_VALUES=[3 5];cfg.N_VALUES=[1e4 1e6 1e7];
    cfg.NOISE_MODES={'clean','snr30'};
    cfg.REPEATS=10;
    cfg.DEEP_ITERS=[250 500 1500 5000 15000];
    cfg.MVSA_ITERS=[1 2 4 8];cfg.MVSA_TOLS=[1e-2 1e-3];
    cfg.SOFTML_ITERS=[1 5 20 100];
elseif strcmpi(cfg.MODE,'replot')
    % Skip dataset/model dependencies, and regenerate figures/tables from CSV.
    cfg.OUT_DIR=fullfile(pwd,['E5_output_' cfg.REPLOT_SOURCE '_E4coords']);
    e5_make_reports(fullfile(cfg.OUT_DIR,'E5_run_summary.csv'),cfg.OUT_DIR);
    fprintf('E5 reports recreated from CSV: %s\n',cfg.OUT_DIR);
    return;
else
    error('Unknown MODE: %s',cfg.MODE);
end

%% --------- Preconditions and independent results folder ---------
here=fileparts(mfilename('fullpath')); addpath(here,'-begin');
required={'e5_deep_mvsa_invflow_memory', ...
    'e5_mvsa_memory','e5_softml_memory', ...
    'VCA','quadProg1','dataProj'};
if strcmp(cfg.DATA_PROTOCOL,'table2_spectmixgen')
    required{end+1}='spectMixGen';
end
for ii=1:numel(required)
    if exist(required{ii},'file')~=2
        error('Required dependency missing from MATLAB path: %s',required{ii});
    end
end
if ~cfg.MEASURE_MEMORY
    error('The compact E5 driver requires enabled memory monitoring.');
end
if cfg.MEASURE_MEMORY && ~ispc
    error('Uploaded Table-2 memory code uses Windows MATLAB memory(). Run on Windows.');
end
if ~exist(cfg.OUT_DIR,'dir'), mkdir(cfg.OUT_DIR);end
if cfg.SELF_TEST_TV, e5_tv_selftest(cfg);end
run_mat=fullfile(cfg.OUT_DIR,'E5_formal_checkpoint.mat');
run_csv=fullfile(cfg.OUT_DIR,'E5_run_summary.csv');
% Keep a separate output directory for pilot and formal: these cannot be mixed.
if cfg.RESUME && isfile(run_mat)
    loaded=load(run_mat,'records','vertices','config');
    if ~isfield(loaded,'config') || ~isequaln(loaded.config,cfg)
        error(['E5 checkpoint configuration does not match current cfg. ' ...
               'Use a separate OUT_DIR or archive/reset the old checkpoint.']);
    end
    records=loaded.records; vertices=loaded.vertices;
else
    records=struct([]); vertices={};
end
fprintf('E5 mode=%s; output=%s\n',cfg.MODE,cfg.OUT_DIR);

%% --------- USGS full-library PCA basis (as in uploaded Table 2 code) ---------
lib=load('USGS_1995_Library');
if ~isfield(lib,'datalib'),error('USGS_1995_Library must contain datalib');end
Xlib=double(lib.datalib); n_materiais=size(Xlib,2);
mu_lib=mean(Xlib,2);
[Ulib,~,~]=svd(bsxfun(@minus,Xlib,mu_lib),'econ');
if size(Ulib,2)<cfg.TARGET_L,error('USGS library PCA dimension too small');end
PCA_basis=Ulib(:,1:cfg.TARGET_L);
clear lib Xlib Ulib;

%% --------- Main formal grid ---------
for iK=1:numel(cfg.K_VALUES)
    K=cfg.K_VALUES(iK);p=K+1;
    for iN=1:numel(cfg.N_VALUES)
        N=cfg.N_VALUES(iN);
        for ir=1:cfg.REPEATS
            % Keep the same true simplex within each K x repeat when N varies.
            % This separates sample-size effects from endmember geometry.
            scene_seed=1101 + 10000*iK + ir;
            rng(scene_seed,'twister');
            sel_mat=4+randperm(n_materiais-4);sel_mat=sel_mat(1:p);
            % Need to reload selected spectra, avoiding copying full library.
            selected=load('USGS_1995_Library','datalib');
            M_original=double(selected.datalib(:,sel_mat));clear selected;
            M_pre=PCA_basis' * bsxfun(@minus,M_original,mu_lib);
            Mtrue=e5_fp8_e4m3_quantize(M_pre);clear M_original M_pre;
            for inoise=1:numel(cfg.NOISE_MODES)
                noise=cfg.NOISE_MODES{inoise};
                scene=struct('K',K,'N',N,'noise',noise,'seed',scene_seed);
                fprintf('\n[E5] K=%d N=%d %s rep=%d/%d\n',K,N,noise,ir,cfg.REPEATS);
                % Skip regenerating large data when every budget has completed.
                budgets=make_e5_budgets(cfg);
                todo=false;
                for jb=1:numel(budgets)
                    key=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
                        cfg.DATA_PROTOCOL,K,N,noise,ir,budgets(jb).method,budgets(jb).label);
                    if isempty(records) || ~any(strcmp({records.run_id},key))
                        todo=true;break;
                    end
                end
                if ~todo, fprintf('  All budgets in checkpoint; skipping.\n'); continue;end
                try
                    % regenerate identical abundances for same scene_seed and
                    % same vertices, irrespective of clean/noisy condition.
                    [Y,~,scene_meta]=e5_generate_dataset(Mtrue,N,noise,scene_seed,cfg);
                    if any(~isfinite(Y(:))) || ~isequal(size(Y),[cfg.TARGET_L,N])
                        error('Synthetic scene invalid.');
                    end
                    % E4-aligned TV coordinate protocol (ONE shared map per Y).
                    % Reproduces E4's e4_to_work formula, using Y's top K
                    % covariance eigenvectors and whitening eigenvalues.
                    % This evaluation-only operation is NOT timed as training,
                    % and its allocations are NOT part of the model memory metric.
                    tvmap=e5_common_e4_workmap(Y,p,cfg.GEN_BLOCK,cfg.TV_WHITEN_REG);
                    Mtrue_tv=e5_to_e4_work(Mtrue,tvmap);
                    % Methods are grouped to avoid keeping a second full Yproj
                    % copy during non-SoftML training.
                    methods={'DeepMVSA','MVSA','SoftML'};
                    for im=1:numel(methods)
                        method=methods{im};
                        proj=struct('Yproj',[],'Up',[],'my',[]);
                        if strcmp(method,'SoftML')
                            [proj.Yproj,proj.Up,proj.my,~]=dataProj(Y,p,'proj_type','affine');
                        end
                        for jb=1:numel(budgets)
                            if ~strcmp(budgets(jb).method,method), continue;end
                            key=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
                                cfg.DATA_PROTOCOL,K,N,noise,ir,method,budgets(jb).label);
                            if ~isempty(records) && any(strcmp({records.run_id},key))
                                continue;
                            end
                            fprintf('  %s %s\n',method,budgets(jb).label);
                            [r,v]=e5_run_one(Y,Mtrue,Mtrue_tv,tvmap,proj,cfg,scene,method,budgets(jb),ir);
                            r.achieved_snr_db=scene_meta.achieved_snr_db;
                            % Every row must have the same struct fields.
                            if isempty(records)
                                records=r;
                            else
                                records(end+1)=r; %#ok<SAGROW>
                            end
                            vertices{end+1}=v; %#ok<SAGROW>
                            config=cfg; %#ok<NASGU>
                            save(run_mat,'records','vertices','config','-v7.3');
                            writetable(struct2table(records),run_csv);
                            fprintf('    time=%.3fs TV=%.6g [%.6g, %.6g] peak=%.3f MB status=%s\n', ...
                                r.runtime_s,r.tv,r.tv_ci_low,r.tv_ci_high, ...
                                r.peak_local_workspace_MB,r.status);
                        end
                        clear proj;
                    end
                    clear Y tvmap Mtrue_tv;
                catch ME
                    clear Y proj tvmap Mtrue_tv;
                    warning('E5 scene K%d N%d %s rep%d failed: %s',K,N,noise,ir,ME.message);
                    % Preserve scene-level errors in a separate ledger. No false
                    % zero TV, zero runtime or success rows are fabricated.
                    fid=fopen(fullfile(cfg.OUT_DIR,'E5_scene_failures.log'),'a');
                    if fid>=0
                        fprintf(fid,'K=%d N=%d noise=%s rep=%d seed=%d | %s\n', ...
                            K,N,noise,ir,scene_seed,ME.message);
                        fclose(fid);
                    end
                    continue;
                end
            end
        end
    end
end

%% --------- Analyze and draw from saved CSV (no models rerun) ---------
e5_make_reports(run_csv,cfg.OUT_DIR);
fprintf('\nE5 finished. Raw CSV: %s\n',run_csv);

%% --------- Script-local helpers (only estimator algorithms are external) ---------
function budgets=make_e5_budgets(cfg)
budgets=struct('method',{},'label',{},'iter',{},'tol',{});
for T=cfg.DEEP_ITERS
    budgets(end+1)=struct('method','DeepMVSA','label',sprintf('T%d',T), ...
        'iter',T,'tol',NaN); %#ok<AGROW>
end
for T=cfg.MVSA_ITERS
    for tol=cfg.MVSA_TOLS
        budgets(end+1)=struct('method','MVSA', ...
            'label',sprintf('I%d_tol%.0e',T,tol),'iter',T,'tol',tol); %#ok<AGROW>
    end
end
for T=cfg.SOFTML_ITERS
    budgets(end+1)=struct('method','SoftML', ...
        'label',sprintf('I%d',T),'iter',T,'tol',NaN); %#ok<AGROW>
end
end

function [rec,vert] = e5_run_one(Y,Mtrue,Mtrue_tv,tvmap,proj,cfg,scene,method,budget,rep)
%E5_RUN_ONE Single, timed instrumented estimator call for BOTH time and MB.
% Timer brackets whole monitored function call: initialization + optimization
% + recovery. Monitoring is INCLUDED in wall-clock. Dataset generation and
% external SoftML affine dataProj are EXCLUDED (same as uploaded Table-2 code).
% Memory metric is peak_local_workspace_bytes/1e6 (decimal MB).
rec=e5_blank_record();
vert=struct('Mtrue',Mtrue,'Mest',[],'Mtrue_work',Mtrue_tv, ...
    'Mest_work',[],'eval_mean',tvmap.my,'eval_basis',tvmap.Up_sub, ...
    'eval_eigenvalues',tvmap.eigvals,'eval_lambda_reg',tvmap.lambda_reg, ...
    'run_id','');
rec.K=scene.K; rec.p=scene.K+1; rec.N=scene.N; rec.noise=scene.noise;
rec.rep=rep; rec.scene_seed=scene.seed; rec.method=method;
rec.data_protocol=cfg.DATA_PROTOCOL; rec.noise_protocol=cfg.NOISE_PROTOCOL;
rec.budget_iter=budget.iter; rec.tolerance=budget.tol;
rec.budget_id=budget.label;
rec.run_id=sprintf('%s_K%d_N%d_%s_R%02d_%s_%s', ...
    cfg.DATA_PROTOCOL,scene.K,scene.N,scene.noise,rep,method,budget.label);
vert.run_id=rec.run_id;
rec.algo_seed=scene.seed+300000+rep*1000;
rec.tv_target=scene.N^(-0.5);
rec.tv_metric='E4_common_Y_whitened_projected_uniform_simplex_TV';
rec.tv_coord_protocol=cfg.TV_COORD_PROTOCOL;
rec.runtime_protocol='monitored_full_function_call';
rec.status='started';
if strcmp(method,'DeepMVSA')
    warm=min(cfg.DEEP_WARM_UP,max(1,floor(budget.iter/4)));
    rec.warmup_iter=warm;
else
    warm=NaN;
end
% Require memory instrumented call, no duplicated second training.
try
    rng(rec.algo_seed,'twister');
    timer=tic;
    switch method
        case 'DeepMVSA'
            [Mest,~,~,~,theta]=e5_deep_mvsa_invflow_memory(Y,scene.K+1, ...
                'spherize','yes','verbose',0, ...
                'MM_ITERS',budget.iter,'WARM_UP',warm, ...
                'LR',cfg.DEEP_LR,'LAMBDA_VOL',cfg.DEEP_VOL, ...
                'LAMBDA_NONNEG',cfg.DEEP_NONNEG,'LAMBDA_EQ',cfg.DEEP_EQ, ...
                'LAMBDA_SUMONE',cfg.DEEP_SUMONE, ...
                'LAMBDA_ENCLOSE',cfg.DEEP_ENCLOSE, ...
                'BATCH_SIZE',cfg.DEEP_BATCH, ...
                'VCA_INIT_SAMPLES',cfg.VCA_INIT_SAMPLES, ...
                'COORD_MODE',cfg.DEEP_COORD_MODE, ...
                'RETURN_FULL_ABUNDANCE',false, ...
                'MEASURE_OPT_MEMORY',cfg.MEASURE_MEMORY, ...
                'MEMORY_BASELINE_SAMPLES',cfg.MEMORY_BASELINE_SAMPLES, ...
                'MEMORY_CHECKPOINT_EVERY',cfg.MEMORY_CHECKPOINT_DEEP);
            st=theta.memory_stats;
        case 'MVSA'
            [Mest,~,~,~,~,st]=e5_mvsa_memory(Y,scene.K+1, ...
                'spherize','yes','verbose',0, ...
                'MM_ITERS',budget.iter,'TOLF',budget.tol, ...
                'MEASURE_OPT_MEMORY',cfg.MEASURE_MEMORY, ...
                'MEMORY_BASELINE_SAMPLES',cfg.MEMORY_BASELINE_SAMPLES, ...
                'MEMORY_CHECKPOINT_EVERY',cfg.MEMORY_CHECKPOINT_MVSA);
        case 'SoftML'
            [Mest,~,omem]=e5_softml_memory(Y,scene.K+1, ...
                'YProj',proj.Yproj,'Up',proj.Up,'my',proj.my, ...
                'MTrue',Mtrue,'MaxIter',budget.iter, ...
                'Gamma',[],'Alpha',[], ...
                'UseConvexHullInit',true,'UseHullGradient',true, ...
                'Seed',rec.algo_seed,'Plot',false,'Verbose',false, ...
                'MEASURE_OPT_MEMORY',cfg.MEASURE_MEMORY, ...
                'MEMORY_BASELINE_SAMPLES',cfg.MEMORY_BASELINE_SAMPLES, ...
                'MEMORY_CHECKPOINT_EVERY',cfg.MEMORY_CHECKPOINT_SOFTML);
            st=omem.memory_stats;
        otherwise
            error('Unknown E5 method: %s',method);
    end
    rec.runtime_s=toc(timer);
    vert.Mest=Mest;
    if ~isequal(size(Mest),size(Mtrue)) || any(~isfinite(Mest(:)))
        error('Estimator returned invalid M of size %s',mat2str(size(Mest)));
    end
    if ~isstruct(st) || ~isfield(st,'peak_local_workspace_bytes')
        error('Instrumented estimator did not return Peak local workspace arrays.');
    end
    rec.peak_local_workspace_bytes=double(st.peak_local_workspace_bytes);
    rec.peak_local_workspace_MB=rec.peak_local_workspace_bytes/1e6;
    if ~isfinite(rec.peak_local_workspace_MB) || rec.peak_local_workspace_MB<0
        error('Invalid Peak local workspace arrays measurement.');
    end
    rec.peak_local_label=st.peak_local_workspace_label;
    rec.local_memory_samples=st.local_samples;
    rec.memory_status='ok';
    rec.status='model_ok';
catch ME
    % A failure never receives a fake finite TV or MB.
    rec.status='model_failed'; rec.error_text=e5_errtext(ME);
    return;
end
% TV is deliberately OUTSIDE the model wall-clock and peak workspace interval.
try
    % Both methods use the SAME E4-style affine work coordinate map.
    % E4: W(p,:) = 1; W = W/sqrt(p) after whitening Up'*(M-my).
    % Off-subspace components are deliberately projected away in BOTH.
    Mest_tv=e5_to_e4_work(Mest,tvmap);
    vert.Mest_work=Mest_tv;
    centered=bsxfun(@minus,double(Mest),tvmap.my);
    off=centered-tvmap.Up_sub*(tvmap.Up_sub'*centered);
    rec.tv_est_out_of_subspace_rel=norm(off,'fro')/max(norm(centered,'fro'),realmin);
    tv=e5_tv_distance(Mtrue_tv,Mest_tv,rec.tv_target,rec.algo_seed+111,cfg);
    rec.tv=tv.tv; rec.tv_ci_low=tv.ci_low; rec.tv_ci_high=tv.ci_high;
    rec.tv_samples=tv.n_samples; rec.target_status=tv.target_status;
    rec.volume_ratio=tv.volume_ratio; rec.tv_status=tv.status;
    if strcmp(tv.status,'ok') || strcmp(tv.status,'degenerate_est')
        rec.status='ok';
    else
        rec.status='tv_invalid';
    end
catch ME
    rec.status='tv_failed'; rec.error_text=e5_errtext(ME);
end
end
function rec=e5_blank_record()
rec=struct('run_id','','method','','K',NaN,'p',NaN,'N',NaN, ...
    'noise','','rep',NaN,'scene_seed',NaN,'algo_seed',NaN, ...
    'data_protocol','','noise_protocol','','budget_id','', ...
    'budget_iter',NaN,'tolerance',NaN,'warmup_iter',NaN, ...
    'runtime_s',NaN,'runtime_protocol','', ...
    'peak_local_workspace_bytes',NaN, ...
    'peak_local_workspace_MB',NaN,'peak_local_label','', ...
    'local_memory_samples',NaN,'memory_status','not_measured', ...
    'tv',NaN,'tv_ci_low',NaN,'tv_ci_high',NaN, ...
    'tv_samples',NaN,'tv_target',NaN,'target_status',NaN, ...
    'volume_ratio',NaN,'tv_metric','','tv_coord_protocol','', ...
    'tv_est_out_of_subspace_rel',NaN,'tv_status','', ...
    'status','','error_text','');
end
function s=e5_errtext(ME)
s=sprintf('%s: %s',ME.identifier,ME.message);
s=regexprep(s,'[\r\n\t]',' ');
if numel(s)>700,s=s(1:700);end
end


function [Y,Mtrue,meta] = e5_generate_dataset(Mtrue, N, noise_mode, seed, cfg)
%E5_GENERATE_DATASET Return L-by-N data using user's quantized USGS vertices.
%   'uniform_simplex_v127' samples Dirichlet(1,...,1) uniformly on simplex.
%   'table2_spectmixgen' uses Table-2's spectMixGen Diri_id/max_purity=.8.
%   noise_mode: 'clean' or 'snr30'; gaussian_v127 noise has exactly global SNR30.
%   DATA PROTOCOL and NOISE PROTOCOL are explicitly stored for audit.
rng(seed,'twister');
p=size(Mtrue,2); L=size(Mtrue,1);
meta=struct('data_protocol',cfg.DATA_PROTOCOL,'noise_protocol',cfg.NOISE_PROTOCOL, ...
    'scene_seed',seed,'target_snr_db',NaN,'achieved_snr_db',NaN, ...
    'shape_parameter',cfg.SHAPE_PARAMETER,'max_purity',cfg.MAX_PURITY);
if strcmpi(cfg.DATA_PROTOCOL,'uniform_simplex_v127')
    Y=zeros(L,N,'double');
    for s=1:cfg.GEN_BLOCK:N
        e=min(N,s+cfg.GEN_BLOCK-1);
        A=-log(max(rand(p,e-s+1),realmin));
        A=bsxfun(@rdivide,A,sum(A,1));
        Y(:,s:e)=double(Mtrue)*A;
    end
elseif strcmpi(cfg.DATA_PROTOCOL,'table2_spectmixgen')
    % Run at a finite SNR, use its abundances to reconstruct noise-free Y.
    % The original Table-2 generator exposes [Y, S, ...]. Confirm S shape.
    [Ygenerated,Sgen,~]=spectMixGen(double(Mtrue), N, ...
        'Source_pdf','Diri_id','pdf_pars',cfg.SHAPE_PARAMETER, ...
        'max_purity',cfg.MAX_PURITY*ones(1,p), ...
        'no_outliers',0,'violation_extremes',[1,1.2], ...
        'snr',30,'noise_shape','uniform');
    if ~isequal(size(Sgen),[p,N])
        error(['spectMixGen second output is not a p-by-N abundance matrix. ' ...
            'Verify your local spectMixGen signature; no synthetic data were guessed.']);
    end
    if any(~isfinite(Sgen(:))) || max(abs(sum(Sgen,1)-1))>1e-5
        error('spectMixGen output abundances failed the sum-to-one validation.');
    end
    if strcmpi(cfg.NOISE_PROTOCOL,'table2_uniform') && strcmpi(noise_mode,'snr30')
        Y=Ygenerated;
        meta.target_snr_db=30;
        % Exact SNR of the generator's original Y can be measured against M*S.
        Epower=0; Spower=0;
        for s=1:cfg.GEN_BLOCK:N
            e=min(N,s+cfg.GEN_BLOCK-1); Yclean=double(Mtrue)*double(Sgen(:,s:e));
            D=double(Ygenerated(:,s:e))-Yclean;
            Epower=Epower+sum(D(:).^2); Spower=Spower+sum(Yclean(:).^2);
        end
        meta.achieved_snr_db=10*log10(Spower/max(Epower,realmin));
        clear Sgen Ygenerated; return;
    end
    clear Ygenerated;
    Y=zeros(L,N,'double');
    for s=1:cfg.GEN_BLOCK:N
        e=min(N,s+cfg.GEN_BLOCK-1);
        Y(:,s:e)=double(Mtrue)*double(Sgen(:,s:e));
    end
    clear Sgen;
else
    error('Unknown DATA_PROTOCOL: %s',cfg.DATA_PROTOCOL);
end
if strcmpi(noise_mode,'clean')
    return;
elseif ~strcmpi(noise_mode,'snr30')
    error('Unknown noise_mode: %s',noise_mode);
end
if strcmpi(cfg.NOISE_PROTOCOL,'table2_uniform')
    error('table2_uniform requires DATA_PROTOCOL=table2_spectmixgen.');
end
if ~strcmpi(cfg.NOISE_PROTOCOL,'gaussian_v127')
    error('Unknown NOISE_PROTOCOL: %s',cfg.NOISE_PROTOCOL);
end
% Independent N(0,1) noise entries. Exact 30-dB Frobenius SNR via two-pass
% deterministic block RNG (no L-by-N duplicate allocation).
noise_seed=seed+777777;
rng(noise_seed,'twister'); signal_sq=0; noise_sq=0;
for s=1:cfg.GEN_BLOCK:N
    e=min(N,s+cfg.GEN_BLOCK-1); R=randn(L,e-s+1);
    C=Y(:,s:e); noise_sq=noise_sq+sum(R(:).^2);
    signal_sq=signal_sq+sum(C(:).^2);
end
scale=sqrt(signal_sq/noise_sq)*10^(-30/20);
rng(noise_seed,'twister');
for s=1:cfg.GEN_BLOCK:N
    e=min(N,s+cfg.GEN_BLOCK-1);
    Y(:,s:e)=Y(:,s:e)+scale*randn(L,e-s+1);
end
meta.target_snr_db=30; meta.achieved_snr_db=30;
end


function y = e5_fp8_e4m3_quantize(x)
% Identical numeric E4M3 rounding rule to the uploaded Table-2 benchmarks.
x = double(x); y = zeros(size(x)); s = sign(x); a = abs(x);
nan_mask = isnan(a); inf_mask = isinf(a); finite_mask = isfinite(a) & a>0;
a(inf_mask)=240; min_normal=2^-6; sub_step=2^-9; max_finite=240;
sub_mask=finite_mask & a<min_normal;
if any(sub_mask(:))
    q=round(a(sub_mask)/sub_step)*sub_step;
    y(sub_mask)=min(q,min_normal);
end
normal_mask=finite_mask & a>=min_normal;
if any(normal_mask(:))
    av=min(a(normal_mask),max_finite); e=floor(log2(av));
    e=max(-6,min(7,e)); step=2.^(e-3);
    q=round(av./step).*step;
    y(normal_mask)=min(q,max_finite);
end
y(inf_mask)=max_finite; y=y.*s; y(nan_mask)=NaN;
end


function map=e5_common_e4_workmap(Y,p,blockSize,lambda_reg)
%E5_COMMON_E4_WORKMAP Same coordinate convention as E4 e4_to_work().
% E4 maps Z to [C*Up(:,1:K)'*(Z-my);1]/sqrt(p), where
% C=diag(1./sqrt(diag(D)+lambda_reg)). DeepMVSA derives Up/D from the
% top K sample-covariance eigenpairs. The E5 evaluation map is computed
% once on the FULL shared scene, then applied to ALL methods (no leakage
% of method-dependent subspace estimators into a cross-method metric).
% Accumulate covariance in blocks to avoid full-sized double Y copies.
[L,N]=size(Y); K=p-1;
if N<2 || L<K, error('Cannot build E4 work-map for L=%d N=%d K=%d.',L,N,K);end
sy=zeros(L,1); YYt=zeros(L,L);
for j=1:blockSize:N
    ids=j:min(j+blockSize-1,N);
    X=double(Y(:,ids));
    sy=sy+sum(X,2);
    YYt=YYt+X*X';
end
my=sy/double(N);
Cov=YYt/double(N)-my*my';
Cov=(Cov+Cov')/2;
[Vec,vals]=eig(Cov,'vector');
[vals,order]=sort(real(vals),'descend');
if numel(vals)<K || any(~isfinite(vals(1:K)))
    error('E4 TV coordinate map: invalid covariance eigenvalues.');
end
Up_sub=real(Vec(:,order(1:K)));
eigvals=max(vals(1:K),0);
% E4 uses this exact regularization in the model working transform.
scale=1./sqrt(eigvals+lambda_reg);
if any(~isfinite(scale))
    error('E4 TV coordinate map: nonfinite whitening scale.');
end
map=struct('my',my,'Up_sub',Up_sub,'eigvals',eigvals, ...
    'lambda_reg',lambda_reg,'p',p, ...
    'W',(bsxfun(@times,Up_sub',scale))/sqrt(p));
end

function W=e5_to_e4_work(Z,map)
%E5_TO_E4_WORK  Algebraically equivalent to E4's e4_to_work().
if size(Z,1)~=numel(map.my) || size(Z,2)~=map.p
    error('TV work-map input must be L-by-p with p=%d.',map.p);
end
W=[map.W*bsxfun(@minus,double(Z),map.my); ...
    ones(1,size(Z,2))/sqrt(map.p)];
end

function r = e5_tv_distance(Mtrue, Mest, target, seed, cfg)
%E5_TV_DISTANCE TV between UNIFORM distributions on K-dimensional simplices.
% Correct identity TV=1-Vol(intersection)/max(Vol(Strue),Vol(Sest)).
% Sample uniformly from the *larger-volume* simplex; TV is then the
% Bernoulli probability of landing OUTSIDE the other simplex.
% INPUTS must already be in a COMMON E4 work-coordinate system (p-by-p):
% E4-style whitening and a fixed homogeneous last row. QR only eliminates
% the redundant constant coordinate in that same work space.
% This is a projected-simplex metric, NOT ambient-space TV.
% Different model outputs are always evaluated in the SAME common Y map.
r=struct('tv',NaN,'ci_low',NaN,'ci_high',NaN, ...
    'n_samples',0,'target_status',-1,'volume_ratio',NaN, ...
    'metric','E4_common_Y_whitened_projected_uniform_simplex_TV','status','invalid');
if isempty(Mest) || ~isequal(size(Mest),size(Mtrue)) || ...
        any(~isfinite(Mest(:))) || any(~isfinite(Mtrue(:)))
    return;
end
[L,p]=size(Mtrue); K=p-1;
if L~=p || max(abs(Mtrue(p,:)-1/sqrt(p)))>1e-8 || ...
        max(abs(Mest(p,:)-1/sqrt(p)))>1e-8
    r.status='invalid_e4_work_coordinates'; return;
end
D=double(Mtrue(:,2:end))-double(Mtrue(:,1));
[U,R]=qr(D,0);
if size(U,2)~=K || rcond(R)<1e-12, r.status='degenerate_true'; return; end
Qtrue=U'*(double(Mtrue)-double(Mtrue(:,1)));
Qest=U'*(double(Mest)-double(Mtrue(:,1)));
T=[Qtrue;ones(1,p)]; E=[Qest;ones(1,p)];
vtrue=abs(det(T)); vest=abs(det(E));
if vtrue<realmin || ~isfinite(vtrue),r.status='degenerate_true';return;end
r.volume_ratio=vest/vtrue;
if ~isfinite(vest) || vest/vtrue<1e-12 || rcond(E)<1e-12
    r.tv=1; r.ci_low=1; r.ci_high=1;
    r.target_status=0; r.status='degenerate_est'; return;
end
if vest>=vtrue
    base=Qest; other=T;
else
    base=Qtrue; other=E;
end
rng(seed,'twister');
Ntot=0; Nout=0; z=1.959963984540054;
while Ntot<cfg.TV_MAX_SAMPLES
    len=min(cfg.TV_BATCH,cfg.TV_MAX_SAMPLES-Ntot);
    A=-log(max(rand(p,len),realmin));
    A=bsxfun(@rdivide,A,sum(A,1));
    X=base*A;
    bary=other\[X;ones(1,len)];
    outside=any(bary<-cfg.TV_MEMBERSHIP_TOL,1);
    Nout=Nout+nnz(outside); Ntot=Ntot+len;
    if Ntot>=cfg.TV_MIN_SAMPLES
        [lo,hi]=wilson_ci(Nout,Ntot,z);
        phat=Nout/Ntot;
        goal=max(cfg.TV_RELATIVE_CI*max(phat,target),cfg.TV_ABSOLUTE_CI);
        if (hi-lo)/2<=goal, break; end
    end
end
[r.ci_low,r.ci_high]=wilson_ci(Nout,Ntot,z);
r.tv=Nout/Ntot; r.n_samples=Ntot; r.status='ok';
if r.ci_high<=target, r.target_status=1;
elseif r.ci_low>target, r.target_status=0;
else, r.target_status=-1;
end
end
function [lo,hi]=wilson_ci(x,n,z)
p=x/n; d=1+z^2/n;
mid=(p+z^2/(2*n))/d;
half=z*sqrt(p*(1-p)/n+z^2/(4*n^2))/d;
lo=max(0,mid-half); hi=min(1,mid+half);
end


function e5_tv_selftest(cfg)
%E5_TV_SELFTEST Analytic references plus E4 work-map equivalence.
K=3;p=K+1;
M=[zeros(K,1),eye(K); ones(1,p)/sqrt(p)];
c=mean(M,2);
r0=e5_tv_distance(M,M,0.01,123,cfg);
if ~isfinite(r0.tv) || r0.tv>0.001
    error('E5 TV self-test failed: identical simplices TV must be zero.');
end
small=bsxfun(@plus,0.5*bsxfun(@minus,M,c),c);
r1=e5_tv_distance(M,small,0.01,456,cfg);
expected=1-0.5^K;
if ~isfinite(r1.tv) || abs(r1.tv-expected)>0.02
    error('E5 TV self-test failed: expected %.6g, observed %.6g.',expected,r1.tv);
end
large=bsxfun(@plus,2*bsxfun(@minus,M,c),c);
r2=e5_tv_distance(M,large,0.01,789,cfg);
if ~isfinite(r2.tv) || abs(r2.tv-expected)>0.02
    error('E5 TV self-test failed: encompassing simplex expected %.6g.',expected);
end
% Check a FULL Y-derived E4 work map, including scale and homogeneous row.
rng(8024,'twister');
L=6; K=3; p=4; V=randn(L,p);
A=-log(max(rand(p,1200),realmin)); A=bsxfun(@rdivide,A,sum(A,1));
map=e5_common_e4_workmap(V*A,p,217,cfg.TV_WHITEN_REG);
W=e5_to_e4_work(V,map);
C=diag(1./sqrt(map.eigvals+map.lambda_reg));
Wref=C*map.Up_sub'*bsxfun(@minus,V,map.my);
Wref(p,:)=1; Wref=Wref/sqrt(p);
if norm(W-Wref,'fro')>1e-11
    error('E5 TV self-test failed: not equivalent to E4 e4_to_work.');
end
% A component perpendicular to E4's data subspace must be projected out
% equally for all methods, including in the presence of noise.
Z=null(map.Up_sub');
if ~isempty(Z)
    Woff=e5_to_e4_work(V+0.25*Z(:,1)*ones(1,p),map);
    if norm(Woff-W,'fro')>1e-10
        error('E5 TV self-test failed: off-subspace projection mismatch.');
    end
end
fprintf('E5 TV self-check passed (geometry + E4 work-map consistency).\n');
end


function e5_make_reports(run_csv,out_dir)
%E5_MAKE_REPORTS Read saved E5 runs; no model calls; vector SVG and PNG.
% E5 formal Figure I: log-log wall-clock vs TV, 2 K x 3 N per noise mode.
if ~isfile(run_csv),error('E5 run CSV does not exist: %s',run_csv);end
T=readtable(run_csv,'TextType','string');
if ~ismember('tv_coord_protocol',T.Properties.VariableNames)
    error('E5 CSV lacks tv_coord_protocol: refusing to label old TV as E4-aligned.');
end
if any(T.tv_coord_protocol ~= "E4_common_Y_whitened_work_v1")
    error('E5 CSV contains older or mixed TV evaluation protocols.');
end
planned_repeats=NaN;
checkpoint=fullfile(out_dir,'E5_formal_checkpoint.mat');
if isfile(checkpoint)
    cc=load(checkpoint,'config');
    if isfield(cc,'config') && isfield(cc.config,'REPEATS')
        planned_repeats=cc.config.REPEATS;
    end
end
if ~exist(out_dir,'dir'),mkdir(out_dir);end
ok=(T.status=="ok") & isfinite(T.runtime_s) & T.runtime_s>0 & isfinite(T.tv);
T=T(ok,:);
if isempty(T),warning('No valid completed E5 runs to report.');return;end
keys=strcat(string(T.K),"|",string(T.N),"|",T.noise,"|",T.method,"|",T.budget_id);
[uniq,~,grp]=unique(keys,'stable');
S=table();
for g=1:numel(uniq)
    gidx=find(grp==g); tr=T(gidx,:);
    row=table();
    row.K=tr.K(1);row.N=tr.N(1);row.noise=tr.noise(1);
    row.method=tr.method(1);row.budget_id=tr.budget_id(1);
    row.budget_iter=tr.budget_iter(1);row.tolerance=tr.tolerance(1);
    row.n_runs=height(tr);
    [row.time_mean_s,row.time_sd_s,row.time_ci95_half_s]=e5_mean_ci(tr.runtime_s);
    [row.tv_mean,row.tv_sd,row.tv_ci95_half]=e5_mean_ci(tr.tv);
    [row.peak_local_workspace_mean_MB,row.peak_local_workspace_sd_MB, ...
        row.peak_local_workspace_ci95_half_MB]=e5_mean_ci(tr.peak_local_workspace_MB);
    row.n_memory_valid=sum(isfinite(tr.peak_local_workspace_MB));
    row.tv_target=tr.tv_target(1);
    row.target_confident_reached_fraction=mean(tr.target_status==1);
    row.pareto=false;
    if isempty(S),S=row;else,S=[S;row];end %#ok<AGROW>
end
% Non-dominated mean points: any earlier/equal time with lower/equal TV
% dominates the current one (strict inequality on at least one dimension).
allscene=strcat(string(S.K),"|",string(S.N),"|",S.noise,"|",S.method);
scenes=unique(allscene,'stable');
for gg=1:numel(scenes)
    ii=find(allscene==scenes(gg));
    for j=ii(:)'
        domination=(S.time_mean_s(ii)<=S.time_mean_s(j)) & ...
            (S.tv_mean(ii)<=S.tv_mean(j)) & ...
            ((S.time_mean_s(ii)<S.time_mean_s(j)) | (S.tv_mean(ii)<S.tv_mean(j)));
        S.pareto(j)=~any(domination);
    end
end
writetable(S,fullfile(out_dir,'E5_config_summary.csv'));
% First *confidently* reached TV <= N^-0.5 per REP and METHOD, not across
% average curves. Not-reached repeats stay explicit, not imputed.
Tkey=strcat(string(T.K),"|",string(T.N),"|",T.noise,"|",T.method);
Ukey=unique(Tkey,'stable');
R=table();
for u=1:numel(Ukey)
    ii=find(Tkey==Ukey(u)); tr=T(ii,:);
    repids=unique(tr.rep); earliest=NaN(numel(repids),1);
    for j=1:numel(repids)
        sub=tr(tr.rep==repids(j) & tr.target_status==1,:);
        if ~isempty(sub),earliest(j)=min(sub.runtime_s);end
    end
    good=earliest(isfinite(earliest));
    row=table();row.K=tr.K(1);row.N=tr.N(1);
    row.noise=tr.noise(1);row.method=tr.method(1);
    row.tv_target=tr.tv_target(1);
    row.n_repeats_observed=numel(repids);row.n_repeats_reached=numel(good);
    if isfinite(planned_repeats)
        row.n_repeats_planned=planned_repeats;
    else
        row.n_repeats_planned=numel(repids);
    end
    row.reach_fraction=numel(good)/row.n_repeats_planned;
    [row.earliest_time_mean_s,row.earliest_time_sd_s, ...
        row.earliest_time_ci95_half_s]=e5_mean_ci(good);
    if isempty(good),row.earliest_time_median_s=NaN;
    else,row.earliest_time_median_s=median(good);end
    if isempty(R),R=row;else,R=[R;row];end %#ok<AGROW>
end
writetable(R,fullfile(out_dir,'E5_target_time_summary.csv'));
% Materialized summary MAT is small: no Y, no full abundance maps.
save(fullfile(out_dir,'E5_reports_data.mat'),'S','R','-v7');
colors=[0.10 0.38 0.78;0.88 0.43 0.15;0.06 0.58 0.40];
methods=["DeepMVSA","MVSA","SoftML"];
noises=unique(S.noise,'stable');
Ks=unique(S.K);Ns=unique(S.N);
for inoise=1:numel(noises)
    fig=figure('Color','w','Position',[60 60 1500 790],'Visible','off');
    til=tiledlayout(numel(Ks),numel(Ns),'TileSpacing','compact','Padding','compact');
    for ik=1:numel(Ks)
        for in=1:numel(Ns)
            ax=nexttile(til);hold(ax,'on');box(ax,'on');grid(ax,'on');
            slice=S(S.K==Ks(ik) & S.N==Ns(in) & S.noise==noises(inoise),:);
            for im=1:numel(methods)
                d=slice(slice.method==methods(im),:);
                if isempty(d),continue;end
                xx=d.time_mean_s; yy=d.tv_mean;
                % A zero-count TV is a censored MC estimate for log plotting.
                yyplot=max(yy,1e-6);
                plot(ax,xx,yyplot,'o','Color',colors(im,:), ...
                    'MarkerFaceColor','w','MarkerSize',4,'HandleVisibility','off');
                front=d(d.pareto,:);
                [xf,order]=sort(front.time_mean_s);
                yf=max(front.tv_mean(order),1e-6);
                plot(ax,xf,yf,'-o','LineWidth',1.6, ...
                    'Color',colors(im,:),'MarkerFaceColor',colors(im,:), ...
                    'MarkerSize',5,'DisplayName',char(methods(im)));
                % Mean repeat-level TV uncertainty (t CI); MC CI stored
                % separately in E5_run_summary.csv.
                for q=1:numel(xf)
                    er=max(front.tv_ci95_half(order(q)),0);
                    if ~isfinite(er),continue;end
                    hi=max(yf(q)+er,1e-8);lo=max(yf(q)-er,1e-8);
                    line(ax,[xf(q) xf(q)],[lo hi],'Color',colors(im,:), ...
                        'LineWidth',1,'HandleVisibility','off');
                end
            end
            target=Ns(in)^(-1/2);
            yline(ax,target,'k--',sprintf('N^{-1/2}=%.2g',target), ...
                'LabelHorizontalAlignment','left','HandleVisibility','off');
            set(ax,'XScale','log','YScale','log');
            title(ax,sprintf('K=%d, N=%g',Ks(ik),Ns(in)),'FontWeight','normal');
            xlabel(ax,'Wall-clock time (s)');ylabel(ax,'TV distance');
            ylim(ax,[1e-6 1.1]);
        end
    end
    title(til,sprintf('E5 Time-accuracy Pareto front | %s',char(noises(inoise))));
    % Draw a simple legend on the final tile, independent of Pareto subsets.
    hx=gobjects(1,numel(methods));
    for il=1:numel(methods)
        hx(il)=plot(ax,nan,nan,'-o','Color',colors(il,:), ...
            'MarkerFaceColor',colors(il,:),'DisplayName',char(methods(il)));
    end
    legend(ax,hx,cellstr(methods),'Location','best');
    % Editable vector SVG; no raster image embedded inside.
    fbase=fullfile(out_dir,['E5_FigureI_' char(noises(inoise))]);
    print(fig,[fbase '.svg'],'-dsvg','-painters');
    print(fig,[fbase '.png'],'-dpng','-r180');
    close(fig);
end
end
function [m,s,half]=e5_mean_ci(x)
x=x(isfinite(x)); n=numel(x);
if n==0,m=NaN;s=NaN;half=NaN;return;end
m=mean(x);
if n==1,s=NaN;half=NaN;return;end
s=std(x,0);
if n==10, q=2.262157; % t_{9,0.975}
elseif n==20,q=2.093024; % t_{19,0.975}
elseif exist('tinv','file')==2,q=tinv(0.975,n-1);
else, q=1.96*sqrt(n/(n-2));end
half=q*s/sqrt(n);
end

