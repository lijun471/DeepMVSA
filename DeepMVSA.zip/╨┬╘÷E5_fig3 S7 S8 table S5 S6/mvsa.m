function [M,Sest,Up,my,sing_values] = mvsa(Y,p,varargin)

%% [M,Up,my,sing_values] = mvsa(Y,p,varargin)
%
%  Minimum Volume Simplex Analysis (MVSA)
%
%% --------------- Description ---------------------------------------------
%
%  MVSA Estimates the vertices  M={m_1,...m_p} of the (p-1)-dimensional
%  simplex of minimum volume containing the vectors [y_1,...y_N], under the
%  assumption that y_i belongs to a (p-1)  dimensional affine set. Thus,
%  any vector y_i   belongs  to the convex hull of  the columns of M; i.e.,
%
%                   y_i = M*x_i
%
%  where x_i belongs to the probability (p-1)-simplex.
%
%  As described in the papers [1], [2], matrix M is  obtained by implementing
%  the following steps:
%
%   1-Project y onto a p-dimensional subspace containing the data set y
%
%            yp = Up'*y;      Up is an isometric matrix (Up'*Up=Ip)
%
%   2- solve the   optimization problem
%
%     Q^* = arg min_Q  -\log abs(det(Q))
%
%      subject to: Q*yp >= 0 and ones(1,p)*Q=mq,
%
%     where mq = ones(1,N)*yp'inv(yp*yp)
%
%   3- Compute
%
%      M = Up*inv(Q^*);
%
%% -------------------- Line of Attack  -----------------------------------
%
%  MVSA implements a  sequence of quadratic constrained subproblems. At
%  each iteration the gradient of the objective function is replaced
%  by a quadratic approximation followed by a line-search type procedure.
%
% ------------------------------------------------------------------------
%%  ===== Required inputs =============
%
% y - matrix with  L(channels) x N(pixels).
%     each pixel is a linear mixture of p endmembers
%     signatures y = M*x + noise,
%
%     MVSA assumes that y belongs to an affine space. It may happen,
%     however, that the data supplied by the user is not in an affine
%     set. For this reason, the first step this code implements
%     is the estimation of the affine set the best represent
%     (in the l2 sense) the data.
%
%  p - number of independent columns of M. Therefore, M spans a
%  (p-1)-dimensional affine set.
%
%
%%  ====================== Optional inputs =============================
%
%  'MM_ITERS' = double; Default 4;
%
%               Maximum number of constrained quadratic programs
%
%
%  'spherize'  = {'yes', 'no'}; Default 'yes'
%
%              Applies a spherization step to data such that the spherized
%              data spans over the same range along any axis.
%
%
%  'MU' = double; Default; 1e-6
%
%               Maximum eigenvalue of the quadratic approximation term
%
%
%  'LAMBDA' = double; Default; 1e-10
%
%               Spherization regularization parameter
%
%  'TOLF'  = double; Default; 1e-2
%
%              Tolerance for the termination test (relative variation of f(Q))
%
%
%
%  'M0'  =  <[Lxp] double>; Given by the VCA algorithm
%
%            Initial M.
%
%
%  'verbose'   = {0,1,2}; Default 1
%
%                 0 - work silently
%                 1 - display MVSA warnings
%                 2 - display MVSA and MATLAB warnings
%
%
%
%
%%  =========================== Outputs ==================================
%
% M  =  [Lxp] estimated mixing matrix
%
% Up =  [Lxp] isometric matrix spanning  the same subspace as M
%
% my =   mean value of y
%
% sing_values  = (p-1) eigenvalues of Cy = (y-my)*(y-my)/N. The dynamic range
%                  of these eigenvalues gives an idea of the  difficulty of the
%                  underlying problem
%
%
% NOTE: the identified affine set is given by
%
%              {z\in R^p : z=Up(:,1:p-1)*a+my, a\in R^(p-1)}
%
%% -------------------------------------------------------------------------
%
% Copyright (May, 2009):        Jos Bioucas-Dias (bioucas@lx.it.pt)
%                               Jun li (jun@lx.it.pt)
%
% MVSA is distributed under the terms of
% the GNU General Public License 2.0.
%
% Permission to use, copy, modify, and distribute this software for
% any purpose without fee is hereby granted, provided that this entire
% notice is included in all copies of any software which is or includes
% a copy or modification of this software and in all copies of the
% supporting documentation for such software.
% This software is being provided "as is", without any express or
% implied warranty.  In particular, the authors do not make any
% representation or warranty of any kind concerning the merchantability
% of this software or its fitness for any particular purpose."
% ----------------------------------------------------------------------
%
% More details in:
%
% [1] Jun Li and Jos M. Bioucas-Dias
%     "Minimum volume simplex analysis: A fast algorithm to unmix hyperspectral data"
%      in IEEE International Geoscience and Remote sensing Symposium IGARSS2008, Boston, USA,  2008
%
% [2] Jun Li and Jos M. Bioucas-Dias
%     "Minimum volume simplex analysis: A new algorithm to unmix
%     hyperspectral Data", IEEE Transactions on Geoscience and Remote
%     Sensing, 2009 (submitted).
%
% -------------------------------------------------------------------------

%%
%--------------------------------------------------------------
% test for number of required parametres
%--------------------------------------------------------------
if (nargin-length(varargin)) ~= 2
    error('Wrong number of required parameters');
end
% data set size
[L,N] = size(Y);
if (L<p)
    error('Insufficient number of columns in y');
end
%%
%--------------------------------------------------------------
% Set the defaults for the optional parameters
%--------------------------------------------------------------
% maximum number of quadratic QPs
MMiters = 10;
spherize = 'yes';
% display only MVSA warnings
verbose = 1;
% spherization regularization parameter
lambda = 1e-10;
% quadractic regularization parameter for the Hesssian
% Hreg = = mu*I+H
mu = 1e-6;
% no initial simplex
M = 0;
% tolerance for the termination test
tol_f = 1e-2;

% Optional OS-process optimization-memory measurement (Windows only).
% This instrumentation does not change the MVSA optimization itself.
measure_opt_memory = false;
memory_sample_interval_ms = 30;
memory_baseline_samples = 3;

%%
%--------------------------------------------------------------
% Local variables
%--------------------------------------------------------------
% maximum violation of inequalities
slack = 1e-3;
% flag energy decreasing
any_energy_decreasing = 0;
% used in the termination test
f_val_back = inf;
%--------------------------------------------------------------
% Read the optional parameters
%--------------------------------------------------------------
if (rem(length(varargin),2)==1)
    error('Optional parameters should always go by pairs');
else
    for i=1:2:(length(varargin)-1)
        switch upper(varargin{i})
            case 'MM_ITERS'
                MMiters = varargin{i+1};
            case 'SPHERIZE'
                spherize = varargin{i+1};
            case 'MU'
                mu = varargin{i+1};
            case  'LAMBDA'
                lambda = varargin{i+1};
            case 'TOLF'
                tol_f = varargin{i+1};
            case 'M0'
                M = varargin{i+1};
            case 'VERBOSE'
                verbose = varargin{i+1};
            case 'MEASURE_OPT_MEMORY'
                measure_opt_memory = logical(varargin{i+1});
            case 'MEMORY_SAMPLE_INTERVAL_MS'
                memory_sample_interval_ms = varargin{i+1};
            case 'MEMORY_BASELINE_SAMPLES'
                memory_baseline_samples = varargin{i+1};
            otherwise
                % Hmmm, something wrong with the parameter string
                error(['Unrecognized option: ''' varargin{i} '''']);
        end;
    end;
end

%%
%--------------------------------------------------------------
% set display mode
%--------------------------------------------------------------
if (verbose == 0) | (verbose == 1)
    warning('off','all');
    options = optimset('Display', 'off','Diagnostics','off','MaxIter',2000,'TolFun',1e-10,'TolX',1e-10 );
else
    warning('on','all');
    options = optimset('Display', 'final','Diagnostics','on','MaxIter',2000,'TolFun',1e-10,'TolX',1e-10);
end

%%
%--------------------------------------------------------------
% identify the affine space that best represent the data set y
%--------------------------------------------------------------
my = mean(Y,2);
Y = Y-repmat(my,1,N);
[Up,D] = svds(Y*Y'/N,p-1);
% represent y in the subspace R^(p-1)
Y = Up*Up'*Y;
% lift y
Y = Y + repmat(my,1,N); 
% compute the orthogonal component of my
my_ortho = my-Up*Up'*my;
% define another orthonormal direction
Up = [Up my_ortho/sqrt(sum(my_ortho.^2))];
sing_values = diag(D);
% get coordinates in R^p
Y = Up'*Y;
%%
%------------------------------------------
% spherize if requested
%------------------------------------------
if strcmp(spherize,'yes')
    Y = Up*Y;
    Y = Y-repmat(my,1,N);
    C = diag(1./sqrt((diag(D+lambda*eye(p-1)))));
    Y=C*Up(:,1:p-1)'*Y;
    %  lift
    Y(p,:) = 1;
    % normalize to unit norm
    Y = Y/sqrt(p);
end


%---------------------------------------------
%  Initialization
%---------------------------------------------
if M == 0
    % Initialize with VCA
    Mvca = VCA(Y,'Endmembers',p);
    M = Mvca;
    % expand Q
    Ym = mean(M,2);
    Ym = repmat(Ym,1,p);
    dQ = M - Ym;
    % fraction: multiply by p is to make sure Q0 starts with a feasible
    % initial value.
    M = M + p*dQ;
else
    % Ensure that M is in the affine set defined by the data
    M = M-repmat(my,1,p);
    M = Up(:,1:p-1)*Up(:,1:p-1)'*M;
    M = M +  repmat(my,1,p);
    M = Up'*M;   % represent in the data subspace
    % is sherization is set
    if strcmp(spherize,'yes')
        M = Up*M-repmat(my,1,p);
        M=C*Up(:,1:p-1)'*M;
        %  lift
        M(p,:) = 1;
        % normalize to unit norm
        M = M/sqrt(p);
    end
end
Q0 = inv(M);
Q=Q0;


%%
%---------------------------------------------
%  build constraint matrices
%---------------------------------------------
% inequality matrix
%A = kron(Y',eye(p));   % size np * p^2
% equality matrx
E = kron(eye(p),ones(1,p));
% equality independent vector
qm = sum(inv(Y*Y')*Y,2);

%% ---------------- MVSA optimization-memory measurement ----------------
% START: after MVSA preprocessing/spherization/VCA initialization/Q0/qm,
%        immediately before the sequence of QP optimization iterations.
% STOP : immediately after the QP optimization loop.
% The metric used for Table 1 is Delta Private Mem = peak private committed
% memory during this interval minus the baseline private committed memory.
opt_mem_monitor = struct();
opt_mem_guard = [];
opt_baseline_ws_mb = NaN;
opt_baseline_private_mb = NaN;
opt_tic = [];

if measure_opt_memory
    if ~ispc
        error(['MEASURE_OPT_MEMORY=true currently requires Windows because ' ...
               'the monitor uses PowerShell Get-Process.']);
    end
    matlab_pid = feature('getpid');
    opt_mem_monitor = start_process_memory_monitor( ...
        matlab_pid, round(memory_sample_interval_ms), 10);
    opt_mem_guard = onCleanup(@() cleanup_monitor_files(opt_mem_monitor)); %#ok<NASGU>
    [opt_baseline_ws_mb, opt_baseline_private_mb] = ...
        measure_process_memory_snapshot( ...
        matlab_pid, round(memory_baseline_samples), 0.03);
    signal_process_memory_monitor_go(opt_mem_monitor);
    opt_tic = tic;
end

%%
%---------------------------------------------
%  sequence of QPs - main body
%---------------------------------------------
throtle = 0;
for k = 1:MMiters
    % make initial point feasible
    M = inv(Q);
    Ym = mean(M,2);
    Ym = repmat(Ym,1,p);
    dW = M - Ym;
    count = 0;
    if ~throtle
        while sum(sum( (inv(M)*Y) < 0  )) > 0
            fprintf('\n making M feasible...\n')
            M = M + 0.01*dW;
            count = count + 1;
            if count > 100
                if verbose
                    fprintf('\n could not make M feasible after 100 expansions\n')
                end
                break;
            end
        end
    end
    Q = inv(M);
    % gradient of -log(abs(det(Q)))
    g = -M';
    g = g(:);

    % quadractic term (mu*I+diag(H))
    H = mu*eye(p^2)+diag(g.^2);
    q0 = Q(:);
    Q0 = Q;
    f=g-H*q0;

    % initial function values (true and quadratic)
    f0_val  = -log(abs(det(Q0)));
    f0_quad = f0_val % (q-q0)'*g+1/2*(q-q0)'*H*(q-q0);

    % anergy decreasing in this quadratic problem
    energy_decreasing = 0;
    
    %%%%%%%%%%%%%% QP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    q  = quadProg1(H, f, Y, zeros(p*N,1), E, qm, q0, throtle);
    exitflag = 1;
    if  exitflag < 0 % quadprog did not converge
        if verbose
            fprintf('\n iter = %d, quadprog did not converge: exitflag = %d \n', k, exitflag);
        end
        if k == MMiters
           if ~any_energy_decreasing
               if verbose
                   fprintf('\n outputing the VCA solution\n');
               end
               Q = inv(Mvca);
               q = Q(:);
           else
               if verbose
                   fprintf('\n outputing the solution of the previous iteration\n');
               end
              Q = Q0;
              q = Q(:);
           end
        else
            % run again with a larger mu
            Q = Q0;
            q = Q(:);
            mu = 1e-2;
        end
    elseif exitflag == 0 % Number of iterations exceeded options.MaxIter.
        % compute  energy of the quadratic approximation
        f_quad = f0_val + (q-q0)'*g+1/2*(q-q0)'*H*(q-q0);
        %if verbose
            fprintf('\n iterations exceeded: iter = %d, f0_quad = %2.4f, f_quad = %2.4f \n',...
                k, f0_quad, f_quad)
        %end
        %test for energy decreasing and feasibility
        if (f0_quad > f_quad) & (sum(sum( Q*Y < -slack  )) == 0)
            %if verbose
                fprintf('\n test for quadratic energy decreasing and feasibility PASSED\n')
            %end
            % there will be surely an energy decreasing between for Q
            % between the current Q and Q0
            energy_decreasing = 1;
            any_energy_decreasing = 1;
        else
            %if verbose
                fprintf('\n test for quadratic energy decreasing FAILED\n')
                fprintf('\n Incremente H\n')
            %end
            % increment H
            Q = Q0;
            q = Q(:);
            mu = 1e-2;
        end
    end

    % energy_decreasing == 1 means that  although exitflag ~= 1, the
    % energy of the quadratic approximation decreased.
    % exiflaf == 1 implies that the energy of the quadratic approximation
    % decreased.
    if energy_decreasing || (exitflag == 1)
        Q = reshape(q,p,p);
        %f_bound
        f_val = -log(abs(det(Q)));
        if verbose
            fprintf('\n iter = %d, f0 = %2.4f, f = %2.4f, exitflag = %d \n',...
                k, f0_val,f_val,exitflag)
        end
        % line search
        if (f0_val < f_val)
            Q = Q0;
            if throtle == 1
                break
            else
                throtle = 1;
            end
        else 
            throtle = 0;
        end
    
%         while (f0_val < f_val)
%             linesearch = 1;
%             % Q and Q0 are in a convex set and f(alpha*Q0+(1-alpha)Q) <
%             % f(Q0)  for some alpha close to zero
%             Q = (Q+Q0)/2;
%             f_val = -log(abs(det(Q)));
%             if verbose
%                 fprintf('\n doing line search: counts = %d, f0 = %2.4f, f = %2.4f\n', ...
%                     counts, f0_val, f_val)
%             end
%             counts = counts + 1;
%             if counts > 20
%                 fprintf('\n something wrong with the line search\n')
%                 if k == MMiters
%                     if ~energy_decreasing
%                         fprintf('\n outputing the VCA solution\n');
%                         Q = inv(Mvca);
%                     else
%                         fprintf('\n outputing the solution of the previous iteration\n');
%                         Q = Q0;
%                     end
%                 else
%                     % run again with a larger mu
%                     Q = Q0;
%                     mu = 1e-2;
%                 end
%             end
%         end
        energy_decreasing = 1;
    end
    % termination test
    if energy_decreasing
        if abs((f_val_back-f_val)/f_val) < tol_f && ~throtle
            if verbose
                fprintf('\n iter: = %d termination test PASSED \n', k)
            end
            break;
        end
        f_val_back = f_val;
    end
end

%% -------- End MVSA optimization-memory measurement --------
if measure_opt_memory
    optimization_runtime_sec = toc(opt_tic);
    [opt_peak_ws_mb, opt_peak_private_mb, opt_monitor_samples] = ...
        stop_process_memory_monitor(opt_mem_monitor, 10);
    opt_working_memory_mb = max(opt_peak_ws_mb - opt_baseline_ws_mb, 0);
    opt_delta_private_mb = max(opt_peak_private_mb - opt_baseline_private_mb, 0);

    fprintf('\n===============================================================\n');
    fprintf('MVSA OPTIMIZATION-MEMORY MEASUREMENT\n');
    fprintf('---------------------------------------------------------------\n');
    fprintf('N                              : %d\n', N);
    fprintf('K                              : %d\n', p - 1);
    fprintf('p = K+1                        : %d\n', p);
    fprintf('Baseline WorkingSet            : %.2f MB\n', opt_baseline_ws_mb);
    fprintf('Peak WorkingSet (optimization) : %.2f MB\n', opt_peak_ws_mb);
    fprintf('WorkingSet Delta (diagnostic)  : %.2f MB\n', opt_working_memory_mb);
    fprintf('Baseline Private Mem           : %.2f MB\n', opt_baseline_private_mb);
    fprintf('Peak Private Mem               : %.2f MB\n', opt_peak_private_mb);
    fprintf('Delta Private Mem              : %.2f MB   <-- Table 1 memory\n', opt_delta_private_mb);
    fprintf('Optimization runtime           : %.6f sec\n', optimization_runtime_sec);
    fprintf('Monitor samples                : %d\n', round(opt_monitor_samples));
    fprintf('Monitor interval               : %d ms\n', round(memory_sample_interval_ms));
    fprintf('===============================================================\n\n');
    clear opt_mem_guard
end

if strcmp(spherize,'yes')
    M = inv(Q);
    %M(1,:)
    % refer to the initial affine set
    % unscale
    M = M*sqrt(p);
    %remove offset
    M = M(1:p-1,:);
    % unspherize
    M = Up(:,1:p-1)*diag(sqrt(diag(D+lambda*eye(p-1))))*M;
    % sum ym
    M = M + repmat(my,1,p);
    Sest = Q*Y;
else
    M = inv(Q);%*sqrt(my_ortho'*my_ortho)
    M = Up*M;%*sqrt(my_ortho'*my_ortho);;
    Sest = Q*Y;
end



% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% % %

end

%% ===================== Theorem 3.2 memory-monitor helpers =====================
function monitor = start_process_memory_monitor(target_pid, interval_ms, timeout_sec)
%START_PROCESS_MEMORY_MONITOR Launch an asynchronous PowerShell sampler.
% The sampler waits for a GO file, so preprocessing/initialization are not
% included in the measured optimization interval.

    token = char(java.util.UUID.randomUUID);
    base = fullfile(tempdir, ['dmvsa_t32_mem_' token]);

    monitor.script_file = [base '.ps1'];
    monitor.ready_file = [base '_ready.flag'];
    monitor.go_file = [base '_go.flag'];
    monitor.stop_file = [base '_stop.flag'];
    monitor.out_file = [base '_result.txt'];

    cleanup_monitor_files(monitor);

    fid = fopen(monitor.script_file, 'w');
    if fid < 0
        error('Could not create temporary PowerShell monitor script.');
    end
    script_guard = onCleanup(@() fclose_if_open(fid)); %#ok<NASGU>

    fprintf(fid, 'param([int]$TargetPid,[string]$ReadyFile,[string]$GoFile,[string]$StopFile,[string]$OutFile,[int]$IntervalMs)\r\n');
    fprintf(fid, '$peakWS = [int64]0\r\n');
    fprintf(fid, '$peakPrivate = [int64]0\r\n');
    fprintf(fid, '$count = 0\r\n');
    fprintf(fid, 'Set-Content -LiteralPath $ReadyFile -Value "ready" -Encoding ascii\r\n');
    fprintf(fid, 'while ((-not (Test-Path -LiteralPath $GoFile)) -and (-not (Test-Path -LiteralPath $StopFile))) { Start-Sleep -Milliseconds 5 }\r\n');
    fprintf(fid, 'while (-not (Test-Path -LiteralPath $StopFile)) {\r\n');
    fprintf(fid, '  try {\r\n');
    fprintf(fid, '    $proc = Get-Process -Id $TargetPid -ErrorAction Stop\r\n');
    fprintf(fid, '    $ws = [int64]$proc.WorkingSet64\r\n');
    fprintf(fid, '    $pr = [int64]$proc.PrivateMemorySize64\r\n');
    fprintf(fid, '    if ($ws -gt $peakWS) { $peakWS = $ws }\r\n');
    fprintf(fid, '    if ($pr -gt $peakPrivate) { $peakPrivate = $pr }\r\n');
    fprintf(fid, '    $count++\r\n');
    fprintf(fid, '  } catch { break }\r\n');
    fprintf(fid, '  Start-Sleep -Milliseconds $IntervalMs\r\n');
    fprintf(fid, '}\r\n');
    fprintf(fid, 'try {\r\n');
    fprintf(fid, '  $proc = Get-Process -Id $TargetPid -ErrorAction Stop\r\n');
    fprintf(fid, '  $ws = [int64]$proc.WorkingSet64\r\n');
    fprintf(fid, '  $pr = [int64]$proc.PrivateMemorySize64\r\n');
    fprintf(fid, '  if ($ws -gt $peakWS) { $peakWS = $ws }\r\n');
    fprintf(fid, '  if ($pr -gt $peakPrivate) { $peakPrivate = $pr }\r\n');
    fprintf(fid, '  $count++\r\n');
    fprintf(fid, '} catch {}\r\n');
    fprintf(fid, 'Set-Content -LiteralPath $OutFile -Value (("{0},{1},{2}" -f $peakWS,$peakPrivate,$count)) -Encoding ascii\r\n');

    fclose(fid);
    fid = -1;

    cmd = sprintf(['start "" /B powershell.exe -NoProfile -WindowStyle Hidden ' ...
        '-ExecutionPolicy Bypass -File "%s" -TargetPid %d -ReadyFile "%s" ' ...
        '-GoFile "%s" -StopFile "%s" -OutFile "%s" -IntervalMs %d'], ...
        monitor.script_file, target_pid, monitor.ready_file, monitor.go_file, ...
        monitor.stop_file, monitor.out_file, interval_ms);

    [status, cmdout] = system(cmd);
    if status ~= 0
        cleanup_monitor_files(monitor);
        error('Could not start PowerShell memory monitor: %s', strtrim(cmdout));
    end

    wait_for_file(monitor.ready_file, timeout_sec, ...
        'PowerShell memory monitor did not become ready in time.');
end

function signal_process_memory_monitor_go(monitor)
%SIGNAL_PROCESS_MEMORY_MONITOR_GO Start sampling the optimization interval.
    fid = fopen(monitor.go_file, 'w');
    if fid < 0
        error('Could not create monitor GO signal file.');
    end
    fprintf(fid, 'go\n');
    fclose(fid);
end

function [peak_ws_mb, peak_private_mb, count] = stop_process_memory_monitor(monitor, timeout_sec)
%STOP_PROCESS_MEMORY_MONITOR Stop sampler and parse peak process memory.
    fid = fopen(monitor.stop_file, 'w');
    if fid < 0
        error('Could not create monitor STOP signal file.');
    end
    fprintf(fid, 'stop\n');
    fclose(fid);

    wait_for_file(monitor.out_file, timeout_sec, ...
        'PowerShell memory monitor did not return a result in time.');

    raw = strtrim(fileread(monitor.out_file));
    vals = sscanf(raw, '%f,%f,%f');
    if numel(vals) ~= 3
        error('Unexpected monitor result: %s', raw);
    end

    peak_ws_mb = vals(1) / (1024^2);
    peak_private_mb = vals(2) / (1024^2);
    count = vals(3);

    if count < 1
        error('The memory monitor returned zero samples.');
    end
end

function [ws_mb, private_mb] = measure_process_memory_snapshot(target_pid, n_samples, pause_sec)
%MEASURE_PROCESS_MEMORY_SNAPSHOT Median baseline from OS process snapshots.
    ws = zeros(1, n_samples);
    pr = zeros(1, n_samples);

    for i = 1:n_samples
        [ws(i), pr(i)] = query_process_memory_bytes(target_pid);
        if i < n_samples
            pause(pause_sec);
        end
    end

    ws_mb = median(ws) / (1024^2);
    private_mb = median(pr) / (1024^2);
end

function [ws_bytes, private_bytes] = query_process_memory_bytes(target_pid)
%QUERY_PROCESS_MEMORY_BYTES Current WorkingSet64 and PrivateMemorySize64.
    cmd = sprintf(['powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ' ...
        '"$proc=Get-Process -Id %d -ErrorAction Stop; ' ...
        'Write-Output (((''{0},{1}'') -f $proc.WorkingSet64,$proc.PrivateMemorySize64))"'], ...
        target_pid);

    [status, out] = system(cmd);
    if status ~= 0
        error('PowerShell baseline memory query failed: %s', strtrim(out));
    end

    vals = sscanf(strtrim(out), '%f,%f');
    if numel(vals) ~= 2
        error('Unexpected PowerShell baseline output: %s', strtrim(out));
    end

    ws_bytes = vals(1);
    private_bytes = vals(2);
end

function wait_for_file(file_name, timeout_sec, err_msg)
%WAIT_FOR_FILE Wait for monitor synchronization/result file.
    t0 = tic;
    while ~exist(file_name, 'file')
        pause(0.02);
        if toc(t0) > timeout_sec
            error('%s', err_msg);
        end
    end
end

function cleanup_monitor_files(monitor)
%CLEANUP_MONITOR_FILES Best-effort stop and removal of temporary files.
    if isfield(monitor, 'stop_file') && ~exist(monitor.stop_file, 'file')
        fid = fopen(monitor.stop_file, 'w');
        if fid >= 0
            fprintf(fid, 'stop\n');
            fclose(fid);
        end
    end

    fields = {'ready_file','go_file','out_file','script_file','stop_file'};
    for i = 1:numel(fields)
        f = fields{i};
        if isfield(monitor, f)
            file_name = monitor.(f);
            if exist(file_name, 'file')
                try
                    delete(file_name);
                catch
                    % Best-effort cleanup only.
                end
            end
        end
    end
end

function fclose_if_open(fid)
%FCLOSE_IF_OPEN Best-effort file-handle cleanup on error paths.
    if isnumeric(fid) && isscalar(fid) && fid >= 0
        try
            fclose(fid);
        catch
        end
    end
end


