% demo_H5_phase_formal_script.m
% ========================================================================
% DeepMVSA H5: (gamma_vol, gamma_enc) two-factor phase map and shrinkage fit
%
% This is a MATLAB SCRIPT (not a main function) for the H5 production experiment.
% It calls deep_mvsa_invflow_H5.m, an H5-specific model fork based on E3.
% The H5 two-stage protocol is:
%   (1) warm-up: kappa/gating branch disabled and Q fixed at Q0;
%   (2) joint: Q is released and the volume penalty is activated.
%
% H5 protocol basis: H5_design.docx, Section H5; common settings/Table S3;
% Table S1 one-factor grid is retained exactly in the two central slices.
%
% IMPORTANT metric distinction:
%   volume_ratio = Vol(M_hat)/Vol(M_true)
%   shrinkage_log = log(Vol(M_true)/Vol(M_hat))
% The Supplement's shrinkage variable in the theoretical bound is the
% logarithmic shrinkage_log, not volume_ratio. Both are saved separately.
% The fitted s* shape curve is fitted to positive shrinkage_log values.
%
% Outputs (outputs_h5_formal_DTV_Fig1/):
%   h5_meta.mat                 fixed synthetic data + configuration
%   h5_checkpoint.mat           resumable per-run records
%   h5_results.mat              final complete result package
%   h5_run_summary.csv          one row per run
%   h5_cell_summary.csv         cell means, SDs, 95% CI half-widths
%   h5_tableS1_check.csv        SNR30 one-factor slice comparison
%   h5_run.log                  execution log
%   h5_figP_TV.png/.svg         TV heatmaps
%   h5_figP_volume_ratio.png/.svg volume-ratio heatmaps
%   h5_figP_s.png/.svg          log-shrinkage heatmaps + fitted s*=1 curve
%
% Run:
%   Run this script directly (press F5 or type demo_H5_phase_formal_script)
%
% Resume is enabled by default. To restart from scratch, set cfg.resume=false
% below and remove/rename outputs_h5_formal if old results should be discarded.
% ========================================================================

clear;
clc;
close all;

%% ------------------------- 0. Configuration ----------------------------
cfg = struct();
cfg.K = 5;
cfg.N = 10000;
cfg.seed_data = 425;

% Seven-point logarithmic grid (49 two-factor cells). The grid includes
% the default point and brackets C' ~= 0.0225. Exact Table S1 factor levels
% not lying on this 7-point grid are run separately as SNR30 validation cells.
cfg.gamma_vol = logspace(log10(0.0025), log10(0.04), 7);
cfg.gamma_enc = logspace(log10(2.5), log10(40), 7);
cfg.default_gamma_vol = 0.01;
cfg.default_gamma_enc = 10.0;
cfg.s1_validation_pairs = [0.005 10.0; 0.02 10.0; 0.01 5.0; 0.01 20.0];
cfg.C_prime = 1 / (32 * log(4));

cfg.noise_names = {'clean', 'snr30'};
cfg.snr_db = 30;
cfg.reps = 20;

% Section 4.1 / SI Table S3 synthetic-data training configuration.
cfg.iters = 1500;
cfg.warmup = 600;
cfg.lr = 1e-3;
cfg.batch_size = 4096;
cfg.hidden = 32;
cfg.lambda_nonneg = 5;
cfg.lambda_eq = 80;
cfg.lambda_sumone = 2;
cfg.kappa0 = 0.05;
cfg.freeze_Q_warmup = true;
cfg.coord_mode = 'auto';
cfg.spherize = 'yes';

% TV Monte-Carlo sample count. Retain the H5 design value (20,000).
% The DTV estimator itself follows Fig.1's symmetric intersection-volume method.
cfg.n_mc_tv = 20000;
cfg.dtv_method = 'fig1_symmetric_intersection_v1';
cfg.seed_train_base = 1001;
cfg.seed_tv_base = 810001;
cfg.seed_bootstrap = 90210;
cfg.n_bootstrap = 1000;

% Execution controls.
cfg.resume = true;
cfg.retry_failed = false;
cfg.verbose_model = 0;

outDir = fullfile(fileparts(mfilename('fullpath')), 'outputs_h5_formal_DTV_Fig1');
if ~exist(outDir, 'dir'), mkdir(outDir); end
metaPath = fullfile(outDir, 'h5_meta.mat');
checkpointPath = fullfile(outDir, 'h5_checkpoint.mat');
logPath = fullfile(outDir, 'h5_run.log');

if exist('deep_mvsa_invflow_H5', 'file') ~= 2
    error('Cannot find deep_mvsa_invflow_H5.m. Put it in the same folder ', ...
           'as demo_H5_phase_formal_script.m.');
end

cfg_core = make_cfg_core(cfg);

%% ------------------------- 1. Log and data -----------------------------
logFid = fopen(logPath, 'a');
if logFid < 0, error('Cannot open log file: %s', logPath); end
logCleanup = onCleanup(@() fclose(logFid)); %#ok<NASGU>
logmsg(logFid, '\n============================================================');
logmsg(logFid, 'H5 formal run started: %s', datestr(now, 31));
logmsg(logFid, 'Grid: %d x %d; noises=%d; reps=%d; expected runs=%d', ...
    numel(cfg.gamma_vol), numel(cfg.gamma_enc), numel(cfg.noise_names), ...
    cfg.reps, numel(cfg.gamma_vol)*numel(cfg.gamma_enc)*numel(cfg.noise_names)*cfg.reps);
logmsg(logFid, 'Default point=(%.6g, %.6g), Cprime=%.8g', ...
    cfg.default_gamma_vol, cfg.default_gamma_enc, cfg.C_prime);

% Reuse the exact same synthetic dataset when resuming.
if cfg.resume && exist(metaPath, 'file') == 2
    T = load(metaPath, 'meta');
    if ~isfield(T, 'meta') || ~isfield(T.meta, 'cfg_core') || ...
            ~isequaln(T.meta.cfg_core, cfg_core)
        error(['Existing h5_meta.mat has a different experiment configuration. ', ...
               'Set cfg.resume=false and restart in a clean output folder.']);
    end
    meta = T.meta;
    M_true = meta.M_true;
    A_true = meta.A_true;
    Y_clean = meta.Y_clean;
    Y_snr30 = meta.Y_snr30;
    logmsg(logFid, 'Loaded fixed data from h5_meta.mat.');
else
    [M_true, A_true, Y_clean, Y_snr30, noiseMatrix] = make_h5_data(cfg);
    meta = struct();
    meta.cfg = cfg;
    meta.cfg_core = cfg_core;
    meta.M_true = M_true;
    meta.A_true = A_true;
    meta.Y_clean = Y_clean;
    meta.Y_snr30 = Y_snr30;
    meta.noise_matrix = noiseMatrix;
    meta.created_at = datestr(now, 31);
    save(metaPath, 'meta', '-v7');
    logmsg(logFid, 'Generated and saved paired synthetic data.');
end

%% ------------------------- 2. Load checkpoint --------------------------
rows = empty_run_rows();
if cfg.resume && exist(checkpointPath, 'file') == 2
    T = load(checkpointPath, 'rows', 'cfg_core_saved');
    if isfield(T, 'cfg_core_saved') && ~isequaln(T.cfg_core_saved, cfg_core)
        error('Checkpoint configuration differs from the current H5 configuration.');
    end
    if isfield(T, 'rows') && ~isempty(T.rows)
        rows = T.rows;
    end
    logmsg(logFid, 'Loaded checkpoint: %d/%d runs already recorded.', ...
        numel(rows), expected_run_count(cfg));
end
cfg_core_saved = cfg_core; %#ok<NASGU>

%% ------------------------- 3. Main experiment --------------------------
totalExpected = expected_run_count(cfg);
runCounter = numel(rows);

% Main 7 x 7 factorial grid under both noise regimes.
for iNoise = 1:numel(cfg.noise_names)
    noiseName = cfg.noise_names{iNoise};
    if strcmp(noiseName, 'clean')
        Y = Y_clean;
    else
        Y = Y_snr30;
    end
    for iVol = 1:numel(cfg.gamma_vol)
        gv = cfg.gamma_vol(iVol);
        for iEnc = 1:numel(cfg.gamma_enc)
            ge = cfg.gamma_enc(iEnc);
            for rep = 1:cfg.reps
                [rows, runCounter] = run_single_h5(rows, Y, M_true, cfg, ...
                    noiseName, gv, ge, rep, outDir, checkpointPath, ...
                    cfg_core_saved, logFid, runCounter, totalExpected);
            end
        end
    end
end

% Four additional SNR30 cells complete the exact Table S1 one-factor slices.
% They are not duplicated in the 7 x 7 phase-map grid.
for q = 1:size(cfg.s1_validation_pairs, 1)
    gv = cfg.s1_validation_pairs(q, 1);
    ge = cfg.s1_validation_pairs(q, 2);
    for rep = 1:cfg.reps
        [rows, runCounter] = run_single_h5(rows, Y_snr30, M_true, cfg, ...
            'snr30', gv, ge, rep, outDir, checkpointPath, ...
            cfg_core_saved, logFid, runCounter, totalExpected);
    end
end

%% ------------------------- 4. Completeness check -----------------------
write_run_csv(rows, fullfile(outDir, 'h5_run_summary.csv'));
if numel(rows) < totalExpected
    logmsg(logFid, 'INCOMPLETE: %d/%d rows. Re-run to resume.', numel(rows), totalExpected);
    fprintf('\nH5 未完成：%d/%d 次。已保存 checkpoint，可重新运行续跑。\n', ...
        numel(rows), totalExpected);
    return;
end

%% ------------------------- 5. Cell summaries ---------------------------
cells = aggregate_h5_cells(rows, cfg);
cellTable = table({cells.noise}', [cells.gamma_vol]', [cells.gamma_enc]', ...
    [cells.n_runs]', [cells.n_valid_TV]', [cells.n_failed]', [cells.failure_rate]', ...
    [cells.TV_mean]', [cells.TV_sd]', [cells.TV_ci95_halfwidth]', ...
    [cells.volume_ratio_mean]', [cells.volume_ratio_sd]', ...
    [cells.volume_ratio_ci95_halfwidth]', [cells.shrinkage_log_mean]', ...
    [cells.shrinkage_log_sd]', [cells.shrinkage_log_ci95_halfwidth]', ...
    [cells.enc_N_mean]', [cells.enc_N_sd]', [cells.enc_N_ci95_halfwidth]', ...
    'VariableNames', {'noise','gamma_vol','gamma_enc','n_runs','n_valid_TV', ...
    'n_failed','failure_rate','TV_mean','TV_sd','TV_ci95_halfwidth', ...
    'volume_ratio_mean','volume_ratio_sd','volume_ratio_ci95_halfwidth', ...
    'shrinkage_log_mean','shrinkage_log_sd','shrinkage_log_ci95_halfwidth', ...
    'enc_N_mean','enc_N_sd','enc_N_ci95_halfwidth'});
writetable(cellTable, fullfile(outDir, 'h5_cell_summary.csv'));

%% ------------------------- 6. Table S1 consistency check ---------------
S1_check = check_tableS1_consistency(cells, rows, cfg);
write_s1_check_csv(S1_check, fullfile(outDir, 'h5_tableS1_check.csv'));

%% ------------------------- 7. Shrinkage-shape fit -----------------------
fit = fit_shrinkage_shape(cells, rows, cfg);

%% ------------------------- 8. Direction diagnostics and verdict --------
direction = direction_diagnostics(cells, cfg);
verdict = make_h5_verdict(rows, cells, S1_check, fit, direction, cfg);

%% ------------------------- 9. Figures ----------------------------------
plot_h5_heatmaps(cells, fit, cfg, outDir, 'TV_mean', ...
    'h5_figP_TV', 'D_{TV}');
plot_h5_heatmaps(cells, fit, cfg, outDir, 'volume_ratio_mean', ...
    'h5_figP_volume_ratio', 'Vol(Shat) / Vol(ST)');
plot_h5_heatmaps(cells, fit, cfg, outDir, 'shrinkage_log_mean', ...
    'h5_figP_s', 'log(Vol(ST) / Vol(Shat))');

%% ------------------------- 10. Final save ------------------------------
results = struct();
results.cfg = cfg;
results.rows = rows;
results.cells = cells;
results.fit = fit;
results.S1_check = S1_check;
results.direction = direction;
results.verdict = verdict;
results.M_true = M_true;
results.A_true = A_true;
results.Y_clean = Y_clean;
results.Y_snr30 = Y_snr30;
results.created_at = datestr(now, 31);
save(fullfile(outDir, 'h5_results.mat'), 'results', '-v7');

logmsg(logFid, '================ H5 ACCEPTANCE SUMMARY ================');
logmsg(logFid, 'Run count: %d/%d', numel(rows), totalExpected);
logmsg(logFid, 'Table S1 consistency PASS: %d', S1_check.PASS);
logmsg(logFid, 'Shrinkage fit: status=%s, c5=%g, R2=%g, positive cells=%d', ...
    fit.status, fit.c5, fit.R2, fit.n_fit_cells);
logmsg(logFid, 'Overall pipeline verdict: %s', verdict.pipeline_status);
logmsg(logFid, 'H5 completed: %s', datestr(now, 31));

fprintf('\n============================================================\n');
fprintf('H5 正式实验已完成：%d 次训练记录。\n', numel(rows));
fprintf('Table S1 一致性检查：%s\n', pass_text(S1_check.PASS));
fprintf('收缩形状拟合：%s；c5=%.6g；R2=%.4f\n', ...
    fit.status, fit.c5, fit.R2);
fprintf('结果目录：%s\n', outDir);
fprintf('============================================================\n');

%% ========================================================================
% Local helper functions: configuration, data, checkpoint, metrics, plots
% ========================================================================
function cfg_core = make_cfg_core(cfg)
cfg_core = struct();
keep = {'K','N','seed_data','gamma_vol','gamma_enc','default_gamma_vol', ...
    'default_gamma_enc','s1_validation_pairs','C_prime','noise_names','snr_db','reps','iters', ...
    'warmup','lr','batch_size','hidden','lambda_nonneg','lambda_eq', ...
    'lambda_sumone','kappa0','freeze_Q_warmup','coord_mode','spherize', ...
    'n_mc_tv','dtv_method','seed_train_base','seed_tv_base','seed_bootstrap','n_bootstrap'};
for k = 1:numel(keep)
    cfg_core.(keep{k}) = cfg.(keep{k});
end
end

function [M_true, A_true, Y_clean, Y_snr30, E] = make_h5_data(cfg)
rng(cfg.seed_data, 'twister');
G = randn(cfg.K, cfg.K);
[Q, R] = qr(G);
sgn = sign(diag(R));
sgn(sgn == 0) = 1;
M_true = Q * diag(sgn);  % orthogonal unit-norm vertices

% Dirichlet(1,...,1): normalized independent Exp(1) variables.
Eexp = -log(max(rand(cfg.K, cfg.N), realmin));
A_true = Eexp ./ repmat(sum(Eexp, 1), cfg.K, 1);
Y_clean = M_true * A_true;

E = randn(size(Y_clean));
currentSNR = 10 * log10(sum(Y_clean(:).^2) / sum(E(:).^2));
E = E * 10^((currentSNR - cfg.snr_db) / 20);
Y_snr30 = Y_clean + E;
actualSNR = 10 * log10(sum(Y_clean(:).^2) / sum((Y_snr30(:)-Y_clean(:)).^2));
fprintf('Synthetic data: K=%d, N=%d, actual SNR=%.6f dB\n', ...
    cfg.K, cfg.N, actualSNR);
end

function n = expected_run_count(cfg)
nMain = numel(cfg.noise_names) * numel(cfg.gamma_vol) * ...
    numel(cfg.gamma_enc) * cfg.reps;
nS1Extra = size(cfg.s1_validation_pairs, 1) * cfg.reps;
n = nMain + nS1Extra;
end

function rows = empty_run_rows()
rows = struct('noise', {}, 'gamma_vol', {}, 'gamma_enc', {}, 'rep', {}, ...
    'train_seed', {}, 'TV', {}, 'volume_ratio', {}, 'shrinkage_log', {}, ...
    'enc_N', {}, 'failure', {}, 'status', {}, 'wall_s', {}, ...
    'loss_total', {}, 'loss_recon', {}, 'loss_enclose', {}, ...
    'kappa_final', {}, 'error_message', {});
end

function row = make_run_row(noise, gv, ge, rep, seed)
row = struct('noise', noise, 'gamma_vol', gv, 'gamma_enc', ge, ...
    'rep', rep, 'train_seed', seed, 'TV', NaN, 'volume_ratio', NaN, ...
    'shrinkage_log', NaN, 'enc_N', NaN, 'failure', true, ...
    'status', 'not_started', 'wall_s', NaN, 'loss_total', NaN, ...
    'loss_recon', NaN, 'loss_enclose', NaN, 'kappa_final', NaN, ...
    'error_message', '');
end

function idx = find_run_row(rows, noise, gv, ge, rep)
idx = [];
if isempty(rows), return; end
mask = strcmp({rows.noise}, noise) & ...
    abs([rows.gamma_vol] - gv) < 1e-12 & ...
    abs([rows.gamma_enc] - ge) < 1e-12 & [rows.rep] == rep;
idx = find(mask, 1, 'first');
end

function [rows, runCounter] = run_single_h5(rows, Y, M_true, cfg, ...
    noiseName, gv, ge, rep, outDir, checkpointPath, cfg_core_saved, ...
    logFid, runCounter, totalExpected)
oldIdx = find_run_row(rows, noiseName, gv, ge, rep);
if ~isempty(oldIdx)
    if ~(cfg.retry_failed && rows(oldIdx).failure)
        return;
    else
        rows(oldIdx) = [];
    end
end

row = make_run_row(noiseName, gv, ge, rep, cfg.seed_train_base + rep - 1);
tRun = tic;
try
    [M_est, ~, Up, my, theta, ~, fullLoss] = ...
        deep_mvsa_invflow_H5(Y, cfg.K, ...
        'MM_ITERS', cfg.iters, ...
        'WARM_UP', cfg.warmup, ...
        'LR', cfg.lr, ...
        'LAMBDA_VOL', gv, ...
        'LAMBDA_NONNEG', cfg.lambda_nonneg, ...
        'LAMBDA_EQ', cfg.lambda_eq, ...
        'LAMBDA_SUMONE', cfg.lambda_sumone, ...
        'LAMBDA_ENCLOSE', ge, ...
        'BATCH_SIZE', cfg.batch_size, ...
        'SEED', row.train_seed, ...
        'HIDDEN', cfg.hidden, ...
        'KAPPA0', cfg.kappa0, ...
        'FREEZE_Q_WARMUP', cfg.freeze_Q_warmup, ...
        'COORD_MODE', cfg.coord_mode, ...
        'spherize', cfg.spherize, ...
        'E1_MONITOR_INTERVAL', 0, ...
        'E1_TV_MC', cfg.n_mc_tv, ...
        'E3_SKIP_ABUNDANCE_OUTPUT', true, ...
        'verbose', cfg.verbose_model);

    row.wall_s = toc(tRun);
    [row.TV, row.volume_ratio, row.shrinkage_log, row.enc_N] = ...
        evaluate_h5_metrics(Y, M_est, M_true, Up, my, cfg.K, ...
        cfg.n_mc_tv, cfg.seed_tv_base + rep - 1);
    row.loss_total = safe_struct_field(fullLoss, 'total');
    row.loss_recon = safe_struct_field(fullLoss, 'recon');
    row.loss_enclose = safe_struct_field(fullLoss, 'enclose');
    row.kappa_final = safe_struct_field(theta, 'c');

    if all(isfinite([row.TV, row.volume_ratio, row.shrinkage_log, row.enc_N]))
        row.failure = false;
        row.status = 'ok';
    else
        row.failure = true;
        row.status = 'invalid_metric';
        row.error_message = 'One or more final metrics are non-finite.';
    end
catch ME
    row.wall_s = toc(tRun);
    row.failure = true;
    row.status = 'exception';
    row.error_message = ME.message;
end

rows(end+1) = row; %#ok<AGROW>
runCounter = runCounter + 1;
save(checkpointPath, 'rows', 'cfg_core_saved', 'cfg', '-v7');
write_run_csv(rows, fullfile(outDir, 'h5_run_summary.csv'));
logmsg(logFid, ...
    '[%4d/%4d] %-5s gv=%-8.5g ge=%-7.4g rep=%02d TV=%7.4f VolRatio=%8.4f shrink=%8.4f enc_N=%7.4f status=%s time=%6.1fs', ...
    runCounter, totalExpected, noiseName, gv, ge, rep, ...
    row.TV, row.volume_ratio, row.shrinkage_log, row.enc_N, ...
    row.status, row.wall_s);
end

function write_run_csv(rows, path)
%WRITE_RUN_CSV Write one record per row without struct2table scalar ambiguity.
if isempty(rows), return; end

rows = rows(:);
n = numel(rows);

% Text columns are cell arrays so variable-length char vectors are safe.
noise = cell(n,1);
status = cell(n,1);
error_message = cell(n,1);

% Numeric/logical columns are explicitly allocated as n-by-1 vectors.
gamma_vol = nan(n,1);
gamma_enc = nan(n,1);
rep = nan(n,1);
train_seed = nan(n,1);
TV = nan(n,1);
volume_ratio = nan(n,1);
shrinkage_log = nan(n,1);
enc_N = nan(n,1);
failure = false(n,1);
wall_s = nan(n,1);
loss_total = nan(n,1);
loss_recon = nan(n,1);
loss_enclose = nan(n,1);
kappa_final = nan(n,1);

for k = 1:n
    noise{k} = char(rows(k).noise);
    status{k} = char(rows(k).status);
    error_message{k} = char(rows(k).error_message);
    gamma_vol(k) = double(rows(k).gamma_vol);
    gamma_enc(k) = double(rows(k).gamma_enc);
    rep(k) = double(rows(k).rep);
    train_seed(k) = double(rows(k).train_seed);
    TV(k) = double(rows(k).TV);
    volume_ratio(k) = double(rows(k).volume_ratio);
    shrinkage_log(k) = double(rows(k).shrinkage_log);
    enc_N(k) = double(rows(k).enc_N);
    failure(k) = logical(rows(k).failure);
    wall_s(k) = double(rows(k).wall_s);
    loss_total(k) = double(rows(k).loss_total);
    loss_recon(k) = double(rows(k).loss_recon);
    loss_enclose(k) = double(rows(k).loss_enclose);
    kappa_final(k) = double(rows(k).kappa_final);
end

T = table(noise, gamma_vol, gamma_enc, rep, train_seed, TV, ...
    volume_ratio, shrinkage_log, enc_N, failure, status, wall_s, ...
    loss_total, loss_recon, loss_enclose, kappa_final, error_message, ...
    'VariableNames', {'noise','gamma_vol','gamma_enc','rep','train_seed', ...
    'TV','volume_ratio','shrinkage_log','enc_N','failure','status','wall_s', ...
    'loss_total','loss_recon','loss_enclose','kappa_final','error_message'});
writetable(T, path);
end

function [TV, volumeRatio, shrinkageLog, encN] = ...
    evaluate_h5_metrics(Y, M_est, M_true, Up, my, K, nMC, tvSeed)
% Geometry metrics are computed in the common affine-projection basis.
MhatProj = Up' * M_est;
MtrueProj = Up' * M_true;
Vhat = simplex_volume_h5(MhatProj);
Vtrue = simplex_volume_h5(MtrueProj);
if ~(isfinite(Vhat) && isfinite(Vtrue) && Vhat > 0 && Vtrue > 0)
    TV = NaN; volumeRatio = NaN; shrinkageLog = NaN; encN = NaN;
    return;
end
volumeRatio = Vhat / Vtrue;
shrinkageLog = log(Vtrue / Vhat);
TV = tv_dist_simplex_h5(MtrueProj, MhatProj, nMC, tvSeed);

% Reconstruct the model's spherized working coordinates from the returned
% Up/my. This mirrors the preprocessing in deep_mvsa_invflow_H5.m.
[Ywork, MhatWork] = rebuild_working_coordinates_h5(Y, M_est, Up, my, K);
if rcond(MhatWork) < 1e-12
    encN = NaN;
else
    bary = MhatWork \ Ywork;
    encN = mean(any(bary < -1e-9, 1));
end
end

function [Ywork, Mwork] = rebuild_working_coordinates_h5(Y, M_est, Up, my, K)
N = size(Y, 2);
U = Up(:, 1:K-1);
Yc = Y - repmat(my, 1, N);
Cov = (Yc * Yc') / N;
Dvals = diag(U' * Cov * U);
Dvals = max(real(Dvals), 0);
C = diag(1 ./ sqrt(Dvals + 1e-10));
Yp = U * (U' * Yc) + repmat(my, 1, N);
Ywork = [C * U' * (Yp - repmat(my, 1, N)); ones(1, N)] / sqrt(K);
Mwork = [C * U' * (M_est - repmat(my, 1, K)); ones(1, K)] / sqrt(K);
end

function V = simplex_volume_h5(M)
K = size(M, 2);
J = M(:, 1:K-1) - M(:, K);
G = J' * J;
d = real(det(G));
if ~isfinite(d) || d <= 0
    V = NaN;
else
    V = sqrt(d) / factorial(K-1);
end
end

function [D_TV, vol_T, vol_E] = tv_dist_simplex_h5(M_T, M_E, M_MC, seed)
%TV_DIST_SIMPLEX_H5
% Fig.1-matched Monte-Carlo estimator of the TV distance between uniform
% distributions on two simplices.
%
% The estimator follows demo_deepmvsa_fig1_std_style_v17_ZhuiZgong_GYL_K3:
%   1) Uniformly sample from each simplex using Dirichlet(1,...,1).
%   2) Estimate the intersection volume from both sampling directions.
%   3) Average the two intersection-volume estimates.
%   4) Compute D_TV = 1 - Vol(intersection)/max(Vol_T,Vol_E).
%
% M_T and M_E must be expressed in the same evaluation coordinates.
% The first argument is the true simplex; the second is the estimated simplex.

p = size(M_T, 2);
K = p - 1;

% Simplex volumes, using the same Gram-determinant expression as Fig.1.
E_T = M_T(:, 2:p) - repmat(M_T(:, 1), 1, K);
E_E = M_E(:, 2:p) - repmat(M_E(:, 1), 1, K);

det_T = real(det(E_T' * E_T));
det_E = real(det(E_E' * E_E));

vol_T = sqrt(max(det_T, 0)) / factorial(K);
vol_E = sqrt(max(det_E, 0)) / factorial(K);

if ~(isfinite(vol_T) && isfinite(vol_E) && vol_T > 0 && vol_E > 0)
    D_TV = NaN;
    return;
end

% Keep H5's per-repetition Monte-Carlo seed control.
rng(seed, 'twister');

% Uniform samples from the true simplex:
% alpha ~ Dirichlet(1,...,1), generated by normalized Exp(1) variables.
G = -log(rand(p, M_MC));
alpha = G ./ repmat(sum(G, 1), p, 1);
r_T = mean(in_simplex_h5(M_T * alpha, M_E));

% Uniform samples from the estimated simplex (symmetric direction).
G = -log(rand(p, M_MC));
alpha = G ./ repmat(sum(G, 1), p, 1);
r_E = mean(in_simplex_h5(M_E * alpha, M_T));

% Symmetric Monte-Carlo estimate of the intersection volume.
vol_int = 0.5 * (r_T * vol_T + r_E * vol_E);

% Fig.1 D_TV definition.
D_TV = max(1 - vol_int / max(vol_T, vol_E), 0);
end


function inside = in_simplex_h5(X, M)
%IN_SIMPLEX_H5
% Fig.1-matched barycentric-coordinate membership test.
% For x = m_0 + E*c, x belongs to conv(M) iff:
%   c >= 0 and 1 - sum(c) >= 0.
% The backslash solve is least squares when E is overdetermined, allowing
% small deviations from the affine hull to be handled consistently.

tol = 1e-8;
m0 = M(:, 1);
E = M(:, 2:end) - repmat(m0, 1, size(M, 2) - 1);
C = E \ (X - repmat(m0, 1, size(X, 2)));
inside = all(C >= -tol, 1) & (1 - sum(C, 1) >= -tol);
end

function v = safe_struct_field(S, fieldName)
if isstruct(S) && isfield(S, fieldName) && isscalar(S.(fieldName))
    v = double(S.(fieldName));
else
    v = NaN;
end
end

function cells = aggregate_h5_cells(rows, cfg)
cells = struct('noise', {}, 'gamma_vol', {}, 'gamma_enc', {}, ...
    'n_runs', {}, 'n_valid_TV', {}, 'n_failed', {}, 'failure_rate', {}, ...
    'TV_mean', {}, 'TV_sd', {}, 'TV_ci95_halfwidth', {}, ...
    'volume_ratio_mean', {}, 'volume_ratio_sd', {}, 'volume_ratio_ci95_halfwidth', {}, ...
    'shrinkage_log_mean', {}, 'shrinkage_log_sd', {}, 'shrinkage_log_ci95_halfwidth', {}, ...
    'enc_N_mean', {}, 'enc_N_sd', {}, 'enc_N_ci95_halfwidth', {});
q = 0;
for iNoise = 1:numel(cfg.noise_names)
    noise = cfg.noise_names{iNoise};
    for iVol = 1:numel(cfg.gamma_vol)
        gv = cfg.gamma_vol(iVol);
        for iEnc = 1:numel(cfg.gamma_enc)
            ge = cfg.gamma_enc(iEnc);
            mask = strcmp({rows.noise}, noise) & ...
                abs([rows.gamma_vol] - gv) < 1e-12 & ...
                abs([rows.gamma_enc] - ge) < 1e-12;
            rr = rows(mask);
            q = q + 1;
            [mTV, sdTV, ciTV, nTV] = mean_sd_ci([rr.TV]);
            [mVR, sdVR, ciVR] = mean_sd_ci([rr.volume_ratio]);
            [mSL, sdSL, ciSL] = mean_sd_ci([rr.shrinkage_log]);
            [mEN, sdEN, ciEN] = mean_sd_ci([rr.enc_N]);
            fail = [rr.failure];
            cells(q).noise = noise;
            cells(q).gamma_vol = gv;
            cells(q).gamma_enc = ge;
            cells(q).n_runs = numel(rr);
            cells(q).n_valid_TV = nTV;
            cells(q).n_failed = sum(fail);
            cells(q).failure_rate = mean(double(fail));
            cells(q).TV_mean = mTV;
            cells(q).TV_sd = sdTV;
            cells(q).TV_ci95_halfwidth = ciTV;
            cells(q).volume_ratio_mean = mVR;
            cells(q).volume_ratio_sd = sdVR;
            cells(q).volume_ratio_ci95_halfwidth = ciVR;
            cells(q).shrinkage_log_mean = mSL;
            cells(q).shrinkage_log_sd = sdSL;
            cells(q).shrinkage_log_ci95_halfwidth = ciSL;
            cells(q).enc_N_mean = mEN;
            cells(q).enc_N_sd = sdEN;
            cells(q).enc_N_ci95_halfwidth = ciEN;
        end
    end
end
end

function [m, sd, ci, n] = mean_sd_ci(x)
x = x(isfinite(x));
n = numel(x);
if n == 0
    m = NaN; sd = NaN; ci = NaN;
elseif n == 1
    m = x(1); sd = NaN; ci = NaN;
else
    m = mean(x);
    sd = std(x, 0);
    ci = tcrit975_h5(n-1) * sd / sqrt(n);
end
end

function t = tcrit975_h5(df)
if exist('tinv', 'file') == 2
    t = tinv(0.975, df);
    return;
end
T = [12.706,4.303,3.182,2.776,2.571,2.447,2.365,2.306,2.262, ...
    2.228,2.201,2.179,2.160,2.145,2.131,2.120,2.110,2.101, ...
    2.093,2.086,2.080,2.074,2.069,2.064,2.060,2.056,2.052, ...
    2.048,2.045,2.042];
if df >= 1 && df <= numel(T)
    t = T(df);
else
    t = 1.96;
end
end

function S1 = check_tableS1_consistency(cells, rows, cfg)
% Published Table S1 reference means at K=5,N=1e4,SNR=30 dB.
S1.gamma_vol = cfg.default_gamma_vol * [1/4, 1/2, 1, 2, 4];
S1.gamma_enc = cfg.default_gamma_enc * [1/4, 1/2, 1, 2, 4];
S1.published_gamma_vol_TV = [0.44, 0.43, 0.43, 0.43, 0.43];
S1.published_gamma_enc_TV = [0.48, 0.46, 0.43, 0.42, 0.43];
S1.h5_gamma_vol_TV = nan(1, 5);
S1.h5_gamma_enc_TV = nan(1, 5);
for k = 1:5
    S1.h5_gamma_vol_TV(k) = mean_run_metric(rows, 'snr30', ...
        S1.gamma_vol(k), cfg.default_gamma_enc, 'TV');
    S1.h5_gamma_enc_TV(k) = mean_run_metric(rows, 'snr30', ...
        cfg.default_gamma_vol, S1.gamma_enc(k), 'TV');
end
S1.gamma_vol_abs_diff = abs(S1.h5_gamma_vol_TV - S1.published_gamma_vol_TV);
S1.gamma_enc_abs_diff = abs(S1.h5_gamma_enc_TV - S1.published_gamma_enc_TV);
S1.gamma_vol_range_ratio = safe_range_ratio(S1.h5_gamma_vol_TV);
S1.gamma_enc_range_ratio = safe_range_ratio(S1.h5_gamma_enc_TV);
S1.gamma_vol_flatness_pass = isfinite(S1.gamma_vol_range_ratio) && S1.gamma_vol_range_ratio < 1.2;
S1.gamma_enc_flatness_pass = isfinite(S1.gamma_enc_range_ratio) && S1.gamma_enc_range_ratio < 1.2;
S1.underweighted_enc_direction = S1.h5_gamma_enc_TV(1) > S1.h5_gamma_enc_TV(3);
S1.overweighted_enc_harmless = max(S1.h5_gamma_enc_TV(4:5)) <= ...
    1.2 * max(S1.h5_gamma_enc_TV(3), eps);
defaultTV = mean_run_metric(rows, 'snr30', cfg.default_gamma_vol, ...
    cfg.default_gamma_enc, 'TV');
S1.default_TV = defaultTV;
S1.default_below_MVSA_0p76 = isfinite(defaultTV) && defaultTV < 0.76;
S1.default_below_SoftML_0p98 = isfinite(defaultTV) && defaultTV < 0.98;
% PASS uses the published Table S1 insensitivity factor and baseline clauses.
% Directional observations and numerical differences are reported separately.
S1.PASS = S1.gamma_vol_flatness_pass && S1.gamma_enc_flatness_pass && ...
    S1.default_below_MVSA_0p76 && S1.default_below_SoftML_0p98;
S1.note = ['The H5 7x7 phase grid is supplemented with four SNR30 cells ', ...
    'so both Table S1 one-factor slices use the exact five published factor ', ...
    'levels. New paired seeds are used; this is not a bitwise reproduction.'];
end

function m = mean_run_metric(rows, noise, gv, ge, fieldName)
mask = strcmp({rows.noise}, noise) & ...
    abs([rows.gamma_vol] - gv) < 1e-12 & ...
    abs([rows.gamma_enc] - ge) < 1e-12;
if ~any(mask)
    m = NaN;
else
    x = [rows(mask).(fieldName)];
    x = x(isfinite(x));
    if isempty(x), m = NaN; else, m = mean(x); end
end
end

function r = safe_range_ratio(x)
x = x(isfinite(x));
if isempty(x) || min(x) <= 0
    r = NaN;
else
    r = max(x) / min(x);
end
end

function v = find_cell_value(cells, noise, gv, ge, fieldName)
idx = find(strcmp({cells.noise}, noise) & ...
    abs([cells.gamma_vol] - gv) < 1e-12 & ...
    abs([cells.gamma_enc] - ge) < 1e-12, 1, 'first');
if isempty(idx)
    v = NaN;
else
    v = cells(idx).(fieldName);
end
end

function write_s1_check_csv(S1, path)
T = table(S1.gamma_vol(:), S1.published_gamma_vol_TV(:), ...
    S1.h5_gamma_vol_TV(:), S1.gamma_vol_abs_diff(:), ...
    S1.gamma_enc(:), S1.published_gamma_enc_TV(:), ...
    S1.h5_gamma_enc_TV(:), S1.gamma_enc_abs_diff(:), ...
    'VariableNames', {'gamma_vol','TableS1_gamma_vol_TV','H5_gamma_vol_slice_TV', ...
    'gamma_vol_abs_diff','gamma_enc','TableS1_gamma_enc_TV', ...
    'H5_gamma_enc_slice_TV','gamma_enc_abs_diff'});
writetable(T, path);
end

function fit = fit_shrinkage_shape(cells, rows, cfg)
% Fit log(shrinkage_log) = 0.5*(log(gamma_vol)-log(gamma_enc)) + b.
% Only positive log-shrinkage values are admissible for the log fit.
fit = struct('status', 'not_fitted', 'b', NaN, 'c5', NaN, 'R2', NaN, ...
    'n_fit_cells', 0, 'c5_ci95', [NaN NaN], 'slope_fixed', 0.5);
clean = strcmp({cells.noise}, 'clean');
cc = cells(clean);
valid = isfinite([cc.shrinkage_log_mean]) & [cc.shrinkage_log_mean] > 0;
cc = cc(valid);
if numel(cc) < 3
    fit.note = 'Fewer than three positive shrinkage cells; no log-shape fit.';
    return;
end
X = 0.5 * (log([cc.gamma_vol]) - log([cc.gamma_enc]));
y = log([cc.shrinkage_log_mean]);
b = mean(y - X);
yhat = X + b;
ssRes = sum((y-yhat).^2);
ssTot = sum((y-mean(y)).^2);
if ssTot > 0, R2 = 1 - ssRes/ssTot; else, R2 = NaN; end
c5 = 2 * exp(-2*b);
fit.status = 'fitted';
fit.b = b;
fit.c5 = c5;
fit.R2 = R2;
fit.n_fit_cells = numel(cc);
fit.note = ['Shape-reference fit only; it is not a proof of the theoretical ', ...
    'constant or a test that the bound holds in every cell.'];
fit.c5_ci95 = bootstrap_c5(rows, cc, cfg);
end

function ci = bootstrap_c5(rows, fitCells, cfg)
rng(cfg.seed_bootstrap, 'twister');
bootC5 = nan(cfg.n_bootstrap, 1);
for b = 1:cfg.n_bootstrap
    xs = [];
    ys = [];
    validBoot = true;
    for q = 1:numel(fitCells)
        gv = fitCells(q).gamma_vol;
        ge = fitCells(q).gamma_enc;
        mask = strcmp({rows.noise}, 'clean') & ...
            abs([rows.gamma_vol]-gv) < 1e-12 & ...
            abs([rows.gamma_enc]-ge) < 1e-12 & ...
            isfinite([rows.shrinkage_log]);
        vals = [rows(mask).shrinkage_log];
        vals = vals(isfinite(vals));
        if numel(vals) < 2
            validBoot = false;
            break;
        end
        pick = randi(numel(vals), 1, numel(vals));
        m = mean(vals(pick));
        if ~(isfinite(m) && m > 0)
            validBoot = false;
            break;
        end
        xs(end+1) = 0.5 * (log(gv) - log(ge)); %#ok<AGROW>
        ys(end+1) = log(m); %#ok<AGROW>
    end
    if validBoot && numel(xs) >= 3
        bb = mean(ys - xs);
        bootC5(b) = 2 * exp(-2*bb);
    end
end
bootC5 = sort(bootC5(isfinite(bootC5) & bootC5 > 0));
if numel(bootC5) < max(50, 0.2*cfg.n_bootstrap)
    ci = [NaN NaN];
else
    ci = [bootC5(max(1, ceil(0.025*numel(bootC5)))), ...
          bootC5(min(numel(bootC5), ceil(0.975*numel(bootC5))))];
end
end

function direction = direction_diagnostics(cells, cfg)
% Report empirical direction fractions for both the volume ratio and the
% theory-defined log-shrinkage. These are descriptive, not pass/fail gates.
direction = struct();
for n = 1:numel(cfg.noise_names)
    noise = cfg.noise_names{n};
    VR = nan(numel(cfg.gamma_enc), numel(cfg.gamma_vol));
    SL = VR;
    for i = 1:numel(cfg.gamma_enc)
        for j = 1:numel(cfg.gamma_vol)
            VR(i,j) = find_cell_value(cells, noise, cfg.gamma_vol(j), ...
                cfg.gamma_enc(i), 'volume_ratio_mean');
            SL(i,j) = find_cell_value(cells, noise, cfg.gamma_vol(j), ...
                cfg.gamma_enc(i), 'shrinkage_log_mean');
        end
    end
    % For volume_ratio: expected down with gamma_vol, up with gamma_enc.
    % For log-shrinkage: expected up with gamma_vol, down with gamma_enc.
    direction.(noise).volume_ratio_decreasing_gamma_vol = ...
        rowwise_direction_fraction(VR, 'decreasing');
    direction.(noise).volume_ratio_increasing_gamma_enc = ...
        colwise_direction_fraction(VR, 'increasing');
    direction.(noise).shrinkage_increasing_gamma_vol = ...
        rowwise_direction_fraction(SL, 'increasing');
    direction.(noise).shrinkage_decreasing_gamma_enc = ...
        colwise_direction_fraction(SL, 'decreasing');
end
end

function f = rowwise_direction_fraction(A, direction)
f = nan(size(A,1),1);
for i = 1:size(A,1)
    x = A(i,:); x = x(isfinite(x));
    if numel(x) < 2, f(i)=NaN; continue; end
    d = diff(x);
    if strcmp(direction,'increasing'), f(i)=mean(d >= -1e-12);
    else, f(i)=mean(d <= 1e-12); end
end
end

function f = colwise_direction_fraction(A, direction)
f = nan(size(A,2),1);
for j = 1:size(A,2)
    x = A(:,j); x = x(isfinite(x));
    if numel(x) < 2, f(j)=NaN; continue; end
    d = diff(x);
    if strcmp(direction,'increasing'), f(j)=mean(d >= -1e-12);
    else, f(j)=mean(d <= 1e-12); end
end
end

function verdict = make_h5_verdict(rows, cells, S1, fit, direction, cfg)
verdict = struct();
verdict.expected_runs = expected_run_count(cfg);
verdict.actual_runs = numel(rows);
verdict.run_count_complete = numel(rows) == verdict.expected_runs;
verdict.failure_count = sum([rows.failure]);
verdict.failure_rate = mean(double([rows.failure]));
verdict.tableS1_consistency_pass = S1.PASS;
verdict.shrinkage_fit_available = strcmp(fit.status, 'fitted');
verdict.shrinkage_c5 = fit.c5;
verdict.shrinkage_fit_R2 = fit.R2;
verdict.direction_diagnostics = direction;
if verdict.run_count_complete && verdict.failure_count == 0 && S1.PASS && ...
        verdict.shrinkage_fit_available
    verdict.pipeline_status = 'COMPLETE; scientific interpretation still required';
elseif verdict.run_count_complete
    verdict.pipeline_status = 'COMPLETE WITH SCIENTIFIC/DIAGNOSTIC FLAGS';
else
    verdict.pipeline_status = 'INCOMPLETE';
end
verdict.note = ['A completed pipeline is not equivalent to H5 scientific acceptance. ', ...
    'The phase boundary and fitted shape must be judged from the measured maps.'];
end

function plot_h5_heatmaps(cells, fit, cfg, outDir, metricName, baseName, colorLabel)
fig = figure('Color','w','Position',[100 100 1180 500], 'Visible','off');
ax2 = [];
allValues = [cells.(metricName)];
allValues = allValues(isfinite(allValues));
if isempty(allValues), close(fig); return; end
clim = [min(allValues), max(allValues)];
if abs(clim(2)-clim(1)) < eps
    clim = clim + [-1 1] * max(abs(clim(1))*1e-6, 1e-9);
end
for n = 1:numel(cfg.noise_names)
    noise = cfg.noise_names{n};
    ax = subplot(1,2,n,'Parent',fig);
    if n == 2, ax2 = ax; end
    Z = nan(numel(cfg.gamma_enc), numel(cfg.gamma_vol));
    for i = 1:numel(cfg.gamma_enc)
        for j = 1:numel(cfg.gamma_vol)
            Z(i,j) = find_cell_value(cells, noise, cfg.gamma_vol(j), ...
                cfg.gamma_enc(i), metricName);
        end
    end
    imagesc(ax, log10(cfg.gamma_vol), log10(cfg.gamma_enc), Z);
    set(ax,'YDir','normal','CLim',clim,'FontName','Times New Roman','FontSize',10);
    colormap(ax, parula(256));
    hold(ax,'on');
    set(ax,'XTick',log10(cfg.gamma_vol), ...
        'XTickLabel',arrayfun(@(x)sprintf('%g',x),cfg.gamma_vol,'UniformOutput',false));
    set(ax,'YTick',log10(cfg.gamma_enc), ...
        'YTickLabel',arrayfun(@(x)sprintf('%g',x),cfg.gamma_enc,'UniformOutput',false));
    xlabel(ax,'\gamma_{vol}');
    ylabel(ax,'\gamma_{enc}');
    title(ax, sprintf('%s | %s', colorLabel, noise), 'Interpreter','tex');

    % Theoretical shape-reference curve s* = 1, when a positive c5 fit exists.
    % The curve is shown on TV and theory-defined log-shrinkage maps, not on
    % the raw volume-ratio map (the fitted s variable is log(VT/Vhat)).
    showFitCurve = strcmp(metricName,'TV_mean') || strcmp(metricName,'shrinkage_log_mean');
    if showFitCurve && strcmp(fit.status,'fitted') && isfinite(fit.c5) && fit.c5 > 0
        gvLine = logspace(log10(min(cfg.gamma_vol)), log10(max(cfg.gamma_vol)), 250);
        geLine = 2 * gvLine / fit.c5;
        keep = geLine >= min(cfg.gamma_enc) & geLine <= max(cfg.gamma_enc);
        if any(keep)
            plot(ax, log10(gvLine(keep)), log10(geLine(keep)), ...
                'w--','LineWidth',1.8,'DisplayName','fitted s^*=1');
        end
    end
    % C' cap and default operating point.
    xC = log10(cfg.C_prime);
    yLim = log10([min(cfg.gamma_enc), max(cfg.gamma_enc)]);
    plot(ax,[xC xC],yLim,'w:','LineWidth',1.6,'DisplayName','C''');
    plot(ax,log10(cfg.default_gamma_vol),log10(cfg.default_gamma_enc), ...
        'wo','MarkerSize',10,'LineWidth',1.8,'MarkerFaceColor','none', ...
        'DisplayName','default');

    % Numeric annotations for each cell.
    for i = 1:numel(cfg.gamma_enc)
        for j = 1:numel(cfg.gamma_vol)
            if isfinite(Z(i,j))
                txt = sprintf('%.3g',Z(i,j));
                text(ax,log10(cfg.gamma_vol(j)),log10(cfg.gamma_enc(i)),txt, ...
                    'HorizontalAlignment','center','VerticalAlignment','middle', ...
                    'FontSize',8,'Color','k','FontWeight','bold');
            end
        end
    end
    grid(ax,'on'); box(ax,'on');
    if n == 2
        legend(ax,'Location','northwest','FontSize',8);
    end
end
if ~isempty(ax2)
    cb = colorbar(ax2);
    cb.Label.String = colorLabel;
end
annotation(fig,'textbox',[0.08 0.94 0.84 0.045], ...
    'String',sprintf('H5 parameter phase map: %s', colorLabel), ...
    'EdgeColor','none','HorizontalAlignment','center', ...
    'FontWeight','bold','FontSize',12,'Interpreter','tex');
print(fig, fullfile(outDir,[baseName '.png']), '-dpng','-r300');
try
    print(fig, fullfile(outDir,[baseName '.svg']), '-dsvg');
catch ME
    warning('Could not export SVG for %s: %s', baseName, ME.message);
end
close(fig);
end

function logmsg(fid, fmt, varargin)
msg = sprintf(fmt, varargin{:});
fprintf('%s\n', msg);
fprintf(fid, '%s\n', msg);
end

function s = pass_text(tf)
if tf, s='PASS'; else, s='NOT PASS'; end
end
