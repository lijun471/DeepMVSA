function [M_est, Sest, Up, my, theta, e1_history, e3_full_loss] = deep_mvsa_invflow_H5(Y, p, varargin)
% H5 model: H5-specific fork of the supplied deep_mvsa_invflow_E3.m.
% Added: E2-consistent Monte Carlo TV monitor and exact full-data objective.
% The full objective is evaluated after the final Adam update in chunks.
% The third output Up is the affine-projection basis; E2 uses Up'*M_est
% and Up'*M_true for Table-2-consistent TV and vertex-error metrics.
%% DeepMVSA-InvFlow H5 (mini-batch): Invertible Coupled Q + Nonlinear Attention
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% A_eff = A_base + c * G .* (A_base.^2)
%
% ------------------------- MINI-BATCH TRAINING -------------------------
% Each gradient step draws BATCH_SIZE samples uniformly at random (with
% replacement). Per-sample SUM penalties (nonnegativity, sum-to-one,
% enclosure) are rescaled by N/B so that the stochastic losses and
% gradients are UNBIASED estimates of the original full-batch quantities
% -- all LAMBDA_* hyperparameters keep their original meaning and tuned
% values transfer directly. The reconstruction loss is a per-sample MEAN
% and needs no rescaling.
%
%   - Per-step cost:      O(B * (p^2 + p*h))  instead of O(N * p^2)
%   - Parameter memory:   O(p^2 + p*h), independent of N  (unchanged)
%   - Set BATCH_SIZE >= N to recover the original full-batch behavior
%     exactly (no random sampling, scaling factor N/B = 1).
%
% q_m is a fixed 1xp target vector precomputed in ONE pass over the data
% before training; it does not enter the per-iteration cost.
%
% Optional data-enclosure penalty sum(min(Q*Y,0).^2) (LAMBDA_ENCLOSE).
% Default 0 -> identical to the original version (used for Cuprite).
% For synthetic data with i.i.d. abundances, set LAMBDA_ENCLOSE = 10 to
% anchor Q to the data convex hull and prevent the simplex from
% collapsing inward under the volume term.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term, default off
addParameter(pStruct, 'BATCH_SIZE', 4096, @isnumeric);    % <<< NEW: mini-batch size (>=N => full batch)
addParameter(pStruct, 'SEED', [], @isnumeric);            % optional training RNG seed
% E1 monitoring: loss decomposition is always recorded when interval > 0.
% Supply E1_MTRUE (original L-by-p endmembers) to also compute TV and volume ratio.
addParameter(pStruct, 'E1_MONITOR_INTERVAL', 25, @isnumeric);
addParameter(pStruct, 'E1_MTRUE', [], @isnumeric);
addParameter(pStruct, 'E1_TV_MC', 2000, @isnumeric);
addParameter(pStruct, 'E1_TV_SEED', 12345, @isnumeric);
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'HIDDEN', 32, @(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(pStruct, 'KAPPA0', 0.05, @(x)isnumeric(x)&&isscalar(x)&&isfinite(x));
addParameter(pStruct, 'FREEZE_Q_WARMUP', true, @(x)islogical(x)||isnumeric(x));
addParameter(pStruct, 'COORD_MODE', 'auto', @ischar);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'E3_SKIP_ABUNDANCE_OUTPUT', true, @(x)islogical(x)||isnumeric(x));
parse(pStruct, varargin{:});

if ~isempty(pStruct.Results.SEED)
    rng(pStruct.Results.SEED, 'twister');
end

[L, N] = size(Y);
B = min(pStruct.Results.BATCH_SIZE, N);
full_batch = (B >= N);

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------------------- E1 reference simplex (optional) ---------------------
E1_MTRUE = pStruct.Results.E1_MTRUE;
if ~isempty(E1_MTRUE)
    if size(E1_MTRUE,1) ~= L || size(E1_MTRUE,2) ~= p
        error('E1_MTRUE must be an L-by-p matrix in the original spectral space.');
    end
    if strcmp(pStruct.Results.spherize, 'yes')
        E1_MTRUE_work = C * Up(:,1:p-1)' * (E1_MTRUE - repmat(my,1,p));
        E1_MTRUE_work(p,:) = 1;
        E1_MTRUE_work = E1_MTRUE_work / sqrt(p);
    else
        E1_MTRUE_work = Up' * E1_MTRUE;
    end
    E1_MTRUE_proj = Up' * E1_MTRUE;
    E1_true_volume = simplex_volume_e1(E1_MTRUE_proj);
    if ~(isfinite(E1_true_volume) && E1_true_volume > 0)
        error('E1_MTRUE produces a degenerate simplex in the model working space.');
    end
else
    E1_MTRUE_work = [];
    E1_MTRUE_proj = [];
    E1_true_volume = NaN;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    if exist('VCA','file')==2
        M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
    else
        M0 = e3_vca_fallback(Y_work,p);
    end
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');   % one pass, O(N*p^2), fixed target thereafter

%% --------------------- Spatial coordinates ---------------------
if strcmpi(pStruct.Results.COORD_MODE,'index')
    coords = linspace(-1,1,N); coords = coords(:)';
elseif strcmpi(pStruct.Results.COORD_MODE,'auto')
    H = round(sqrt(N)); W = round(N/H);
    if H*W == N
    [gx, gy] = meshgrid(linspace(-1,1,W), linspace(-1,1,H));
    coords = [gx(:)'; gy(:)'];
    else
        coords = linspace(-1,1,N); coords = coords(:)';
    end
else
    error('COORD_MODE must be ''auto'' or ''index''.');
end
coord_dim = size(coords,1);

%% --------------------- E1 history buffers ---------------------
e1_interval = round(pStruct.Results.E1_MONITOR_INTERVAL);
if e1_interval < 0
    error('E1_MONITOR_INTERVAL must be zero (disabled) or a positive integer.');
end
e1_history = struct();
e1_history.iteration = zeros(0,1);
e1_history.warm_up = false(0,1);
e1_history.total = zeros(0,1);
e1_history.recon = zeros(0,1);
e1_history.vol = zeros(0,1);
e1_history.nonneg = zeros(0,1);
e1_history.sumone = zeros(0,1);
e1_history.eq = zeros(0,1);
e1_history.enclose = zeros(0,1);
e1_history.tv = zeros(0,1);
e1_history.volume_ratio = zeros(0,1);
e1_history.estimated_volume = zeros(0,1);
e1_history.true_volume = E1_true_volume;
e1_history.reference_available = ~isempty(E1_MTRUE_work);
e1_history.monitor_interval = e1_interval;
e1_history.tv_mc = round(pStruct.Results.E1_TV_MC);
e1_history.tv_seed = pStruct.Results.E1_TV_SEED;
if e1_history.tv_mc < 1
    error('E1_TV_MC must be a positive integer.');
end
% A private stream ensures that TV sampling does not alter the training RNG.
tv_stream = RandStream('mt19937ar', 'Seed', pStruct.Results.E1_TV_SEED);

%% --------------------- A-Net parameters ---------------------
hidden = round(pStruct.Results.HIDDEN);
theta.W1 = 0.01*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
theta.W2 = 0.01*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
theta.W3 = 0.01*randn(p, hidden);         theta.b3 = zeros(p,1);
theta.Wg1 = 0.01*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.01*randn(p, hidden);         theta.bg2 = zeros(p,1);
theta.c = pStruct.Results.KAPPA0;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);       % strict lower triangular
theta.R = zeros(p,p);       % strict upper triangular
theta.r_log = zeros(p,1);   % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

if pStruct.Results.verbose
    fprintf('Mini-batch training: N=%d, batch=%d, steps/epoch=%.1f\n', N, B, N/B);
end

%% --------------------- Warm-up (linear, Q fixed at Q0) ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch);              % <<< mini-batch
    [loss, grad, loss_parts] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, true, N);
    % H5 protocol: during warm-up Q must remain exactly at Q0. The supplied
    % E3 file's comment says this, but its original loop still updates the
    % Q-flow parameters through reconstruction/equality/enclosure gradients.
    % Zeroing these gradients before Adam keeps L, R and r_log unchanged.
    if logical(pStruct.Results.FREEZE_Q_WARMUP)
        grad.L(:) = 0;
        grad.R(:) = 0;
        grad.r_log(:) = 0;
    end
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;

    if e1_interval > 0 && (mod(iter,e1_interval)==0 || iter==pStruct.Results.MM_ITERS)
        e1_history = append_e1_checkpoint(e1_history, iter, true, loss_parts, ...
            theta, Q0, E1_MTRUE_proj, E1_true_volume, tv_stream, e1_history.tv_mc, ...
            Up, D, my, lambda_reg, strcmp(pStruct.Results.spherize,'yes'));
    end

    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f\n', k, pStruct.Results.WARM_UP, loss);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
for k = 1:n_joint
    [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch);              % <<< mini-batch
    [loss, grad, loss_parts] = compute_gradients_invflow(theta, Yb, cb, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, false, N);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr);
    iter = iter + 1;

    if e1_interval > 0 && (mod(iter,e1_interval)==0 || iter==pStruct.Results.MM_ITERS)
        e1_history = append_e1_checkpoint(e1_history, iter, false, loss_parts, ...
            theta, Q0, E1_MTRUE_proj, E1_true_volume, tv_stream, e1_history.tv_mc, ...
            Up, D, my, lambda_reg, strcmp(pStruct.Results.spherize,'yes'));
    end

    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end

%% --------------------- Recover endmembers ---------------------
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);

% E3 does not need a full p-by-N abundance output; save peak memory.
if pStruct.Results.E3_SKIP_ABUNDANCE_OUTPUT
    Sest = [];
else
    CHUNK = min(N, 50000);
    Sest = zeros(p, N);
    for i1 = 1:CHUNK:N
        i2 = min(i1+CHUNK-1, N);
        Sest(:, i1:i2) = abundance_net_forward_nl(coords(:, i1:i2), theta, false);
    end
end

% Exact (non-stochastic) deployed objective at the post-update final point.
% Crucial: all runs at fixed N share this full-data evaluation definition.
e3_full_loss = eval_e3_full_objective(theta, Y_work, coords, Q0, qm, pStruct.Results);

e1_history.total_iterations = iter;
e1_history.warmup_iterations = pStruct.Results.WARM_UP;
e1_history.training_space = 'DeepMVSA spherized/projected working space';
e1_history.loss_note = ['Loss components are recorded from the mini-batch objective ' ...
    'evaluated immediately before the corresponding Adam update; geometry metrics ' ...
    'are evaluated immediately after that update.'];

if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1)*diag(sqrt(diag(D+lambda_reg*eye(p-1))))*M_sub + repmat(my,1,p);
else
    M_est = Up*M_sub;
end
end

%% ===================== Sub-functions =====================
function [Yb, cb] = next_batch(Y_work, coords, N, B, full_batch)
%NEXT_BATCH  Uniform random mini-batch (with replacement); full batch if B >= N.
if full_batch
    Yb = Y_work; cb = coords;
else
    idx = randi(N, 1, B);
    Yb = Y_work(:, idx); cb = coords(:, idx);
end
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

c = warm_up*0 + (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function grad = abundance_net_backward_nl(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    grad.c = dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);
end

function [loss, grad, loss_parts] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, warm_up, N_total)
% Y is a BATCH of Nb columns drawn from the full data set of N_total
% samples. Per-sample SUM penalties are scaled by s = N_total/Nb so that
% all stochastic losses/gradients are unbiased estimates of the original
% full-batch versions (s = 1 recovers them exactly).
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

[A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up);

Nb = size(Y, 2);
s = N_total / Nb;              % unbiased scaling for per-sample SUM penalties

Y_hat = M * A_eff;
diff = Y_hat - Y;
loss_recon = mean(sum(diff.^2,1));         % per-sample MEAN: no rescaling

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

penalty = min(A_eff,0);
loss_nonneg = s * sum(penalty.^2, 'all');                 % <<< scaled

sum_A = sum(A_eff,1);
loss_sumone = s * sum((sum_A-1).^2, 'all');               % <<< scaled

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');   % data-free (q_m precomputed)

% --- optional data-enclosure penalty QY >= 0 ---
QY = Q*Y;
pen_enclose = min(QY, 0);
loss_enclose = s * sum(pen_enclose.^2, 'all');            % <<< scaled

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + lambda_enclose*loss_enclose;

% Unweighted component values are retained for E1 objective decomposition.
loss_parts = struct();
loss_parts.total = loss;
loss_parts.recon = loss_recon;
loss_parts.vol = loss_vol;
loss_parts.nonneg = loss_nonneg;
loss_parts.sumone = loss_sumone;
loss_parts.eq = loss_eq;
loss_parts.enclose = loss_enclose;

dY_hat = 2*diff/Nb;                        % gradient of the batch MEAN
dM = dY_hat * A_eff';
grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * s * pen_enclose * Y';                % <<< scaled
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Backprop to abundance network
dA_eff = M' * dY_hat + s * (2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1));               % <<< scaled
grad_net = abundance_net_backward_nl(dA_eff, cache, theta);
grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
grad.c = grad_net.c;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*(grad.(f).^2);
    m_hat = m.(f) / (1 - beta1^iter);
    v_hat = v.(f) / (1 - beta2^iter);
    theta.(f) = theta.(f) - lr * m_hat ./ (sqrt(v_hat) + eps);
end
end


%% ===================== E1 trajectory helpers =====================
function hist = append_e1_checkpoint(hist, iter, is_warmup, loss_parts, ...
    theta, Q0, M_true_proj, V_true, tv_stream, n_mc, ...
    Up, D, my, lambda_reg, is_spherized)
% Record six objective components and, when the true simplex is supplied,
% TV distance and estimated/true simplex-volume ratio.
hist.iteration(end+1,1) = iter;
hist.warm_up(end+1,1) = logical(is_warmup);
hist.total(end+1,1) = double(loss_parts.total);
hist.recon(end+1,1) = double(loss_parts.recon);
hist.vol(end+1,1) = double(loss_parts.vol);
hist.nonneg(end+1,1) = double(loss_parts.nonneg);
hist.sumone(end+1,1) = double(loss_parts.sumone);
hist.eq(end+1,1) = double(loss_parts.eq);
hist.enclose(end+1,1) = double(loss_parts.enclose);

L_mat = eye(size(Q0,1)) + tril(theta.L,-1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R,1);
Q_now = L_mat * Q0 * R_mat;
M_now = inv(Q_now);
if is_spherized
    p = size(M_now,2);
    M_s = M_now(1:p-1,:) * sqrt(p);
    M_orig = Up(:,1:p-1) * diag(sqrt(diag(D + lambda_reg*eye(p-1)))) ...
        * M_s + repmat(my,1,p);
    M_now_proj = Up' * M_orig;
else
    M_now_proj = M_now;
end
V_now = simplex_volume_e1(M_now_proj);
hist.estimated_volume(end+1,1) = V_now;

if isempty(M_true_proj)
    hist.tv(end+1,1) = NaN;
    hist.volume_ratio(end+1,1) = NaN;
else
    hist.tv(end+1,1) = tv_uniform_e1(M_now_proj, M_true_proj, n_mc, tv_stream);
    hist.volume_ratio(end+1,1) = V_now / V_true;
end
end

function V = simplex_volume_e1(M)
% (p-1)-dimensional Euclidean volume of the simplex with column vertices.
p = size(M,2);
J = M(:,1:p-1) - M(:,p);
G = J' * J;
d = real(det(G));
V = sqrt(max(d,0)) / factorial(p-1);
end

function tv = tv_uniform_e1(M1, M2, n_mc, stream)
% E2 / Table-2 DTV definition:
%   1 - Vol(intersection(S1,S2)) / max(Vol(S1),Vol(S2))
% Monte Carlo estimate of intersection volume, averaging both directions.
% Geometry is evaluated in the common Up' * M affine-projection basis.
p = size(M1,2);
V1 = simplex_volume_e1(M1);
V2 = simplex_volume_e1(M2);
if ~(isfinite(V1)&&isfinite(V2)&&V1>0&&V2>0)
    tv=NaN; return;
end
G=-log(max(rand(stream,p,n_mc),realmin));
A1=G./sum(G,1);
G=-log(max(rand(stream,p,n_mc),realmin));
A2=G./sum(G,1);
r1=mean(e3_inside_simplex(M1*A1,M2));
r2=mean(e3_inside_simplex(M2*A2,M1));
Vintersection=0.5*(r1*V1+r2*V2);
tv=max(0,min(1,1-Vintersection/max(V1,V2)));
end

function inside=e3_inside_simplex(X,M)
% Same barycentric test/tolerance as supplied E2 driver.
tol=1e-8; p=size(M,2);
m0=M(:,1); E=M(:,2:end)-repmat(m0,1,p-1);
C=E\(X-repmat(m0,1,size(X,2)));
inside=all(C>=-tol,1) & ((1-sum(C,1))>=-tol);
end

function parts=eval_e3_full_objective(theta,Y,coords,Q0,qm,params)
% Exact full-dataset objective, evaluated in chunks to cap memory.
p=size(Y,1); N=size(Y,2);
L=eye(p)+tril(theta.L,-1);
R=diag(exp(theta.r_log))+triu(theta.R,1);
Q=L*Q0*R; M=Q\eye(p);
recon_sum=0; nonneg_sum=0; sumone_sum=0; enclose_sum=0;
CHUNK=20000;
for j=1:CHUNK:N
    jj=j:min(N,j+CHUNK-1);
    A=abundance_net_forward_nl(coords(:,jj),theta,false);
    diff=M*A-Y(:,jj);
    recon_sum=recon_sum+sum(diff(:).^2);
    neg=min(A,0); nonneg_sum=nonneg_sum+sum(neg(:).^2);
    sa=sum(A,1)-1; sumone_sum=sumone_sum+sum(sa.^2);
    qy=min(Q*Y(:,jj),0); enclose_sum=enclose_sum+sum(qy(:).^2);
end
parts=struct();
parts.recon=recon_sum/N;
parts.vol=-sum(theta.r_log);
parts.nonneg=nonneg_sum;
parts.sumone=sumone_sum;
parts.eq=sum((sum(Q,1)-qm).^2);
parts.enclose=enclose_sum;
parts.total=parts.recon + params.LAMBDA_VOL*parts.vol ...
    + params.LAMBDA_NONNEG*parts.nonneg ...
    + params.LAMBDA_SUMONE*parts.sumone ...
    + params.LAMBDA_EQ*parts.eq ...
    + params.LAMBDA_ENCLOSE*parts.enclose;
end

function M0 = e3_vca_fallback(Y,p)
% Fallback VCA-style extreme-point initialization; called only if VCA absent.
% Uses affine/homogeneous p-space and selects p independent data columns.
N=size(Y,2); U=zeros(p,0); selected=zeros(1,p);
for i=1:p
    w=randn(p,1);
    f=w-U*(U'*w);
    if norm(f)<1e-12
        for j=1:p
            e=zeros(p,1); e(j)=1;
            f=e-U*(U'*e);
            if norm(f)>1e-12, break; end
        end
    end
    f=f/max(norm(f),eps);
    [~,idx]=max(abs(f'*Y));
    if any(idx==selected(1:i-1))
        [~,ord]=sort(abs(f'*Y),'descend');
        j=find(~ismember(ord,selected(1:i-1)),1,'first');
        idx=ord(j);
    end
    selected(i)=idx;
    v=Y(:,idx)-U*(U'*Y(:,idx));
    if norm(v)>1e-12
        U=[U,v/norm(v)]; %#ok<AGROW>
    end
end
M0=Y(:,selected);
if rcond(M0)<1e-10
    error('Fallback VCA selected a nearly singular initial simplex.');
end
end
