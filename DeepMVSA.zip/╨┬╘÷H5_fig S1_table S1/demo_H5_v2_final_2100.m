%% DeepMVSA H5-v2: complete 2100-run experiment (single-launch script)
% This script runs the complete experiment in one launch:
%   180 Table-S1 reference-slice runs (9 settings x 20 reps, SNR30)
%   1920 phase-map runs (8 x 6 settings x 2 noise arms x 20 reps)
% Total: 2100 runs.
%
% IMPORTANT:
%   - No G0 gate or G0 pass/fail judgment is performed.
%   - Table-S1 values are saved as descriptive numerical comparisons only.
%   - The 180 reference-slice runs are retained as a separate phase. Their
%     parameter settings overlap nine SNR30 cells in the 1920-run grid.
%   - All run checkpoints are stored in ONE temporary MAT file, not one MAT
%     file per run. The checkpoint is deleted only after a complete final
%     result MAT has been saved and verified.
%   - Final deliverables: 2 MAT + 4 CSV + 2 TXT files.
%   - If interrupted, rerun this same script. Successful runs are skipped;
%     failed/pending runs are retried.
%
% Required files on the MATLAB path/current folder:
%   USGS_1995_Library.mat (variable datalib; 224 x spectra+metadata)
%   spectMixGen.m
%   deep_mvsa_invflow_H5.m
%
% MATLAB R2016b or newer is required for local functions in scripts.

clear;
clc;
close all;

%% ------------------------- USER SETTINGS -----------------------------
K = 5;
N = 1e4;
NREP = 20;
USGS_MAT = 'USGS_1995_Library.mat';
OUTDIR = 'outputs_h5v2_final_2100';

% Geometry evaluation
M_MC = 2e4;
ENC_N_SAMPLES = 2000;

% Training protocol (kept consistent with the supplied H5-v2 demo)
ITERS_S1 = 1500;
ITERS_GRID = 1500;
WARM_UP = 600;
LR = 1e-3;
BATCH_SIZE = 4096;
LAMBDA_NONNEG = 5;
LAMBDA_EQ = 80;
LAMBDA_SUMONE = 2;
KAPPA0 = 0.05;
HIDDEN = 32;
MODEL_VERBOSE = 0;

% Registered random seeds (unchanged)
DATA_SEED0 = 203000;
TRAIN_SEED0 = 503000;
TV_SEED0 = 12345;

%% ------------------------- CONFIG STRUCT ------------------------------
C = struct();
C.K = K;
C.N = N;
C.NREP = NREP;
C.USGS_MAT = USGS_MAT;
C.OUTDIR = OUTDIR;
C.M_MC = M_MC;
C.ENC_N_SAMPLES = ENC_N_SAMPLES;
C.ITERS_S1 = ITERS_S1;
C.ITERS_GRID = ITERS_GRID;
C.WARM_UP = WARM_UP;
C.LR = LR;
C.BATCH_SIZE = BATCH_SIZE;
C.LAMBDA_NONNEG = LAMBDA_NONNEG;
C.LAMBDA_EQ = LAMBDA_EQ;
C.LAMBDA_SUMONE = LAMBDA_SUMONE;
C.KAPPA0 = KAPPA0;
C.HIDDEN = HIDDEN;
C.MODEL_VERBOSE = MODEL_VERBOSE;
C.DATA_SEED0 = DATA_SEED0;
C.TRAIN_SEED0 = TRAIN_SEED0;
C.TV_SEED0 = TV_SEED0;
C.PROTOCOL_ID = 'H5v2_USGS_SPECTMIXGEN_H5MODEL_FINAL2100_20261124_R1';

validate_inputs(C);
[S1,GRID] = h5_design();
paths = check_dependencies(C);
C.MODEL_PATH = paths.model;
C.SPECTMIXGEN_PATH = paths.mixgen;
C.USGS_PATH = paths.usgs;

% Resolve the actual script path for the protocol signature.
this_full = mfilename('fullpath');
if isempty(this_full)
    paths.demo = which('demo_H5_v2_final_2100');
else
    paths.demo = [this_full '.m'];
end
if isempty(paths.demo) || exist(paths.demo,'file') ~= 2
    error('Cannot resolve the running script path for protocol verification.');
end
paths.demo_bytes = file_bytes(paths.demo);
C.RUN_SIGNATURE = make_run_signature(C,paths,GRID);

plan = build_run_plan(C,S1,GRID);
if height(plan) ~= 2100
    error('Internal run-plan error: expected exactly 2100 runs, got %d.',height(plan));
end

if ~exist(C.OUTDIR,'dir')
    mkdir(C.OUTDIR);
end
checkpoint_file = fullfile(C.OUTDIR,'h5v2_checkpoint.mat');
config_file = fullfile(C.OUTDIR,'h5v2_config.mat');
results_file = fullfile(C.OUTDIR,'h5v2_results.mat');

% Do not overwrite a completed result set accidentally.
if exist(results_file,'file') == 2 && exist(checkpoint_file,'file') ~= 2
    error(['A completed h5v2_results.mat already exists in %s. ' ...
        'To run a fresh experiment, change OUTDIR at the top of this script.'],C.OUTDIR);
end

% Create or verify the single consolidated checkpoint.
initialize_checkpoint(checkpoint_file,C,S1,GRID,paths,plan);

% Save the compact configuration MAT (one file for the whole experiment).
config_tmp = fullfile(C.OUTDIR,'h5v2_config_tmp.mat');
save(config_tmp,'C','S1','GRID','paths','plan','-v7');
[ok,msg] = movefile(config_tmp,config_file,'f');
if ~ok
    error('Could not finalize h5v2_config.mat: %s',msg);
end
write_protocol_manifest(C,S1,GRID,paths,plan);

fprintf('\n============================================================\n');
fprintf('DeepMVSA H5-v2 complete experiment\n');
fprintf('Runs planned : %d (180 S1-slice + 1920 phase-map)\n',height(plan));
fprintf('K / p / L    : %d / %d / 224\n',C.K,C.K+1);
fprintf('N / repeats  : %d / %d\n',C.N,C.NREP);
fprintf('Model        : %s\n',paths.model);
fprintf('USGS library : %s\n',paths.usgs);
fprintf('Output       : %s\n',C.OUTDIR);
fprintf('G0 judgment  : DISABLED (no gate; no G0 pass/fail)\n');
fprintf('Checkpoint   : one consolidated MAT file\n');
fprintf('============================================================\n\n');

%% ------------------------- RUN ALL 2100 -------------------------------
datalib = load_usgs(paths.usgs);
run_all_2100(plan,C,checkpoint_file,datalib);

%% ------------------------- COLLATE / SAVE -----------------------------
[results,T,CS,missing,S1comparison,diagnostics] = ...
    build_final_results(checkpoint_file,C,S1,GRID,paths,plan);

writetable(T,fullfile(C.OUTDIR,'h5v2_run_summary.csv'));
writetable(CS,fullfile(C.OUTDIR,'h5v2_cell_summary.csv'));
writetable(missing,fullfile(C.OUTDIR,'h5v2_missing_runs.csv'));
writetable(S1comparison,fullfile(C.OUTDIR,'h5v2_tableS1_comparison.csv'));
write_run_report(results,diagnostics,C.OUTDIR);

% Atomic final MAT write. Keep the checkpoint until this file is verified.
results_tmp = fullfile(C.OUTDIR,'h5v2_results_tmp.mat');
save(results_tmp,'results','-v7.3');
move_ok = movefile(results_tmp,results_file,'f');
if ~move_ok
    error('Could not finalize h5v2_results.mat. Checkpoint was retained.');
end

w = whos('-file',results_file);
if ~any(strcmp({w.name},'results'))
    error('Final MAT verification failed: variable results is missing. Checkpoint retained.');
end

n_done = sum(T.completed);
n_failed = sum(T.attempted & ~T.completed);
n_pending = sum(~T.attempted);
if n_done == height(plan) && n_failed == 0 && n_pending == 0
    % Only now is it safe to remove the temporary checkpoint.
    delete(checkpoint_file);
    fprintf('\nAll 2100 runs completed successfully. Temporary checkpoint removed.\n');
else
    fprintf(2,['\nExperiment is not fully complete: successful=%d, failed=%d, pending=%d.\n' ...
        'The consolidated checkpoint is retained. Rerun this same script to retry unfinished runs.\n'], ...
        n_done,n_failed,n_pending);
end

fprintf('\nFinal files are in: %s\n',C.OUTDIR);
fprintf('MAT: h5v2_config.mat, h5v2_results.mat\n');
fprintf('CSV: h5v2_run_summary.csv, h5v2_cell_summary.csv, h5v2_missing_runs.csv, h5v2_tableS1_comparison.csv\n');
fprintf('TXT: h5v2_run_report.txt, h5v2_protocol_manifest.txt\n');

%% =====================================================================
%                           LOCAL FUNCTIONS
% =====================================================================
function [S1,GRID] = h5_design()
S1.GV_LEVELS = [0.0025 0.005 0.01 0.02 0.04];
S1.GV_TV = [0.44 0.43 0.43 0.43 0.43];
S1.GV_SD = [0.13 0.13 0.13 0.13 0.13];
S1.GE_LEVELS = [2.5 5 10 20 40];
S1.GE_TV = [0.48 0.46 0.43 0.42 0.43];
S1.GE_SD = [0.14 0.14 0.13 0.11 0.11];
S1.DEFAULT = struct('gamma_vol',0.01,'gamma_enc',10);
S1.NREP = 20;
GRID.GAMMA_VOL = [0.0025 0.005 0.01 0.02 0.04 0.08 0.16 0.32];
GRID.GAMMA_ENC = [1.25 2.5 5 10 20 40];
GRID.ARMS = {'clean','snr30'};
end

function validate_inputs(C)
if C.K ~= 5 || C.N ~= 1e4 || C.NREP ~= 20
    error('This registered H5-v2 protocol requires K=5, N=10000, NREP=20.');
end
if C.M_MC < 100 || C.M_MC ~= round(C.M_MC)
    error('M_MC must be an integer >= 100.');
end
if C.ENC_N_SAMPLES < 1 || C.ENC_N_SAMPLES ~= round(C.ENC_N_SAMPLES)
    error('ENC_N_SAMPLES must be a positive integer.');
end
if C.ITERS_S1 <= C.WARM_UP || C.ITERS_GRID <= C.WARM_UP
    error('Both iteration counts must exceed WARM_UP.');
end
if C.BATCH_SIZE < 1 || C.BATCH_SIZE ~= round(C.BATCH_SIZE)
    error('BATCH_SIZE must be a positive integer.');
end
if C.LR <= 0 || C.KAPPA0 < 0 || C.HIDDEN < 1
    error('Invalid LR, KAPPA0, or HIDDEN setting.');
end
end

function paths = check_dependencies(C)
if exist(C.USGS_MAT,'file') ~= 2
    error('Cannot find USGS_MAT: %s',C.USGS_MAT);
end
if exist('spectMixGen','file') ~= 2
    error('Cannot find spectMixGen.m on the MATLAB path.');
end
if exist('deep_mvsa_invflow_H5','file') ~= 2
    error('Cannot find deep_mvsa_invflow_H5.m on the MATLAB path.');
end
paths.usgs = which(C.USGS_MAT);
if isempty(paths.usgs), paths.usgs = C.USGS_MAT; end
paths.mixgen = which('spectMixGen');
paths.model = which('deep_mvsa_invflow_H5');
S = load(paths.usgs,'datalib');
if ~isfield(S,'datalib') || ~isnumeric(S.datalib) || ndims(S.datalib) ~= 2
    error('USGS MAT must contain a numeric 2-D variable named datalib.');
end
D = S.datalib;
if size(D,1) ~= 224
    error('Expected 224 USGS bands; datalib has %d rows.',size(D,1));
end
if size(D,2) < 4 + C.K + 1
    error('USGS library has too few spectral columns.');
end
bad = ~isfinite(D(:,5:end));
if any(bad(:))
    error('USGS spectral columns 5:end contain NaN or Inf.');
end
paths.usgs_bytes = file_bytes(paths.usgs);
paths.mixgen_bytes = file_bytes(paths.mixgen);
paths.model_bytes = file_bytes(paths.model);
end

function n = file_bytes(path)
d = dir(path);
if isempty(d), n = NaN; else, n = d(1).bytes; end
end

function s = file_stamp(path)
d = dir(path);
if isempty(d)
    s = [path '|MISSING'];
else
    s = sprintf('%s|%d|%.15g',path,d(1).bytes,d(1).datenum);
end
end

function sig = make_run_signature(C,paths,GRID)
% The script checksum is computed from the exact running script path.
txt = fileread(paths.demo);
w = mod((1:numel(txt))',997)+1;
driver_sum = sum(double(txt(:)).*w);
driver_sig = sprintf('%d|%.0f',numel(txt),driver_sum);
sig = sprintf(['%s|K=%g|N=%g|REP=%g|MMC=%g|ENCN=%g|S1IT=%g|GRIDIT=%g|' ...
    'WARM=%g|LR=%.16g|BATCH=%g|NONNEG=%g|EQ=%g|SUMONE=%g|KAPPA=%.16g|' ...
    'HIDDEN=%g|DSEED=%g|TSEED=%g|TVSEED=%g|GV=%s|GE=%s|ARMS=%s|' ...
    'DRIVER=%s|MODEL=%s|MIX=%s|USGS=%s'], ...
    C.PROTOCOL_ID,C.K,C.N,C.NREP,C.M_MC,C.ENC_N_SAMPLES,C.ITERS_S1, ...
    C.ITERS_GRID,C.WARM_UP,C.LR,C.BATCH_SIZE,C.LAMBDA_NONNEG, ...
    C.LAMBDA_EQ,C.LAMBDA_SUMONE,C.KAPPA0,C.HIDDEN,C.DATA_SEED0, ...
    C.TRAIN_SEED0,C.TV_SEED0,mat2str(GRID.GAMMA_VOL,12), ...
    mat2str(GRID.GAMMA_ENC,12),strjoin(GRID.ARMS,','),driver_sig, ...
    file_stamp(paths.model),file_stamp(paths.mixgen),file_stamp(paths.usgs));
end

function cells = s1_slice_cells(S1)
cells = struct('gamma_vol',{},'gamma_enc',{},'tag',{});
cells(end+1) = make_cell(S1.DEFAULT.gamma_vol,S1.DEFAULT.gamma_enc,'s1_default');
for i = 1:numel(S1.GV_LEVELS)
    gv = S1.GV_LEVELS(i);
    if abs(gv-S1.DEFAULT.gamma_vol) < 1e-12, continue; end
    cells(end+1) = make_cell(gv,S1.DEFAULT.gamma_enc,sprintf('s1_gv%g',gv)); %#ok<AGROW>
end
for i = 1:numel(S1.GE_LEVELS)
    ge = S1.GE_LEVELS(i);
    if abs(ge-S1.DEFAULT.gamma_enc) < 1e-12, continue; end
    cells(end+1) = make_cell(S1.DEFAULT.gamma_vol,ge,sprintf('s1_ge%g',ge)); %#ok<AGROW>
end
end

function cells = grid_cells(GRID)
cells = struct('gamma_vol',{},'gamma_enc',{},'tag',{});
for gv = GRID.GAMMA_VOL
    for ge = GRID.GAMMA_ENC
        cells(end+1) = make_cell(gv,ge,sprintf('grid_gv%g_ge%g',gv,ge)); %#ok<AGROW>
    end
end
end

function s = make_cell(gv,ge,tag)
s = struct('gamma_vol',gv,'gamma_enc',ge,'tag',tag);
end

function plan = build_run_plan(C,S1,GRID)
rows = cell(0,1);
s1cells = s1_slice_cells(S1);
gcells = grid_cells(GRID);
for rep = 1:C.NREP
    for ci = 1:numel(s1cells)
        rows{end+1,1} = plan_row('s1slice',s1cells(ci),'snr30',rep,C.ITERS_S1,C); %#ok<AGROW>
    end
end
for rep = 1:C.NREP
    for ci = 1:numel(gcells)
        for ai = 1:numel(GRID.ARMS)
            rows{end+1,1} = plan_row('grid',gcells(ci),GRID.ARMS{ai},rep,C.ITERS_GRID,C); %#ok<AGROW>
        end
    end
end
plan = records_to_table(rows);
end

function q = plan_row(phase,cellDef,arm,rep,iters,C)
q = struct();
q.tag = sprintf('%s_%s_rep%02d',cellDef.tag,arm,rep);
q.phase = phase;
q.cell_tag = cellDef.tag;
q.arm = arm;
q.gamma_vol = cellDef.gamma_vol;
q.gamma_enc = cellDef.gamma_enc;
q.rep = rep;
q.iters = iters;
q.data_seed = C.DATA_SEED0 + rep;
q.train_seed = C.TRAIN_SEED0 + rep;
q.tv_seed = C.TV_SEED0 + rep;
end

function d = extract_driver_signature(sig)
tok = regexp(sig,'\|DRIVER=([0-9]+)\|([0-9]+)\|MODEL=','tokens','once');
if isempty(tok)
    d = '';
else
    d = [tok{1} '|' tok{2}];
end
end

function s = strip_driver_signature(sig)
s = regexprep(sig,'\|DRIVER=[0-9]+\|[0-9]+\|MODEL=', ...
    '|DRIVER=<same>|MODEL=');
end

function initialize_checkpoint(file,C,S1,GRID,paths,plan)
if exist(file,'file') == 2
    H = load(file,'run_signature','n_runs','plan');
    if ~isfield(H,'run_signature')
        error('Existing checkpoint has no run_signature. No files were overwritten.');
    end
    if ~strcmp(H.run_signature,C.RUN_SIGNATURE)
        % Permit exactly the immediately preceding H5-v2 driver checkpoint
        % when the only source change is this MATFILE noncontiguous-index fix.
        old_driver = extract_driver_signature(H.run_signature);
        legacy_driver_ok = any(strcmp(old_driver, ...
            {'35918|1435475141','36873|1446691014'})); % LF / CRLF
        same_protocol = strcmp(strip_driver_signature(H.run_signature), ...
            strip_driver_signature(C.RUN_SIGNATURE));
        driver_text = fileread(paths.demo);
        fix_present = ~isempty(strfind(driver_text,'done_all = mf.run_done;')) && ...
            ~isempty(strfind(driver_text,'done_now = done_all(rep_idx,1);')) && ...
            ~isempty(strfind(driver_text,'bad_idx = rep_idx(~done_all(rep_idx,1));'));
        if ~(legacy_driver_ok && same_protocol && fix_present)
            error(['Existing checkpoint does not match the current H5-v2 protocol. ' ...
                'No files were overwritten. Use a new OUTDIR or restore the matching code/dependencies.']);
        end
        fprintf(['Compatible checkpoint detected: accepting the MATFILE indexing-only ' ...
            'driver correction; all experiment settings and dependencies match.\n']);
    end
    if H.n_runs ~= height(plan) || ~isequaln(H.plan,plan)
        error('Existing checkpoint run plan differs from the current 2100-run plan.');
    end
    fprintf('Found one compatible checkpoint. Completed runs will be skipped; unfinished runs will be retried.\n');
    return;
end
if exist(fullfile(C.OUTDIR,'h5v2_results.mat'),'file') == 2
    error('Final results already exist but checkpoint is absent. Use a new OUTDIR for a fresh experiment.');
end
n = height(plan);
L = 224;
p = C.K+1;
run_metrics = nan(n,17);
run_status = repmat(' ',n,16);
run_failure = repmat(' ',n,512);
run_done = false(n,1);
run_attempted = false(n,1);
run_M_est = nan(L,p,n);
run_Up = nan(L,p,n);
M_true_by_rep = nan(L,p,C.NREP);
run_signature = C.RUN_SIGNATURE;
n_runs = n;
tmp = [file '.tmp.mat'];
save(tmp,'C','S1','GRID','paths','plan','run_signature','n_runs', ...
    'run_metrics','run_status','run_failure','run_done','run_attempted', ...
    'run_M_est','run_Up','M_true_by_rep','-v7.3');
[ok,msg] = movefile(tmp,file,'f');
if ~ok, error('Cannot create consolidated checkpoint: %s',msg); end
end

function run_all_2100(plan,C,checkpoint_file,datalib)
mf = matfile(checkpoint_file,'Writable',true);
phases = {'s1slice','grid'};
new_success = 0;
skipped = 0;
failed_attempts = 0;
fprintf('\nStarting all %d runs. No G0 gate or pass/fail judgment will be performed.\n',height(plan));

for rep = 1:C.NREP
    rep_idx = find(plan.rep == rep);
    % MATFILE supports regular-stride subscripting only. Read the small
    % completion vector once, then apply the noncontiguous rep_idx in RAM.
    done_all = mf.run_done;
    done_now = done_all(rep_idx,1);
    if all(done_now)
        skipped = skipped + numel(rep_idx);
        fprintf('Rep %02d/%02d: all %d planned runs already complete; skipped.\n',rep,C.NREP,numel(rep_idx));
        continue;
    end

    dseed = C.DATA_SEED0 + rep;
    fprintf('\nGenerating paired USGS data for rep %02d/%02d (seed=%d).\n',rep,C.NREP,dseed);
    try
        [Ypair,M_true] = gen_pair(datalib,C.K+1,C.N,dseed);
    catch ME
        bad_idx = rep_idx(~done_all(rep_idx,1));
        for z = 1:numel(bad_idx)
            rec = empty_run_record();
            rec.status = 'failed';
            rec.failure = ['DATA_GENERATION: ' ME.message];
            write_checkpoint_record(mf,bad_idx(z),rec);
            failed_attempts = failed_attempts + 1;
        end
        fprintf(2,'Data generation failed for rep %d: %s\n',rep,ME.message);
        continue;
    end

    old_true = mf.M_true_by_rep(:,:,rep);
    if all(isfinite(old_true(:)))
        if norm(old_true-M_true,'fro') > 1e-10*max(1,norm(M_true,'fro'))
            error('Regenerated M_true differs from the saved rep %d data. Check USGS data/protocol.',rep);
        end
    else
        mf.M_true_by_rep(:,:,rep) = M_true;
    end

    for ph = 1:numel(phases)
        phase = phases{ph};
        phase_idx = find(plan.rep == rep & strcmp(plan.phase,phase));
        for z = 1:numel(phase_idx)
            idx = phase_idx(z);
            if mf.run_done(idx,1)
                skipped = skipped + 1;
                continue;
            end
            arm = plan.arm{idx};
            Y = Ypair.(arm);
            cellDef = make_cell(plan.gamma_vol(idx),plan.gamma_enc(idx),plan.cell_tag{idx});
            fprintf('[%4d/%4d] %-7s %-46s gv=%-8g ge=%-8g rep=%02d\n', ...
                idx,height(plan),phase,plan.tag{idx},cellDef.gamma_vol,cellDef.gamma_enc,rep);
            rec = run_one(Y,M_true,C.K+1,cellDef,rep,plan.iters(idx),C);
            write_checkpoint_record(mf,idx,rec);
            if strcmp(rec.status,'ok')
                new_success = new_success + 1;
                fprintf('    status=ok | TV=%.6f | VolumeRatio=%.6f | enc_N=%.6f | %.1f s\n', ...
                    rec.TV,rec.volume_ratio,rec.enc_N,rec.runtime_s);
            else
                failed_attempts = failed_attempts + 1;
                fprintf(2,'    status=failed | %s\n',rec.failure);
            end
        end
    end
end
fprintf('\nRun loop finished. Newly successful=%d; skipped successful=%d; failed attempts=%d.\n', ...
    new_success,skipped,failed_attempts);
end

function write_checkpoint_record(mf,idx,rec)
% Store scalar metrics and matrices in one consolidated MAT file.
metrics = [rec.TV,rec.vol_T,rec.vol_E,rec.volume_ratio,rec.log_s, ...
    rec.shrinkage_log,rec.r_T,rec.r_E,rec.enc_N,rec.runtime_s, ...
    rec.loss_total,rec.loss_recon,rec.loss_vol,rec.loss_nonneg, ...
    rec.loss_sumone,rec.loss_eq,rec.loss_enclose];
mf.run_attempted(idx,1) = true;
mf.run_status(idx,:) = fixed_char(rec.status,16);
mf.run_failure(idx,:) = fixed_char(rec.failure,512);
mf.run_metrics(idx,:) = metrics;
if strcmp(rec.status,'ok')
    mf.run_M_est(:,:,idx) = rec.M_est;
    mf.run_Up(:,:,idx) = rec.Up;
else
    mf.run_M_est(:,:,idx) = nan(224,6);
    mf.run_Up(:,:,idx) = nan(224,6);
end
% Write completion flag last: an interrupted write will be retried.
mf.run_done(idx,1) = strcmp(rec.status,'ok');
end

function s = fixed_char(value,n)
s = repmat(' ',1,n);
if isempty(value), return; end
value = char(value);
value = value(:)';
value = strrep(value,sprintf('\n'),' ');
value = strrep(value,sprintf('\r'),' ');
value = strrep(value,char(9),' ');
value = strtrim(value);
if numel(value) > n, value = value(1:n); end
s(1:numel(value)) = value;
end

function rec = run_one(Y,M_true,p,cellDef,rep,iters,C)
rec = empty_run_record();
t0 = tic;
try
    tseed = C.TRAIN_SEED0 + rep;
    vseed = C.TV_SEED0 + rep;
    [M_est,~,Up,~,~,~,full_loss] = deep_mvsa_invflow_H5(Y,p, ...
        'spherize','yes', ...
        'verbose',C.MODEL_VERBOSE, ...
        'MM_ITERS',iters, ...
        'WARM_UP',C.WARM_UP, ...
        'LR',C.LR, ...
        'LAMBDA_VOL',cellDef.gamma_vol, ...
        'LAMBDA_ENCLOSE',cellDef.gamma_enc, ...
        'LAMBDA_NONNEG',C.LAMBDA_NONNEG, ...
        'LAMBDA_EQ',C.LAMBDA_EQ, ...
        'LAMBDA_SUMONE',C.LAMBDA_SUMONE, ...
        'BATCH_SIZE',C.BATCH_SIZE, ...
        'SEED',tseed, ...
        'KAPPA0',C.KAPPA0, ...
        'HIDDEN',C.HIDDEN, ...
        'FREEZE_Q_WARMUP',true, ...
        'E1_MONITOR_INTERVAL',0, ...
        'E3_SKIP_ABUNDANCE_OUTPUT',true);

    if ~isequal(size(M_est),size(M_true))
        error('M_est size %s does not match M_true size %s.',mat2str(size(M_est)),mat2str(size(M_true)));
    end
    if size(Up,1) ~= size(M_true,1) || size(Up,2) ~= p
        error('Up has unexpected size %s.',mat2str(size(Up)));
    end
    if any(~isfinite(M_est(:))) || any(~isfinite(Up(:)))
        error('The model returned NaN/Inf in M_est or Up.');
    end
    if norm(Up'*Up-eye(p),'fro') > 1e-5
        error('Returned Up basis is not numerically orthonormal.');
    end
    required_loss = {'total','recon','vol','nonneg','sumone','eq','enclose'};
    if ~isstruct(full_loss)
        error('The model did not return a full-loss structure.');
    end
    for k = 1:numel(required_loss)
        f = required_loss{k};
        if ~isfield(full_loss,f) || ~isscalar(full_loss.(f)) || ~isfinite(full_loss.(f))
            error('The model full-loss field %s is missing or invalid.',f);
        end
    end

    M_true_w = Up' * M_true;
    M_est_w = Up' * M_est;
    [DTV,vol_T,vol_E,r_T,r_E] = tv_canonical(M_true_w,M_est_w,C.M_MC,vseed);
    if ~(isfinite(DTV) && isfinite(vol_T) && isfinite(vol_E) && vol_T > 0 && vol_E > 0)
        error('Canonical TV evaluation returned invalid/degenerate geometry.');
    end
    idx = unique(round(linspace(1,size(Y,2),min(C.ENC_N_SAMPLES,size(Y,2)))));
    Y_w = Up' * Y(:,idx);
    enc_N = 1 - mean(in_simplex(Y_w,M_est_w));
    if ~isfinite(enc_N) || ~isfinite(r_T) || ~isfinite(r_E)
        error('Enclosure/Monte Carlo diagnostics returned NaN or Inf.');
    end

    rec.status = 'ok';
    rec.failure = '';
    rec.TV = DTV;
    rec.vol_T = vol_T;
    rec.vol_E = vol_E;
    rec.volume_ratio = vol_E/vol_T;
    rec.log_s = log(rec.volume_ratio);
    rec.shrinkage_log = -rec.log_s;
    rec.r_T = r_T;
    rec.r_E = r_E;
    rec.enc_N = enc_N;
    rec.M_est = M_est;
    rec.Up = Up;
    rec.loss_total = full_loss.total;
    rec.loss_recon = full_loss.recon;
    rec.loss_vol = full_loss.vol;
    rec.loss_nonneg = full_loss.nonneg;
    rec.loss_sumone = full_loss.sumone;
    rec.loss_eq = full_loss.eq;
    rec.loss_enclose = full_loss.enclose;
catch ME
    rec.status = 'failed';
    rec.failure = sprintf('%s: %s',ME.identifier,ME.message);
end
rec.runtime_s = toc(t0);
end

function rec = empty_run_record()
rec = struct('status','failed','failure','','TV',NaN,'vol_T',NaN,'vol_E',NaN, ...
    'volume_ratio',NaN,'log_s',NaN,'shrinkage_log',NaN,'r_T',NaN,'r_E',NaN, ...
    'enc_N',NaN,'runtime_s',NaN,'M_est',[],'Up',[],'loss_total',NaN, ...
    'loss_recon',NaN,'loss_vol',NaN,'loss_nonneg',NaN,'loss_sumone',NaN, ...
    'loss_eq',NaN,'loss_enclose',NaN);
end

function datalib = load_usgs(usgs_mat)
S = load(usgs_mat,'datalib');
if ~isfield(S,'datalib')
    error('USGS MAT must contain variable datalib.');
end
datalib = double(S.datalib);
if size(datalib,1) ~= 224 || size(datalib,2) < 5
    error('Expected a 224-band USGS library with four metadata columns.');
end
bad = ~isfinite(datalib(:,5:end));
if any(bad(:))
    error('USGS spectral columns contain NaN/Inf.');
end
end

function [Ypair,M_true] = gen_pair(datalib,p,N,dseed)
rng(dseed,'twister');
n_mat = size(datalib,2);
if n_mat-4 < p
    error('USGS library has too few spectra for p=%d.',p);
end
sel_all = 4 + randperm(n_mat-4);
sel = sel_all(1:p);
M_true = datalib(:,sel);
[Y30,x] = spectMixGen(M_true,N, ...
    'Source_pdf','Diri_id', ...
    'pdf_pars',1, ...
    'max_purity',0.8*ones(1,p), ...
    'no_outliers',0, ...
    'violation_extremes',[1 1.2], ...
    'snr',30, ...
    'noise_shape','uniform');
if ~isequal(size(Y30),[size(M_true,1),N])
    error('spectMixGen returned an unexpected SNR30 data size %s.',mat2str(size(Y30)));
end
if ~isequal(size(x),[p,N])
    error('spectMixGen returned an unexpected abundance size %s.',mat2str(size(x)));
end
if any(~isfinite(Y30(:))) || any(~isfinite(x(:)))
    error('spectMixGen returned NaN/Inf.');
end
Ypair.snr30 = Y30;
Ypair.clean = M_true*x;
end

function [D_TV,vol_T,vol_E,r_T,r_E] = tv_canonical(M_T,M_E,M_MC,seed)
rng(seed,'twister');
if size(M_T,1) ~= size(M_E,1) || size(M_T,2) ~= size(M_E,2)
    error('Projected endpoint matrices must have identical dimensions.');
end
p = size(M_T,2);
K = p-1;
E_T = M_T(:,2:p)-repmat(M_T(:,1),1,K);
E_E = M_E(:,2:p)-repmat(M_E(:,1),1,K);
vol_T = sqrt(max(real(det(E_T'*E_T)),0))/factorial(K);
vol_E = sqrt(max(real(det(E_E'*E_E)),0))/factorial(K);
if ~(isfinite(vol_T) && isfinite(vol_E) && vol_T>0 && vol_E>0)
    D_TV=NaN; r_T=NaN; r_E=NaN; return;
end
G = -log(max(rand(p,M_MC),realmin));
a = G./repmat(sum(G,1),p,1);
r_T = mean(in_simplex(M_T*a,M_E));
G = -log(max(rand(p,M_MC),realmin));
a = G./repmat(sum(G,1),p,1);
r_E = mean(in_simplex(M_E*a,M_T));
vol_int = 0.5*(r_T*vol_T+r_E*vol_E);
D_TV = max(0,min(1,1-vol_int/max(vol_T,vol_E)));
end

function inside = in_simplex(X,M)
p = size(M,2);
E = M(:,2:p)-repmat(M(:,1),1,p-1);
c = E\(X-repmat(M(:,1),1,size(X,2)));
inside = (min(c,[],1)>=-1e-8) & (sum(c,1)<=1+1e-8);
inside = reshape(inside,1,[]);
end

function [results,T,CS,missing,S1comparison,diagnostics] = ...
    build_final_results(checkpoint_file,C,S1,GRID,paths,plan)
D = load(checkpoint_file,'run_metrics','run_status','run_failure', ...
    'run_done','run_attempted','run_M_est','run_Up','M_true_by_rep');
T = plan;
T.attempted = D.run_attempted;
T.completed = D.run_done;
status = strtrim(cellstr(D.run_status));
for i=1:numel(status)
    if isempty(status{i})
        if D.run_attempted(i), status{i}='failed'; else, status{i}='pending'; end
    end
end
T.status = status;
T.ok = D.run_done;
failure = strtrim(cellstr(D.run_failure));
T.failure = failure;
metric_names = {'TV','vol_T','vol_E','volume_ratio','log_s','shrinkage_log', ...
    'r_T','r_E','enc_N','runtime_s','loss_total','loss_recon','loss_vol', ...
    'loss_nonneg','loss_sumone','loss_eq','loss_enclose'};
for j=1:numel(metric_names)
    T.(metric_names{j}) = D.run_metrics(:,j);
end

% Explicit issue table: failed attempts and not-yet-attempted runs.
missing = T(~T.ok,:);
issue = cell(height(missing),1);
for i=1:height(missing)
    if missing.attempted(i), issue{i}='failed'; else, issue{i}='pending'; end
end
missing.issue_type = issue;

CS = summarize_cells(T,C.NREP);
S1comparison = make_s1_comparison(T,S1);
diagnostics = make_diagnostics(CS,GRID);

results = struct();
results.protocol_id = C.PROTOCOL_ID;
results.run_signature = C.RUN_SIGNATURE;
results.generated_at = datestr(now,31);
results.config = C;
results.S1_reference = S1;
results.GRID = GRID;
results.paths = paths;
results.run_plan_and_results = T;
results.cell_summary = CS;
results.tableS1_comparison = S1comparison;
results.diagnostics = diagnostics;
results.M_true_by_rep = D.M_true_by_rep;
results.M_est_all = D.run_M_est;
results.Up_all = D.run_Up;
results.metric_names = metric_names;
results.n_expected = height(plan);
results.n_attempted = sum(T.attempted);
results.n_successful = sum(T.completed);
results.n_failed = sum(T.attempted & ~T.completed);
results.n_pending = sum(~T.attempted);
results.complete = all(T.completed);
results.note = ['No G0 gate or G0 pass/fail judgment was performed. ' ...
    'Table-S1 values are retained only as descriptive numerical references. ' ...
    'The 180 S1-slice settings overlap nine SNR30 grid cells and use the same ' ...
    'rep-specific data/training/TV seed rules; do not pool these duplicate ' ...
    'phase records as independent extra replications.'];
end

function T = records_to_table(rows)
% Convert a cell array of scalar records without relying on struct2table's
% treatment of variable-length character vectors.
if isempty(rows)
    T = table();
    return;
end
fn = fieldnames(rows{1});
vars = cell(1,numel(fn));
for j = 1:numel(fn)
    vals = cell(numel(rows),1);
    for i = 1:numel(rows)
        vals{i} = rows{i}.(fn{j});
    end
    v0 = vals{1};
    if ischar(v0) || isstring(v0)
        vars{j} = cell(numel(rows),1);
        for i = 1:numel(rows)
            vars{j}{i} = char(vals{i});
        end
    elseif (isnumeric(v0) || islogical(v0)) && isscalar(v0)
        vars{j} = cell2mat(vals);
    else
        vars{j} = vals;
    end
end
T = table(vars{:},'VariableNames',fn(:)');
end

function CS = summarize_cells(T,NREP)
keys = cell(height(T),1);
for i=1:height(T)
    keys{i} = [T.phase{i} '|' T.cell_tag{i} '|' T.arm{i}];
end
[u,ia] = unique(keys,'stable'); %#ok<ASGLU>
rows = cell(numel(ia),1);
for k=1:numel(ia)
    i=ia(k);
    mask = strcmp(T.phase,T.phase{i}) & strcmp(T.cell_tag,T.cell_tag{i}) & strcmp(T.arm,T.arm{i});
    A = T(mask,:);
    G = A(A.ok,:);
    q = struct();
    q.phase=T.phase{i}; q.cell_tag=T.cell_tag{i}; q.arm=T.arm{i};
    q.gamma_vol=T.gamma_vol(i); q.gamma_enc=T.gamma_enc(i);
    q.n_expected=NREP; q.n_attempted=sum(A.attempted); q.n_success=height(G);
    q.n_failed=sum(A.attempted & ~A.completed); q.n_pending=sum(~A.attempted);
    metric_list={'TV','volume_ratio','log_s','shrinkage_log','enc_N','runtime_s', ...
        'loss_total','loss_recon','loss_vol','loss_nonneg','loss_sumone','loss_eq','loss_enclose'};
    for m=1:numel(metric_list)
        nm=metric_list{m}; x=G.(nm); x=x(isfinite(x));
        q.([nm '_mean'])=safe_mean(x);
        q.([nm '_sd'])=safe_std(x);
        q.([nm '_ci95_halfwidth'])=ci95_halfwidth(x,NREP);
    end
    q.r_T_mean=safe_mean(G.r_T); q.r_E_mean=safe_mean(G.r_E);
    rows{k}=q;
end
CS=records_to_table(rows);
end

function m=safe_mean(x)
x=x(isfinite(x)); if isempty(x),m=NaN;else,m=mean(x);end
end
function s=safe_std(x)
x=x(isfinite(x)); if numel(x)<2,s=NaN;else,s=std(x,0);end
end
function h=ci95_halfwidth(x,nExpected)
x=x(isfinite(x));
if numel(x)==nExpected && nExpected==20
    tcrit=2.093024054408263;
    h=tcrit*std(x,0)/sqrt(nExpected);
else
    h=NaN;
end
end

function S1T=make_s1_comparison(T,S1)
points=struct('name',{},'gamma_vol',{},'gamma_enc',{},'ref_mean',{},'ref_sd',{});
points(end+1)=struct('name','default','gamma_vol',S1.DEFAULT.gamma_vol, ...
    'gamma_enc',S1.DEFAULT.gamma_enc,'ref_mean',0.43,'ref_sd',0.13);
for i=1:numel(S1.GV_LEVELS)
    gv=S1.GV_LEVELS(i);
    if abs(gv-S1.DEFAULT.gamma_vol)<1e-12,continue;end
    points(end+1)=struct('name',sprintf('gamma_vol=%g',gv),'gamma_vol',gv, ...
        'gamma_enc',S1.DEFAULT.gamma_enc,'ref_mean',S1.GV_TV(i),'ref_sd',S1.GV_SD(i)); %#ok<AGROW>
end
for i=1:numel(S1.GE_LEVELS)
    ge=S1.GE_LEVELS(i);
    if abs(ge-S1.DEFAULT.gamma_enc)<1e-12,continue;end
    points(end+1)=struct('name',sprintf('gamma_enc=%g',ge),'gamma_vol',S1.DEFAULT.gamma_vol, ...
        'gamma_enc',ge,'ref_mean',S1.GE_TV(i),'ref_sd',S1.GE_SD(i)); %#ok<AGROW>
end
rows=cell(0,1);
phases={'s1slice','grid'};
for ph=1:numel(phases)
    for i=1:numel(points)
        phase=phases{ph};
        mask=strcmp(T.phase,phase) & strcmp(T.arm,'snr30') & ...
            abs(T.gamma_vol-points(i).gamma_vol)<1e-12 & ...
            abs(T.gamma_enc-points(i).gamma_enc)<1e-12;
        A=T(mask,:); G=A(A.ok,:);
        q=struct(); q.phase=phase; q.point=points(i).name;
        q.gamma_vol=points(i).gamma_vol; q.gamma_enc=points(i).gamma_enc;
        q.n_expected=20; q.n_success=height(G);
        q.observed_TV_mean=safe_mean(G.TV); q.observed_TV_sd=safe_std(G.TV);
        q.reference_TV_mean=points(i).ref_mean; q.reference_TV_sd=points(i).ref_sd;
        q.absolute_difference=abs(q.observed_TV_mean-q.reference_TV_mean);
        rows{end+1,1}=q; %#ok<AGROW>
    end
end
S1T=records_to_table(rows);
end

function D=make_diagnostics(CS,GRID)
D=struct();
for a={'clean','snr30'}
    arm=a{1}; R=CS(strcmp(CS.phase,'grid') & strcmp(CS.arm,arm),:);
    suffix=arm;
    if isempty(R)
        D.([suffix '_complete_cells'])=0;
        D.([suffix '_shrink_cells'])=0;
        D.([suffix '_overexpansion_cells'])=0;
        D.([suffix '_fit_n_cells'])=0;
        D.([suffix '_fit_intercept'])=NaN;
        D.([suffix '_fit_slope'])=NaN;
        continue;
    end
    complete=R.n_success==20 & R.n_failed==0 & R.n_pending==0;
    shrink=complete & (R.shrinkage_log_mean-R.shrinkage_log_ci95_halfwidth>0);
    over=complete & (R.shrinkage_log_mean+R.shrinkage_log_ci95_halfwidth<0);
    D.([suffix '_complete_cells'])=sum(complete);
    D.([suffix '_shrink_cells'])=sum(shrink);
    D.([suffix '_overexpansion_cells'])=sum(over);
    if sum(shrink)>=3
        x=0.5*(log(R.gamma_vol(shrink))-log(R.gamma_enc(shrink)));
        y=R.log_s_mean(shrink);
        if rank([ones(numel(x),1),x])==2
            b=[ones(numel(x),1),x]\y;
            D.([suffix '_fit_n_cells'])=numel(x);
            D.([suffix '_fit_intercept'])=b(1);
            D.([suffix '_fit_slope'])=b(2);
        else
            D.([suffix '_fit_n_cells'])=numel(x);
            D.([suffix '_fit_intercept'])=NaN;
            D.([suffix '_fit_slope'])=NaN;
        end
    else
        D.([suffix '_fit_n_cells'])=sum(shrink);
        D.([suffix '_fit_intercept'])=NaN;
        D.([suffix '_fit_slope'])=NaN;
    end
end
D.x_definition='0.5*(log(gamma_vol)-log(gamma_enc))';
D.response_definition='log_s = log(V_est/V_true)';
D.theory_reference_slope=1;
D.gamma_vol_levels=GRID.GAMMA_VOL;
D.gamma_enc_levels=GRID.GAMMA_ENC;
end

function write_protocol_manifest(C,S1,GRID,paths,plan)
fid=fopen(fullfile(C.OUTDIR,'h5v2_protocol_manifest.txt'),'w');
if fid<0,error('Cannot write protocol manifest.');end
fprintf(fid,'DeepMVSA H5-v2 complete 2100-run protocol\n');
fprintf(fid,'Generated: %s\n',datestr(now,31));
fprintf(fid,'Protocol ID: %s\n',C.PROTOCOL_ID);
fprintf(fid,'Run signature: %s\n',C.RUN_SIGNATURE);
fprintf(fid,'Planned runs: %d = 180 S1-slice + 1920 grid\n',height(plan));
fprintf(fid,'No G0 gate and no G0 pass/fail judgment are applied.\n');
fprintf(fid,'The 180 S1-slice settings overlap nine SNR30 grid cells and retain the same rep-specific seed rules.\n');
fprintf(fid,'These two phase records must not be pooled as independent additional replications.\n');
fprintf(fid,'K=%d, p=%d, L=224, N=%d, NREP=%d\n',C.K,C.K+1,C.N,C.NREP);
fprintf(fid,'M_MC=%d, ENC_N_SAMPLES=%d\n',C.M_MC,C.ENC_N_SAMPLES);
fprintf(fid,'ITERS_S1=%d, ITERS_GRID=%d, WARM_UP=%d\n',C.ITERS_S1,C.ITERS_GRID,C.WARM_UP);
fprintf(fid,'LR=%.16g, BATCH_SIZE=%d\n',C.LR,C.BATCH_SIZE);
fprintf(fid,'LAMBDA_NONNEG=%g, LAMBDA_EQ=%g, LAMBDA_SUMONE=%g\n',C.LAMBDA_NONNEG,C.LAMBDA_EQ,C.LAMBDA_SUMONE);
fprintf(fid,'KAPPA0=%g, HIDDEN=%d\n',C.KAPPA0,C.HIDDEN);
fprintf(fid,'DATA_SEED0=%d, TRAIN_SEED0=%d, TV_SEED0=%d\n',C.DATA_SEED0,C.TRAIN_SEED0,C.TV_SEED0);
fprintf(fid,'USGS: %s\nspectMixGen: %s\nModel: %s\nDriver: %s\n',paths.usgs,paths.mixgen,paths.model,paths.demo);
fprintf(fid,'Table-S1 GV levels: %s\n',mat2str(S1.GV_LEVELS));
fprintf(fid,'Table-S1 GE levels: %s\n',mat2str(S1.GE_LEVELS));
fprintf(fid,'Grid GV levels: %s\n',mat2str(GRID.GAMMA_VOL));
fprintf(fid,'Grid GE levels: %s\n',mat2str(GRID.GAMMA_ENC));
fprintf(fid,'Grid arms: %s\n',strjoin(GRID.ARMS,','));
fprintf(fid,'\nStorage: one temporary h5v2_checkpoint.mat; final h5v2_config.mat and h5v2_results.mat.\n');
fprintf(fid,'Per-run M_est and Up are stored as slices in the consolidated checkpoint/results MAT.\n');
fprintf(fid,'M_true is stored once per repetition. Projected M_true_w/M_est_w can be recomputed as Up''*M_true and Up''*M_est.\n');
fclose(fid);
end

function write_run_report(results,D,outdir)
fid=fopen(fullfile(outdir,'h5v2_run_report.txt'),'w');
if fid<0,error('Cannot write run report.');end
fprintf(fid,'=== H5-v2 complete experiment run report ===\n');
fprintf(fid,'Generated: %s\n',results.generated_at);
fprintf(fid,'Protocol: %s\n',results.protocol_id);
fprintf(fid,'Expected runs: %d\n',results.n_expected);
fprintf(fid,'Attempted runs: %d\n',results.n_attempted);
fprintf(fid,'Successful runs: %d\n',results.n_successful);
fprintf(fid,'Failed attempted runs: %d\n',results.n_failed);
fprintf(fid,'Pending runs: %d\n',results.n_pending);
fprintf(fid,'All runs complete: %d\n',results.complete);
rt = results.run_plan_and_results.runtime_s(results.run_plan_and_results.ok);
rt = rt(isfinite(rt));
if isempty(rt), total_runtime = 0; else, total_runtime = sum(rt); end
fprintf(fid,'Total recorded runtime (successful runs, seconds): %.3f\n',total_runtime);
fprintf(fid,'\nG0: not evaluated by design. No G0 gate or G0 pass/fail judgment was performed.\n');
fprintf(fid,'Table-S1 values are included only as descriptive reference comparisons.\n');
fprintf(fid,'The 180 S1-slice runs overlap nine SNR30 grid cells and use the same rep-specific data/training/TV seeds; do not pool them as independent extra replications.\n');
fprintf(fid,'\nDescriptive phase-map diagnostics (not acceptance gates):\n');
fprintf(fid,'clean: complete cells=%d, shrink cells=%d, over-expansion cells=%d, fit cells=%d, fit slope=%.6f\n', ...
    D.clean_complete_cells,D.clean_shrink_cells,D.clean_overexpansion_cells,D.clean_fit_n_cells,D.clean_fit_slope);
fprintf(fid,'snr30: complete cells=%d, shrink cells=%d, over-expansion cells=%d, fit cells=%d, fit slope=%.6f\n', ...
    D.snr30_complete_cells,D.snr30_shrink_cells,D.snr30_overexpansion_cells,D.snr30_fit_n_cells,D.snr30_fit_slope);
fprintf(fid,'\nStorage note: final outputs contain 2 MAT, 4 CSV, and 2 TXT files.\n');
fclose(fid);
end
