%% H5-v2 formal phase-map experiment for DeepMVSA
% This is a MATLAB SCRIPT (not a function). Edit MODE and the settings
% below, then run this file.
%
% Run order:
%   1) MODE='smoke'   : 9 Table-S1 cells x 20 reps = 180 runs.
%   2) Confirm G0 PASS in h5v2_verdict.txt.
%   3) MODE='grid'    : 8 x 6 cells x {clean,snr30} x 20 reps = 1920 runs.
%   4) MODE='collate' : regenerate summaries from existing checkpoints.
%      If only collation code was repaired, the saved config signature is
%      reused when settings/dependency files still match; no retraining.
%
% The grid mode is blocked unless the complete smoke phase passes G0.
%
% Required files:
%   USGS_1995_Library.mat (variable datalib, 224 x spectra)
%   spectMixGen.m
%   deep_mvsa_invflow_H5.m (file name must match its function name)
%
% Local functions at the end of this script require MATLAB R2016b or newer.

clear;
clc;
close all;

%% ------------------------- USER SETTINGS -----------------------------
MODE = 'collate';   % 'smoke' | 'grid' | 'collate'

K = 5;
N = 1e4;
NREP = 20;
USGS_MAT = 'USGS_1995_Library.mat';
OUTDIR = 'outputs_h5v2_H5model';

% Geometry evaluation
M_MC = 2e4;
ENC_N_SAMPLES = 2000;

% Training protocol
ITERS_SMOKE = 1500;
ITERS_GRID = 1500;
WARM_UP = 600;
LR = 1e-3;
BATCH_SIZE = 4096;
LAMBDA_NONNEG = 5;
LAMBDA_EQ = 80;
LAMBDA_SUMONE = 2;
KAPPA0 = 0.05;
HIDDEN = 32;
MODEL_VERBOSE = 0;

% Registered random seeds
DATA_SEED0 = 203000;
TRAIN_SEED0 = 503000;
TV_SEED0 = 12345;

%% ------------------------- CONFIG STRUCT ------------------------------
C = struct();
C.MODE = MODE;
C.K = K;
C.N = N;
C.NREP = NREP;
C.USGS_MAT = USGS_MAT;
C.OUTDIR = OUTDIR;
C.M_MC = M_MC;
C.ENC_N_SAMPLES = ENC_N_SAMPLES;
C.ITERS_SMOKE = ITERS_SMOKE;
C.ITERS_GRID = ITERS_GRID;
C.WARM_UP = WARM_UP;
C.LR = LR;
C.BATCH_SIZE = BATCH_SIZE;
C.LAMBDA_NONNEG = LAMBDA_NONNEG;
C.LAMBDA_EQ = LAMBDA_EQ;
C.LAMBDA_SUMONE = LAMBDA_SUMONE;
C.KAPPA0 = KAPPA0;
C.HIDDEN = HIDDEN;
C.MODEL_VERBOSE = MODEL_VERBOSE;
C.DATA_SEED0 = DATA_SEED0;
C.TRAIN_SEED0 = TRAIN_SEED0;
C.TV_SEED0 = TV_SEED0;

validate_inputs(C);
[S1,GRID] = h5_design();

%% ------------------------- DEPENDENCIES -------------------------------
paths = check_dependencies(C);
C.MODEL_PATH = paths.model;
C.SPECTMIXGEN_PATH = paths.mixgen;
C.USGS_PATH = paths.usgs;
C.PROTOCOL_ID = 'H5v2_USGS_SPECTMIXGEN_H5MODEL_20261124_R3';

C.CANONICAL_SMOKE_SETTINGS = canonical_smoke_settings(C);
C.CANONICAL_GRID_SETTINGS = canonical_grid_settings(C);
C.RUN_SIGNATURE = make_run_signature(C,paths,GRID);
% The aggregation-only repair changes the driver file checksum. When the
% saved configuration and all training/data settings are unchanged, reuse
% the signature recorded before the completed Smoke runs so that existing
% checkpoints remain valid for collate and subsequent Grid execution.
[C.RUN_SIGNATURE,signature_reused] = reuse_saved_run_signature( ...
    C,paths,S1,GRID,C.RUN_SIGNATURE);
if signature_reused
    fprintf('Reusing the saved run signature for existing checkpoints.\n');
end

if ~exist(C.OUTDIR,'dir')
    mkdir(C.OUTDIR);
end
rundir = fullfile(C.OUTDIR,'runs');
if ~exist(rundir,'dir')
    mkdir(rundir);
end

existing_run_files = dir(fullfile(rundir,'run_*.mat'));
if ~isempty(existing_run_files) && ~signature_reused
    error(['Existing H5 checkpoints were found, but the saved configuration ' ...
        'could not be verified against the current settings/dependencies. ' ...
        'The old configuration was not overwritten. Restore the original ' ...
        'h5v2_config.mat or use the original driver/dependency files.']);
end

write_protocol_manifest(C,S1,GRID,paths);
save(fullfile(C.OUTDIR,'h5v2_config.mat'),'C','S1','GRID','paths','-v7');

fprintf('\n============================================================\n');
fprintf('H5-v2 formal driver\n');
fprintf('MODE       : %s\n',lower(C.MODE));
fprintf('MODEL      : %s\n',paths.model);
fprintf('USGS       : %s\n',paths.usgs);
fprintf('OUTPUT     : %s\n',C.OUTDIR);
fprintf('K / p / L  : %d / %d / 224\n',C.K,C.K+1);
fprintf('N / NREP   : %d / %d\n',C.N,C.NREP);
fprintf('Canonical smoke settings: %d\n',C.CANONICAL_SMOKE_SETTINGS);
fprintf('Canonical grid settings : %d\n',C.CANONICAL_GRID_SETTINGS);
fprintf('============================================================\n\n');

%% ------------------------- MODE DISPATCH ------------------------------
switch lower(C.MODE)
    case 'smoke'
        cells = smoke_cells(S1);
        arms = {'snr30'};
        run_all(cells,arms,C.ITERS_SMOKE,'smoke',C,rundir);
        V = collate(rundir,C,S1,GRID,'smoke'); %#ok<NASGU>
        if ~V.G0_smoke_pass
            fprintf(2,['\nG0 NOT PASSED. The full grid is blocked. ' ...
                'Inspect h5v2_tableS1_check.csv and h5v2_verdict.txt.\n\n']);
        else
            fprintf('\nG0 PASSED. Change MODE to grid and rerun this script.\n\n');
        end

    case 'grid'
        % Mandatory preflight: the full grid is not allowed to start unless
        % the complete smoke phase passes G0 under the current signature.
        Vpre = collate(rundir,C,S1,GRID,'pregrid');
        if ~isfield(Vpre,'G0_smoke_pass') || ~Vpre.G0_smoke_pass
            error(['H5-v2 grid blocked: G0 smoke gate has not passed. ' ...
                'Complete/fix the 180 smoke runs and pass Table-S1 consistency first.']);
        end

        cells = grid_cells(GRID);
        run_all(cells,GRID.ARMS,C.ITERS_GRID,'grid',C,rundir);
        V = collate(rundir,C,S1,GRID,'grid'); %#ok<NASGU>

    case 'collate'
        V = collate(rundir,C,S1,GRID,'auto'); %#ok<NASGU>

    otherwise
        error('MODE must be smoke, grid, or collate.');
end

%% =====================================================================
%                           DESIGN CONSTANTS
% ======================================================================
function [S1,GRID] = h5_design()
% Published Table-S1 reference values (K=5, N=1e4, SNR=30 dB, 20 reps).
S1.GV_LEVELS = [0.0025 0.005 0.01 0.02 0.04];
S1.GV_TV = [0.44 0.43 0.43 0.43 0.43];
S1.GV_SD = [0.13 0.13 0.13 0.13 0.13];

S1.GE_LEVELS = [2.5 5 10 20 40];
S1.GE_TV = [0.48 0.46 0.43 0.42 0.43];
S1.GE_SD = [0.14 0.14 0.13 0.11 0.11];

S1.DEFAULT = struct('gamma_vol',0.01,'gamma_enc',10);
S1.NREP = 20;

% Registered H5-v2 phase-map grid.
GRID.GAMMA_VOL = [0.0025 0.005 0.01 0.02 0.04 0.08 0.16 0.32];
GRID.GAMMA_ENC = [1.25 2.5 5 10 20 40];
GRID.ARMS = {'clean','snr30'};
end

function validate_inputs(C)
if ~any(strcmpi(C.MODE,{'smoke','grid','collate'}))
    error('MODE must be smoke, grid, or collate.');
end
if ~isscalar(C.K) || ~isfinite(C.K) || C.K < 1 || C.K ~= round(C.K)
    error('K must be a positive integer.');
end
if ~isscalar(C.N) || ~isfinite(C.N) || C.N < 1 || C.N ~= round(C.N)
    error('N must be a positive integer.');
end
if ~isscalar(C.NREP) || ~isfinite(C.NREP) || C.NREP < 1 || C.NREP ~= round(C.NREP)
    error('NREP must be a positive integer.');
end
if ~isscalar(C.M_MC) || ~isfinite(C.M_MC) || C.M_MC < 100 || C.M_MC ~= round(C.M_MC)
    error('M_MC must be an integer >= 100.');
end
if ~isscalar(C.ENC_N_SAMPLES) || C.ENC_N_SAMPLES < 1 || ...
        C.ENC_N_SAMPLES ~= round(C.ENC_N_SAMPLES)
    error('ENC_N_SAMPLES must be a positive integer.');
end
if ~isscalar(C.WARM_UP) || C.WARM_UP < 0 || C.WARM_UP ~= round(C.WARM_UP)
    error('WARM_UP must be a nonnegative integer.');
end
if C.ITERS_SMOKE <= C.WARM_UP || C.ITERS_GRID <= C.WARM_UP
    error('Both ITERS_SMOKE and ITERS_GRID must be greater than WARM_UP.');
end
if C.BATCH_SIZE < 1 || C.BATCH_SIZE ~= round(C.BATCH_SIZE)
    error('BATCH_SIZE must be a positive integer.');
end
if C.HIDDEN < 1 || C.HIDDEN ~= round(C.HIDDEN)
    error('HIDDEN must be a positive integer.');
end
if C.LR <= 0 || C.KAPPA0 < 0
    error('LR must be positive and KAPPA0 must be nonnegative.');
end
if C.LAMBDA_NONNEG < 0 || C.LAMBDA_EQ < 0 || C.LAMBDA_SUMONE < 0
    error('The nonnegative/equality/sum-one penalty weights must be nonnegative.');
end
end

function paths = check_dependencies(C)
if exist(C.USGS_MAT,'file') ~= 2
    error('Cannot find USGS_MAT: %s',C.USGS_MAT);
end
if exist('spectMixGen','file') ~= 2
    error('Cannot find spectMixGen.m on the MATLAB path.');
end
if exist('deep_mvsa_invflow_H5','file') ~= 2
    error(['Cannot find deep_mvsa_invflow_H5.m. The model file must be named ' ...
        'exactly deep_mvsa_invflow_H5.m and its folder must be on the MATLAB path.']);
end

paths.usgs = which(C.USGS_MAT);
if isempty(paths.usgs)
    paths.usgs = C.USGS_MAT;
end
paths.mixgen = which('spectMixGen');
paths.model = which('deep_mvsa_invflow_H5');

if isempty(paths.mixgen) || isempty(paths.model)
    error('MATLAB could not resolve spectMixGen or deep_mvsa_invflow_H5.');
end

% Check the library variable and canonical spectral dimensions before training.
S = load(paths.usgs,'datalib');
if ~isfield(S,'datalib')
    error('USGS_MAT must contain a variable named datalib.');
end
D = S.datalib;
if ~isnumeric(D) || ndims(D) ~= 2
    error('datalib must be a numeric two-dimensional matrix.');
end
if size(D,1) ~= 224
    error('Canonical H5 protocol expects 224 spectral bands; datalib has %d rows.',size(D,1));
end
if size(D,2) < 4 + C.K + 1
    error('datalib has too few columns for K+1=%d endmembers after the first four metadata columns.',C.K+1);
end
bad = ~isfinite(D(:,5:end));
if any(bad(:))
    error('USGS spectral columns 5:end contain NaN or Inf values.');
end

paths.usgs_bytes = file_bytes(paths.usgs);
paths.mixgen_bytes = file_bytes(paths.mixgen);
paths.model_bytes = file_bytes(paths.model);
demo_path = which('demo_H5_v2_phase_map');
if isempty(demo_path)
    demo_path = [pwd filesep 'demo_H5_v2_phase_map.m'];
end
paths.demo = demo_path;
paths.demo_bytes = file_bytes(demo_path);
end

function n = file_bytes(path)
d = dir(path);
if isempty(d)
    n = NaN;
else
    n = d(1).bytes;
end
end

function tf = canonical_smoke_settings(C)
tf = C.K == 5 && C.N == 1e4 && C.NREP == 20 && ...
    C.M_MC == 2e4 && C.ITERS_SMOKE == 1500 && C.WARM_UP == 600 && ...
    abs(C.LR-1e-3) < 1e-15 && C.BATCH_SIZE == 4096 && ...
    C.LAMBDA_NONNEG == 5 && C.LAMBDA_EQ == 80 && ...
    C.LAMBDA_SUMONE == 2 && abs(C.KAPPA0-0.05) < 1e-12 && ...
    C.HIDDEN == 32 && C.DATA_SEED0 == 203000 && ...
    C.TRAIN_SEED0 == 503000 && C.TV_SEED0 == 12345 && ...
    C.ENC_N_SAMPLES == 2000;
end

function tf = canonical_grid_settings(C)
tf = canonical_smoke_settings(C) && C.ITERS_GRID == 1500;
end

function [sig,reused] = reuse_saved_run_signature(C,paths,S1,GRID,new_sig)
% Reuse a previous checkpoint signature only when the saved experiment
% configuration and the actual data/model dependencies still match.
% This is needed for an aggregation-only code repair: the driver checksum
% changes, but the already-completed training runs must remain readable.
sig = new_sig;
reused = false;
if ~any(strcmpi(C.MODE,{'smoke','grid','collate'}))
    return;
end
cfgfile = fullfile(C.OUTDIR,'h5v2_config.mat');
if exist(cfgfile,'file') ~= 2
    return;
end
try
    old = load(cfgfile,'C','paths','S1','GRID');
catch
    return;
end
if ~isfield(old,'C') || ~isfield(old,'paths') || ...
        ~isfield(old,'S1') || ~isfield(old,'GRID') || ...
        ~isfield(old.C,'RUN_SIGNATURE') || ~isfield(old.C,'PROTOCOL_ID')
    return;
end
oldC = old.C;
oldPaths = old.paths;
if ~strcmp(oldC.PROTOCOL_ID,C.PROTOCOL_ID) || ...
        ~isequaln(old.S1,S1) || ~isequaln(old.GRID,GRID)
    return;
end

% MODE is intentionally excluded because Smoke, Grid and Collate share
% the same registered experiment/checkpoint family.
config_fields = {'K','N','NREP','USGS_MAT','OUTDIR','M_MC', ...
    'ENC_N_SAMPLES','ITERS_SMOKE','ITERS_GRID','WARM_UP','LR', ...
    'BATCH_SIZE','LAMBDA_NONNEG','LAMBDA_EQ','LAMBDA_SUMONE', ...
    'KAPPA0','HIDDEN','MODEL_VERBOSE','DATA_SEED0','TRAIN_SEED0','TV_SEED0'};
n = numel(config_fields);
for k = 1:n
    f = config_fields{k};
    if ~isfield(oldC,f) || ~isequaln(C.(f),oldC.(f))
        return;
    end
end

% Compare dependency locations and file sizes. Do not compare the driver
% byte count: only the collation accumulator implementation was repaired.
path_fields = {'usgs','mixgen','model','demo'};
for k = 1:numel(path_fields)
    f = path_fields{k};
    if ~isfield(oldPaths,f) || ~isfield(paths,f) || ...
            ~isequaln(paths.(f),oldPaths.(f))
        return;
    end
end
size_fields = {'usgs_bytes','mixgen_bytes','model_bytes'};
for k = 1:numel(size_fields)
    f = size_fields{k};
    if ~isfield(oldPaths,f) || ~isfield(paths,f) || ...
            ~isequaln(paths.(f),oldPaths.(f))
        return;
    end
end

% Verify the original dependency timestamps embedded in the checkpoint
% signature, not just their paths and byte counts.
stamp_tokens = {['MODEL=' file_stamp(paths.model)], ...
    ['MIX=' file_stamp(paths.mixgen)], ['USGS=' file_stamp(paths.usgs)]};
for k = 1:numel(stamp_tokens)
    if isempty(strfind(oldC.RUN_SIGNATURE,stamp_tokens{k})) %#ok<STREMP>
        return;
    end
end

sig = oldC.RUN_SIGNATURE;
reused = true;
end

function sig = make_run_signature(C,paths,GRID)
% The MODE line is deliberately excluded from the driver checksum so that
% changing MODE from smoke to grid does not invalidate the smoke files.
driver_sig = driver_code_signature(paths.demo);
model_stamp = file_stamp(paths.model);
mix_stamp = file_stamp(paths.mixgen);
usgs_stamp = file_stamp(paths.usgs);

sig = sprintf(['%s|K=%g|N=%g|NREP=%g|MMC=%g|SMOKE=%g|GRID=%g|' ...
    'WARM=%g|LR=%.16g|BATCH=%g|NONNEG=%g|EQ=%g|SUMONE=%g|' ...
    'KAPPA=%.16g|HIDDEN=%g|DSEED=%g|TSEED=%g|TVSEED=%g|' ...
    'ENCN=%g|GV=%s|GE=%s|ARMS=%s|DRIVER=%s|MODEL=%s|MIX=%s|USGS=%s'], ...
    C.PROTOCOL_ID,C.K,C.N,C.NREP,C.M_MC,C.ITERS_SMOKE,C.ITERS_GRID, ...
    C.WARM_UP,C.LR,C.BATCH_SIZE,C.LAMBDA_NONNEG,C.LAMBDA_EQ, ...
    C.LAMBDA_SUMONE,C.KAPPA0,C.HIDDEN,C.DATA_SEED0,C.TRAIN_SEED0, ...
    C.TV_SEED0,C.ENC_N_SAMPLES,mat2str(GRID.GAMMA_VOL,12), ...
    mat2str(GRID.GAMMA_ENC,12),strjoin(GRID.ARMS,','), ...
    driver_sig,model_stamp,mix_stamp,usgs_stamp);
end

function s = driver_code_signature(path)
txt = fileread(path);
lines = regexp(txt,'\r\n|\n|\r','split');
for i = 1:numel(lines)
    if ~isempty(regexp(strtrim(lines{i}),'^MODE\s*=','once'))
        lines{i} = 'MODE = ''<MODE>'';';
    end
end
txt = strjoin(lines,sprintf('\n'));
w = mod((1:numel(txt))',997) + 1;
checksum = sum(double(txt(:)).*w);
s = sprintf('%d|%.0f',numel(txt),checksum);
end

function s = file_stamp(path)
d = dir(path);
if isempty(d)
    s = sprintf('%s|MISSING',path);
else
    s = sprintf('%s|%d|%.15g',path,d(1).bytes,d(1).datenum);
end
end

function write_protocol_manifest(C,S1,GRID,paths)
fid = fopen(fullfile(C.OUTDIR,'h5v2_protocol_manifest.txt'),'w');
if fid < 0
    warning('Could not write h5v2_protocol_manifest.txt.');
    return;
end
fprintf(fid,'H5-v2 protocol manifest\n');
fprintf(fid,'Generated: %s\n',datestr(now,31));
fprintf(fid,'Protocol ID: %s\n',C.PROTOCOL_ID);
fprintf(fid,'Run signature: %s\n\n',C.RUN_SIGNATURE);
fprintf(fid,'MODE: %s\n',lower(C.MODE));
fprintf(fid,'K=%g, p=K+1=%g, L=224, N=%g, NREP=%g\n',C.K,C.K+1,C.N,C.NREP);
fprintf(fid,'M_MC=%g, ENC_N_SAMPLES=%g\n',C.M_MC,C.ENC_N_SAMPLES);
fprintf(fid,'ITERS_SMOKE=%g, ITERS_GRID=%g, WARM_UP=%g\n', ...
    C.ITERS_SMOKE,C.ITERS_GRID,C.WARM_UP);
fprintf(fid,'LR=%.16g, BATCH_SIZE=%g\n',C.LR,C.BATCH_SIZE);
fprintf(fid,'LAMBDA_NONNEG=%g, LAMBDA_EQ=%g, LAMBDA_SUMONE=%g\n', ...
    C.LAMBDA_NONNEG,C.LAMBDA_EQ,C.LAMBDA_SUMONE);
fprintf(fid,'KAPPA0=%.16g, HIDDEN=%g\n',C.KAPPA0,C.HIDDEN);
fprintf(fid,'DATA_SEED0=%g, TRAIN_SEED0=%g, TV_SEED0=%g\n', ...
    C.DATA_SEED0,C.TRAIN_SEED0,C.TV_SEED0);
fprintf(fid,'Canonical smoke settings: %d\n',C.CANONICAL_SMOKE_SETTINGS);
fprintf(fid,'Canonical grid settings: %d\n\n',C.CANONICAL_GRID_SETTINGS);
fprintf(fid,'USGS file: %s\n',paths.usgs);
fprintf(fid,'spectMixGen: %s\n',paths.mixgen);
fprintf(fid,'H5 model: %s\n',paths.model);
fprintf(fid,'Driver: %s\n\n',paths.demo);
fprintf(fid,'Table-S1 default: gamma_vol=%g, gamma_enc=%g\n', ...
    S1.DEFAULT.gamma_vol,S1.DEFAULT.gamma_enc);
fprintf(fid,'Table-S1 gamma_vol levels: %s\n',mat2str(S1.GV_LEVELS));
fprintf(fid,'Table-S1 gamma_enc levels: %s\n',mat2str(S1.GE_LEVELS));
fprintf(fid,'Grid gamma_vol levels: %s\n',mat2str(GRID.GAMMA_VOL));
fprintf(fid,'Grid gamma_enc levels: %s\n',mat2str(GRID.GAMMA_ENC));
fprintf(fid,'Grid arms: %s\n',strjoin(GRID.ARMS,','));
fprintf(fid,'\nModel called: deep_mvsa_invflow_H5\n');
fprintf(fid,'E1_MONITOR_INTERVAL=0; E3_SKIP_ABUNDANCE_OUTPUT=true.\n');
fprintf(fid,'G3 definition: s=V_est/V_true; log(s)=log(V_est/V_true).\n');
fclose(fid);
end

%% =====================================================================
%                         CELL DEFINITIONS
% ======================================================================
function cells = smoke_cells(S1)
% Default plus one-factor Table-S1 slices: 9 unique cells.
cells = struct('gamma_vol',{},'gamma_enc',{},'tag',{});
cells(end+1) = make_cell(S1.DEFAULT.gamma_vol,S1.DEFAULT.gamma_enc,'smoke_default');

for i = 1:numel(S1.GV_LEVELS)
    gv = S1.GV_LEVELS(i);
    if abs(gv-S1.DEFAULT.gamma_vol) < 1e-12
        continue;
    end
    cells(end+1) = make_cell(gv,S1.DEFAULT.gamma_enc, ...
        sprintf('smoke_gv%g',gv)); %#ok<AGROW>
end

for i = 1:numel(S1.GE_LEVELS)
    ge = S1.GE_LEVELS(i);
    if abs(ge-S1.DEFAULT.gamma_enc) < 1e-12
        continue;
    end
    cells(end+1) = make_cell(S1.DEFAULT.gamma_vol,ge, ...
        sprintf('smoke_ge%g',ge)); %#ok<AGROW>
end
end

function cells = grid_cells(GRID)
cells = struct('gamma_vol',{},'gamma_enc',{},'tag',{});
for gv = GRID.GAMMA_VOL
    for ge = GRID.GAMMA_ENC
        cells(end+1) = make_cell(gv,ge, ...
            sprintf('grid_gv%g_ge%g',gv,ge)); %#ok<AGROW>
    end
end
end

function s = make_cell(gv,ge,tag)
s = struct('gamma_vol',gv,'gamma_enc',ge,'tag',tag);
end

%% =====================================================================
%                         RUN LOOP / CHECKPOINTS
% ======================================================================
function run_all(cells,arms,iters,phase,C,rundir)
datalib = load_usgs(C.USGS_PATH);
p = C.K + 1;
nRun = numel(cells)*numel(arms)*C.NREP;
completed_or_skipped = 0;
attempted = 0;

fprintf('\nStarting %s phase: %d expected runs.\n',upper(phase),nRun);

% One paired data generation per repetition. The same M_true, abundances,
% and data are reused across all parameter cells and both noise arms.
for rep = 1:C.NREP
    todo = false(numel(cells),numel(arms));
    tags = cell(numel(cells),numel(arms));

    for ci = 1:numel(cells)
        for ai = 1:numel(arms)
            tag = sprintf('%s_%s_rep%02d',cells(ci).tag,arms{ai},rep);
            tags{ci,ai} = tag;
            fmat = fullfile(rundir,['run_' tag '.mat']);
            todo(ci,ai) = ~checkpoint_is_complete(fmat,tag,C);
            if ~todo(ci,ai)
                completed_or_skipped = completed_or_skipped + 1;
            end
        end
    end

    if ~any(todo(:))
        fprintf('[%s] rep %02d/%02d: all checkpoints already complete; skipped data generation.\n', ...
            upper(phase),rep,C.NREP);
        continue;
    end

    dseed = C.DATA_SEED0 + rep;
    fprintf('\n[%s] Generating paired USGS data for rep %02d/%02d (seed=%d).\n', ...
        upper(phase),rep,C.NREP,dseed);
    [Ypair,M_true] = gen_pair(datalib,p,C.N,dseed);

    for ci = 1:numel(cells)
        for ai = 1:numel(arms)
            if ~todo(ci,ai)
                continue;
            end

            arm = arms{ai};
            tag = tags{ci,ai};
            celldef = cells(ci);
            fmat = fullfile(rundir,['run_' tag '.mat']);

            fprintf('[%s] %s | gamma_vol=%g | gamma_enc=%g\n', ...
                upper(phase),tag,celldef.gamma_vol,celldef.gamma_enc);

            rec = run_one(Ypair.(arm),M_true,p,celldef,arm,rep,iters,C);
            rec.tag = tag;
            rec.phase = phase;
            rec.cell_tag = celldef.tag;
            rec.gamma_vol = celldef.gamma_vol;
            rec.gamma_enc = celldef.gamma_enc;
            rec.arm = arm;
            rec.rep = rep;
            rec.iters = iters;
            rec.N = C.N;
            rec.K = C.K;
            rec.p = p;
            rec.L = size(M_true,1);
            rec.M_MC = C.M_MC;
            rec.seed_data = dseed;
            rec.seed_train = C.TRAIN_SEED0 + rep;
            rec.seed_tv = C.TV_SEED0 + rep;
            rec.protocol_id = C.PROTOCOL_ID;
            rec.run_signature = C.RUN_SIGNATURE;
            rec.model_file = C.MODEL_PATH;
            rec.usgs_file = C.USGS_PATH;
            rec.spectMixGen_file = C.SPECTMIXGEN_PATH;
            rec.M_true = M_true;

            % Atomic checkpoint write: an interrupted save will not leave a
            % partially written run_*.mat file.
            tmpfile = [fmat '.tmp'];
            save(tmpfile,'-struct','rec','-v7');
            [ok,msg] = movefile(tmpfile,fmat,'f');
            if ~ok
                error('Could not finalize checkpoint %s: %s',fmat,msg);
            end

            attempted = attempted + 1;
            fprintf('    status=%s, TV=%.5f, runtime=%.1f s\n', ...
                rec.status,rec.TV,rec.runtime_s);
        end
    end
end

fprintf('\n%s phase loop finished. Newly attempted=%d; already complete/skipped=%d; expected=%d.\n', ...
    upper(phase),attempted,completed_or_skipped,nRun);
end

function tf = checkpoint_is_complete(fmat,tag,C)
tf = false;
if exist(fmat,'file') ~= 2
    return;
end

try
    R = load(fmat);
catch
    warning('Checkpoint %s cannot be read; it will be rerun.',fmat);
    return;
end

if ~isfield(R,'protocol_id') || ~isfield(R,'run_signature')
    error(['Existing checkpoint %s is from an older/incompatible H5 driver. ' ...
        'Use a new OUTDIR; old results have not been overwritten.'],fmat);
end
if ~strcmp(R.protocol_id,C.PROTOCOL_ID) || ~strcmp(R.run_signature,C.RUN_SIGNATURE)
    error(['Checkpoint %s has a different protocol/run signature. ' ...
        'Use a new OUTDIR rather than mixing different experiments.'],fmat);
end
if ~isfield(R,'tag') || ~strcmp(R.tag,tag)
    error('Checkpoint tag mismatch in %s.',fmat);
end

required = {'status','TV','vol_T','vol_E','volume_ratio','shrinkage_log', ...
    'M_true','M_est','Up','M_true_w','M_est_w'};
has_required = true;
for i = 1:numel(required)
    if ~isfield(R,required{i})
        has_required = false;
        break;
    end
end

if has_required && strcmp(R.status,'ok') && ...
        isfinite(R.TV) && isfinite(R.vol_T) && isfinite(R.vol_E) && ...
        isfinite(R.volume_ratio) && isfinite(R.shrinkage_log) && ...
        isfinite(R.log_s) && isfinite(R.enc_N) && ...
        ~isempty(R.M_est) && ~isempty(R.M_true)
    tf = true;
else
    fprintf('    Existing checkpoint %s is failed/incomplete; it will be retried.\n',tag);
end
end

function rec = run_one(Y,M_true,p,celldef,arm,rep,iters,C)
rec = empty_run_record();
t0 = tic;

try
    tseed = C.TRAIN_SEED0 + rep;
    vseed = C.TV_SEED0 + rep;

    % H5-specific model fork supplied for this experiment.
    [M_est,~,Up,my,~,~,full_loss] = deep_mvsa_invflow_H5(Y,p, ...
        'spherize','yes', ...
        'verbose',C.MODEL_VERBOSE, ...
        'MM_ITERS',iters, ...
        'WARM_UP',C.WARM_UP, ...
        'LR',C.LR, ...
        'LAMBDA_VOL',celldef.gamma_vol, ...
        'LAMBDA_ENCLOSE',celldef.gamma_enc, ...
        'LAMBDA_NONNEG',C.LAMBDA_NONNEG, ...
        'LAMBDA_EQ',C.LAMBDA_EQ, ...
        'LAMBDA_SUMONE',C.LAMBDA_SUMONE, ...
        'BATCH_SIZE',C.BATCH_SIZE, ...
        'SEED',tseed, ...
        'KAPPA0',C.KAPPA0, ...
        'HIDDEN',C.HIDDEN, ...
        'FREEZE_Q_WARMUP',true, ...
        'E1_MONITOR_INTERVAL',0, ...
        'E3_SKIP_ABUNDANCE_OUTPUT',true);

    if ~isequal(size(M_est),size(M_true))
        error('M_est has size %s; expected %s.', ...
            mat2str(size(M_est)),mat2str(size(M_true)));
    end
    if size(Up,1) ~= size(M_true,1) || size(Up,2) ~= p
        error('Up has an unexpected size: %s.',mat2str(size(Up)));
    end
    if any(~isfinite(M_est(:))) || any(~isfinite(Up(:)))
        error('The H5 model returned NaN/Inf in M_est or Up.');
    end
    if norm(Up'*Up-eye(p),'fro') > 1e-5
        error('The returned Up basis is not numerically orthonormal.');
    end
    if ~isstruct(full_loss) || ~isfield(full_loss,'total') || ...
            ~isfield(full_loss,'recon') || ...
            ~isfinite(full_loss.total) || ~isfinite(full_loss.recon)
        error('The H5 model returned an invalid full-data objective.');
    end

    % E2/Table-S1 geometry: both simplexes are mapped by the same Up''.
    M_true_w = Up' * M_true;
    M_est_w = Up' * M_est;

    [DTV,vol_T,vol_E,r_T,r_E] = tv_canonical(M_true_w,M_est_w,C.M_MC,vseed);
    if ~(isfinite(DTV) && isfinite(vol_T) && isfinite(vol_E) && ...
            vol_T > 0 && vol_E > 0)
        error('Canonical TV evaluation returned a non-finite/degenerate simplex.');
    end

    idx = unique(round(linspace(1,size(Y,2), ...
        min(C.ENC_N_SAMPLES,size(Y,2)))));
    Y_w = Up' * Y(:,idx);
    enc_N = 1 - mean(in_simplex(Y_w,M_est_w));
    if ~isfinite(enc_N) || ~isfinite(r_T) || ~isfinite(r_E)
        error('The enclosure/Monte Carlo diagnostics returned NaN or Inf.');
    end

    rec.status = 'ok';
    rec.failure = '';
    rec.TV = DTV;
    rec.vol_T = vol_T;
    rec.vol_E = vol_E;
    rec.volume_ratio = vol_E / vol_T;       % s = V_est / V_true
    rec.log_s = log(rec.volume_ratio);      % log(s), used by G3
    rec.shrinkage_log = log(vol_T / vol_E); % -log(s), positive = shrinkage
    rec.r_T = r_T;
    rec.r_E = r_E;
    rec.enc_N = enc_N;
    rec.M_est = M_est;
    rec.Up = Up;
    rec.my = my;
    rec.M_true_w = M_true_w;
    rec.M_est_w = M_est_w;
    rec.model_full_loss = full_loss;
    rec.model_full_loss_total = full_loss.total;
    rec.model_full_loss_recon = full_loss.recon;

catch ME
    rec.status = 'failed';
    rec.failure = ME.message;
    rec.failure_identifier = ME.identifier;
    rec.failure_stack = ME.stack;
end

rec.runtime_s = toc(t0);
end

function rec = empty_run_record()
rec = struct();
rec.status = 'failed';
rec.failure = '';
rec.failure_identifier = '';
rec.failure_stack = [];
rec.TV = NaN;
rec.vol_T = NaN;
rec.vol_E = NaN;
rec.volume_ratio = NaN;
rec.log_s = NaN;
rec.shrinkage_log = NaN;
rec.r_T = NaN;
rec.r_E = NaN;
rec.enc_N = NaN;
rec.runtime_s = NaN;
rec.M_est = [];
rec.Up = [];
rec.my = [];
rec.M_true_w = [];
rec.M_est_w = [];
rec.model_full_loss = struct();
rec.model_full_loss_total = NaN;
rec.model_full_loss_recon = NaN;
end

%% =====================================================================
%                           CANONICAL DATA
% ======================================================================
function datalib = load_usgs(usgs_mat)
S = load(usgs_mat,'datalib');
if ~isfield(S,'datalib')
    error('USGS_MAT must contain variable ''datalib''.');
end
datalib = double(S.datalib);
if size(datalib,1) ~= 224
    error('Expected a 224-by-N USGS spectral library; received %s.',mat2str(size(datalib)));
end
if size(datalib,2) < 5
    error('USGS datalib must contain four metadata columns followed by spectra.');
end
bad = ~isfinite(datalib(:,5:end));
if any(bad(:))
    error('USGS spectral library contains NaN/Inf values in columns 5:end.');
end
end

function [Ypair,M_true] = gen_pair(datalib,p,N,dseed)
% Seeded USGS column selection; first four columns are metadata.
rng(dseed,'twister');
n_mat = size(datalib,2);
if n_mat-4 < p
    error('USGS library has %d spectral columns; %d are required.',n_mat-4,p);
end
sel_all = 4 + randperm(n_mat-4);
sel = sel_all(1:p);
M_true = datalib(:,sel);

% One generator call produces the SNR30 arm and the shared abundances.
[Y30,x] = spectMixGen(M_true,N, ...
    'Source_pdf','Diri_id', ...
    'pdf_pars',1, ...
    'max_purity',0.8*ones(1,p), ...
    'no_outliers',0, ...
    'violation_extremes',[1 1.2], ...
    'snr',30, ...
    'noise_shape','uniform');

if size(Y30,1) ~= size(M_true,1) || size(Y30,2) ~= N
    error('spectMixGen returned Y30 with unexpected size %s.',mat2str(size(Y30)));
end
if size(x,1) ~= p || size(x,2) ~= N
    error('spectMixGen returned abundance matrix x with unexpected size %s.',mat2str(size(x)));
end
if any(~isfinite(Y30(:))) || any(~isfinite(x(:)))
    error('spectMixGen returned NaN/Inf values.');
end

Ypair.snr30 = Y30;
Ypair.clean = M_true * x;
end

%% =====================================================================
%                         CANONICAL TV METRIC
% ======================================================================
function [D_TV,vol_T,vol_E,r_T,r_E] = tv_canonical(M_T,M_E,M_MC,seed)
% Symmetric two-direction Monte Carlo estimate:
% D_TV = 1 - Vol(intersection)/max(Vol_T,Vol_E).
% Volumes use the Gram determinant; draws are uniform Dirichlet(1).
rng(seed,'twister');

if size(M_T,1) ~= size(M_E,1) || size(M_T,2) ~= size(M_E,2)
    error('The two projected endpoint matrices must have identical sizes.');
end
p = size(M_T,2);
K = p-1;
if size(M_T,1) < K
    error('The projected space has insufficient dimension for this simplex.');
end

E_T = M_T(:,2:p) - repmat(M_T(:,1),1,K);
E_E = M_E(:,2:p) - repmat(M_E(:,1),1,K);

vol_T = sqrt(max(real(det(E_T'*E_T)),0)) / factorial(K);
vol_E = sqrt(max(real(det(E_E'*E_E)),0)) / factorial(K);
if ~(isfinite(vol_T) && isfinite(vol_E) && vol_T > 0 && vol_E > 0)
    D_TV = NaN;
    r_T = NaN;
    r_E = NaN;
    return;
end

G = -log(max(rand(p,M_MC),realmin));
a = G ./ repmat(sum(G,1),p,1);
r_T = mean(in_simplex(M_T*a,M_E));

G = -log(max(rand(p,M_MC),realmin));
a = G ./ repmat(sum(G,1),p,1);
r_E = mean(in_simplex(M_E*a,M_T));

vol_int = 0.5*(r_T*vol_T + r_E*vol_E);
D_TV = max(0,min(1,1-vol_int/max(vol_T,vol_E)));
end

function inside = in_simplex(X,M)
% Barycentric membership test, matching the registered H5/E2 estimator.
p = size(M,2);
E = M(:,2:p) - repmat(M(:,1),1,p-1);
c = E \ (X - repmat(M(:,1),1,size(X,2)));
inside = (min(c,[],1) >= -1e-8) & (sum(c,1) <= 1+1e-8);
inside = reshape(inside,1,[]);
end

%% =====================================================================
%                       COLLATION AND GATE CHECKS
% ======================================================================
function V = collate(rundir,C,S1,GRID,mode_hint)
T = read_run_table(rundir,C);

has_smoke = any(strcmp(T.phase,'smoke'));
has_grid = any(strcmp(T.phase,'grid'));

switch lower(mode_hint)
    case {'smoke','pregrid'}
        active_phases = {'smoke'};
    case 'grid'
        active_phases = {'smoke','grid'};
    otherwise
        active_phases = {};
        if has_smoke || has_grid
            active_phases{end+1} = 'smoke';
        end
        if has_grid
            active_phases{end+1} = 'grid';
        end
        if isempty(active_phases)
            active_phases = {'smoke'};
        end
end

expected = build_expected_runs(active_phases,C,S1,GRID);
[CS,missing] = summarize_runs(T,expected,C);

writetable(T,fullfile(C.OUTDIR,'h5v2_run_summary.csv'));
writetable(CS,fullfile(C.OUTDIR,'h5v2_cell_summary.csv'));
writetable(missing,fullfile(C.OUTDIR,'h5v2_missing_runs.csv'));

% ---------------- G0: complete smoke + canonical Table-S1 agreement ----
smoke_rows = CS(strcmp(CS.phase,'smoke') & strcmp(CS.arm,'snr30'),:);
[chk_smoke,worst0,slice_pass0] = slice_vs_S1(smoke_rows,S1,'smoke');
smoke_complete = phase_complete(CS,'smoke',9,1,C.NREP);

V = struct();
V.protocol_id = C.PROTOCOL_ID;
V.run_signature = C.RUN_SIGNATURE;
V.generated_at = datestr(now,31);
V.G0_smoke_complete = smoke_complete;
V.G0_tableS1_slice_pass = slice_pass0;
V.G0_canonical_settings = C.CANONICAL_SMOKE_SETTINGS;
V.G0_worst_abs_delta = worst0;
V.G0_smoke_pass = smoke_complete && slice_pass0 && C.CANONICAL_SMOKE_SETTINGS;

% ---------------- G1: completeness and zero failed runs ----------------
V.G1_smoke_complete = smoke_complete;
grid_present_or_requested = any(strcmp(active_phases,'grid'));
if grid_present_or_requested
    grid_complete = phase_complete(CS,'grid',numel(GRID.GAMMA_VOL)* ...
        numel(GRID.GAMMA_ENC),numel(GRID.ARMS),C.NREP);
else
    grid_complete = false;
end
V.G1_grid_complete = grid_complete;
if grid_present_or_requested
    V.G1_zero_failure = smoke_complete && grid_complete;
else
    V.G1_zero_failure = smoke_complete;
end

% ---------------- G2/G3: arm-specific phase-map diagnostics ------------
grid_rows = CS(strcmp(CS.phase,'grid'),:);
if ~isempty(grid_rows)
    arms = {'clean','snr30'};
    for ai = 1:numel(arms)
        arm = arms{ai};
        ar = grid_rows(strcmp(grid_rows.arm,arm),:);
        arm_complete = height(ar) == numel(GRID.GAMMA_VOL)*numel(GRID.GAMMA_ENC) && ...
            all(ar.n_ok == C.NREP & ar.n_failed == 0 & ar.n_missing == 0);

        % G2: count statistically supported shrinkage and over-expansion cells.
        shrink_mask = arm_complete & ...
            (ar.shrinkage_log_mean - ar.shrinkage_log_ci95 > 0);
        over_mask = arm_complete & ...
            (ar.shrinkage_log_mean + ar.shrinkage_log_ci95 < 0);
        n_shrink = sum(shrink_mask);
        n_over = sum(over_mask);
        discernible = arm_complete && n_shrink >= 3 && n_over >= 3;

        suffix = arm_field_suffix(arm);
        V.(['G2_' suffix '_complete']) = arm_complete;
        V.(['G2_' suffix '_n_shrink_cells']) = n_shrink;
        V.(['G2_' suffix '_n_over_cells']) = n_over;
        V.(['G2_' suffix '_zones_discernible']) = discernible;

        % G3: fit log(s), where s=V_est/V_true, on positive-shrinkage cells.
        % The fitted response is log_s_mean, not shrinkage_log_mean.
        pos_shrink = arm_complete & ...
            (ar.shrinkage_log_mean - ar.shrinkage_log_ci95 > 0);
        n_fit = sum(pos_shrink);
        V.(['G3_' suffix '_fit_available']) = n_fit >= 3;
        V.(['G3_' suffix '_n_fit_cells']) = n_fit;
        V.(['G3_' suffix '_s_definition']) = 's = V_est / V_true';
        V.(['G3_' suffix '_x_definition']) = ...
            '0.5 * (log(gamma_vol) - log(gamma_enc))';

        if n_fit >= 3
            xs = 0.5*(log(ar.gamma_vol(pos_shrink))-log(ar.gamma_enc(pos_shrink)));
            ys = ar.log_s_mean(pos_shrink);
            if rank([ones(numel(xs),1),xs]) == 2
                b = [ones(numel(xs),1),xs] \ ys;
                V.(['G3_' suffix '_intercept']) = b(1);
                V.(['G3_' suffix '_shape_slope']) = b(2);
                V.(['G3_' suffix '_theory_slope_reference']) = 1;
            else
                V.(['G3_' suffix '_shape_slope']) = NaN;
                V.(['G3_' suffix '_fit_available']) = false;
            end
        else
            V.(['G3_' suffix '_shape_slope']) = NaN;
            V.(['G3_' suffix '_theory_slope_reference']) = 1;
        end
    end

    % ---------------- G4: SNR30 grid slice vs published Table S1 --------
    grid_snr_rows = grid_rows(strcmp(grid_rows.arm,'snr30'),:);
    [chk_grid,worst4,slice_pass4] = slice_vs_S1(grid_snr_rows,S1,'grid');
    grid_complete_snr = phase_complete(CS(strcmp(CS.phase,'grid') & ...
        strcmp(CS.arm,'snr30'),:),'grid', ...
        numel(GRID.GAMMA_VOL)*numel(GRID.GAMMA_ENC),1,C.NREP);
    V.G4_grid_snr30_complete = grid_complete_snr;
    V.G4_tableS1_slice_pass = slice_pass4;
    V.G4_canonical_grid_settings = C.CANONICAL_GRID_SETTINGS;
    V.G4_worst_abs_delta = worst4;
    V.G4_tableS1_pass = grid_complete_snr && slice_pass4 && C.CANONICAL_GRID_SETTINGS;
else
    chk_grid = empty_s1_check_table();
    worst4 = NaN;
    V.G4_grid_snr30_complete = false;
    V.G4_tableS1_slice_pass = false;
    V.G4_canonical_grid_settings = C.CANONICAL_GRID_SETTINGS;
    V.G4_worst_abs_delta = worst4;
    V.G4_tableS1_pass = false;
end

% Combined Table-S1 check file: smoke and grid slices are labelled separately.
if isempty(chk_smoke)
    chk_all = chk_grid;
elseif isempty(chk_grid)
    chk_all = chk_smoke;
else
    chk_all = [chk_smoke;chk_grid];
end
writetable(chk_all,fullfile(C.OUTDIR,'h5v2_tableS1_check.csv'));

% Counts for auditability.
V.n_run_files = height(T);
V.n_expected_active = height(expected);
V.n_missing_active = height(missing);
V.n_failed_files = sum(~T.ok);
expected_all = build_expected_runs({'smoke','grid'},C,S1,GRID);
V.n_unexpected_files = sum(~ismember(T.tag,expected_all.tag));

write_verdict(V,C.OUTDIR);
fprintf('\n');
type(fullfile(C.OUTDIR,'h5v2_verdict.txt'));
end

function T = read_run_table(rundir,C)
files = dir(fullfile(rundir,'run_*.mat'));
rows = cell(0,1);
for i = 1:numel(files)
    f = fullfile(rundir,files(i).name);
    R = load(f);

    required = {'tag','phase','cell_tag','arm','gamma_vol','gamma_enc', ...
        'rep','iters','status','protocol_id','run_signature','TV','vol_T', ...
        'vol_E','volume_ratio','shrinkage_log','log_s','r_T','r_E', ...
        'enc_N','runtime_s','model_full_loss_total','model_full_loss_recon'};
    for j = 1:numel(required)
        if ~isfield(R,required{j})
            error('Checkpoint %s is missing field %s.',files(i).name,required{j});
        end
    end

    if ~strcmp(R.protocol_id,C.PROTOCOL_ID) || ~strcmp(R.run_signature,C.RUN_SIGNATURE)
        error(['Checkpoint %s does not match the current protocol/run signature. ' ...
            'Do not combine it with this experiment. Use a new OUTDIR.'],files(i).name);
    end

    ok = strcmp(R.status,'ok') && isfinite(R.TV) && isfinite(R.vol_T) && ...
        isfinite(R.vol_E) && isfinite(R.volume_ratio) && ...
        isfinite(R.shrinkage_log) && isfinite(R.log_s) && ...
        isfinite(R.enc_N) && isfinite(R.runtime_s) && ...
        isfinite(R.model_full_loss_total) && isfinite(R.model_full_loss_recon) && ...
        R.vol_T > 0 && R.vol_E > 0;

    q = struct();
    q.tag = R.tag;
    q.phase = R.phase;
    q.cell_tag = R.cell_tag;
    q.arm = R.arm;
    q.gamma_vol = R.gamma_vol;
    q.gamma_enc = R.gamma_enc;
    q.rep = R.rep;
    q.iters = R.iters;
    q.status = R.status;
    q.ok = logical(ok);
    q.TV = R.TV;
    q.vol_T = R.vol_T;
    q.vol_E = R.vol_E;
    q.volume_ratio = R.volume_ratio;
    q.shrinkage_log = R.shrinkage_log;
    q.log_s = R.log_s;
    q.r_T = R.r_T;
    q.r_E = R.r_E;
    q.enc_N = R.enc_N;
    q.runtime_s = R.runtime_s;
    q.model_full_loss_total = R.model_full_loss_total;
    q.model_full_loss_recon = R.model_full_loss_recon;
    q.failure = '';
    if isfield(R,'failure')
        q.failure = R.failure;
    end
    if ~ok && isempty(q.failure)
        q.failure = 'Run status/metrics are not valid.';
    end
    rows{end+1,1} = q; %#ok<AGROW>
end

if isempty(rows)
    T = empty_run_table();
else
    T = struct2table(vertcat(rows{:}));
end
end

function T = empty_run_table()
T = table(cell(0,1),cell(0,1),cell(0,1),cell(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    cell(0,1),false(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),cell(0,1), ...
    'VariableNames',{'tag','phase','cell_tag','arm','gamma_vol','gamma_enc', ...
    'rep','iters','status','ok','TV','vol_T','vol_E','volume_ratio', ...
    'shrinkage_log','log_s','r_T','r_E','enc_N','runtime_s', ...
    'model_full_loss_total','model_full_loss_recon','failure'});
end

function expected = build_expected_runs(phases,C,S1,GRID)
rows = cell(0,1);
for pi = 1:numel(phases)
    phase = phases{pi};
    if strcmp(phase,'smoke')
        cells = smoke_cells(S1);
        arms = {'snr30'};
        iters = C.ITERS_SMOKE;
    else
        cells = grid_cells(GRID);
        arms = GRID.ARMS;
        iters = C.ITERS_GRID;
    end

    for ci = 1:numel(cells)
        for ai = 1:numel(arms)
            for rep = 1:C.NREP
                q = struct();
                q.tag = sprintf('%s_%s_rep%02d',cells(ci).tag,arms{ai},rep);
                q.phase = phase;
                q.cell_tag = cells(ci).tag;
                q.arm = arms{ai};
                q.gamma_vol = cells(ci).gamma_vol;
                q.gamma_enc = cells(ci).gamma_enc;
                q.rep = rep;
                q.iters = iters;
                rows{end+1,1} = q; %#ok<AGROW>
            end
        end
    end
end
if isempty(rows)
    expected = table(cell(0,1),cell(0,1),cell(0,1),cell(0,1), ...
        zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
        'VariableNames',{'tag','phase','cell_tag','arm','gamma_vol', ...
        'gamma_enc','rep','iters'});
else
    expected = struct2table(vertcat(rows{:}));
end
end

function [CS,missing] = summarize_runs(T,expected,C)
if isempty(expected)
    CS = table();
    missing = expected;
    return;
end

missing_mask = ~ismember(expected.tag,T.tag);
missing = expected(missing_mask,:);

rows = cell(0,1);
seen = {};
for i = 1:height(expected)
    key = [expected.phase{i} '|' expected.cell_tag{i} '|' expected.arm{i}];
    if any(strcmp(seen,key))
        continue;
    end
    seen{end+1} = key; %#ok<AGROW>

    m = strcmp(expected.phase,expected.phase{i}) & ...
        strcmp(expected.cell_tag,expected.cell_tag{i}) & ...
        strcmp(expected.arm,expected.arm{i});
    ex = expected(m,:);
    act = T(ismember(T.tag,ex.tag),:);
    good = act(act.ok,:);

    q = struct();
    q.phase = expected.phase{i};
    q.cell_tag = expected.cell_tag{i};
    q.arm = expected.arm{i};
    q.gamma_vol = expected.gamma_vol(i);
    q.gamma_enc = expected.gamma_enc(i);
    q.n_expected = height(ex);
    q.n_actual = height(act);
    q.n_ok = height(good);
    q.n_failed = sum(~act.ok);
    q.n_missing = max(0,q.n_expected-q.n_actual);
    q.TV_mean = safe_mean(good.TV);
    q.TV_std = safe_std(good.TV);
    q.TV_ci95 = ci95_halfwidth(q.TV_std,q.n_ok,C.NREP);
    q.volume_ratio_mean = safe_mean(good.volume_ratio);
    q.volume_ratio_std = safe_std(good.volume_ratio);
    q.shrinkage_log_mean = safe_mean(good.shrinkage_log);
    q.shrinkage_log_std = safe_std(good.shrinkage_log);
    q.shrinkage_log_ci95 = ci95_halfwidth(q.shrinkage_log_std,q.n_ok,C.NREP);
    q.log_s_mean = safe_mean(good.log_s);
    q.log_s_std = safe_std(good.log_s);
    q.log_s_ci95 = ci95_halfwidth(q.log_s_std,q.n_ok,C.NREP);
    q.enc_N_mean = safe_mean(good.enc_N);
    q.runtime_mean_s = safe_mean(good.runtime_s);
    rows{end+1,1} = q; %#ok<AGROW>
end
CS = struct2table(vertcat(rows{:}));
end

function m = safe_mean(x)
x = x(isfinite(x));
if isempty(x)
    m = NaN;
else
    m = mean(x);
end
end

function s = safe_std(x)
x = x(isfinite(x));
if numel(x) < 2
    s = NaN;
else
    s = std(x,0);
end
end

function h = ci95_halfwidth(sd,n_ok,n_expected)
% The registered 20-repeat Student-t half-width is approximately 0.47*SD.
% Do not report a CI for an incomplete cell.
if n_ok == n_expected && n_ok == 20 && isfinite(sd)
    h = 0.47*sd;
else
    h = NaN;
end
end

function tf = phase_complete(CS,phase,n_cells,n_arms,nrep)
R = CS(strcmp(CS.phase,phase),:);
tf = height(R) == n_cells*n_arms && ...
    all(R.n_expected == nrep & R.n_ok == nrep & ...
        R.n_failed == 0 & R.n_missing == 0);
end

function [chk,worst,allpass] = slice_vs_S1(rows,S1,phase)
% All nine required points are explicitly checked. Empty/missing/partial
% points fail; an empty input can never pass by default.
point_names = {};
gv_values = [];
ge_values = [];
ref_values = [];
ref_sd_values = [];

point_names{end+1} = 'default';
gv_values(end+1) = S1.DEFAULT.gamma_vol;
ge_values(end+1) = S1.DEFAULT.gamma_enc;
ref_values(end+1) = 0.43;
ref_sd_values(end+1) = 0.13;

for i = 1:numel(S1.GV_LEVELS)
    gv = S1.GV_LEVELS(i);
    if abs(gv-S1.DEFAULT.gamma_vol) < 1e-12
        continue;
    end
    point_names{end+1} = sprintf('gamma_vol=%g',gv);
    gv_values(end+1) = gv;
    ge_values(end+1) = S1.DEFAULT.gamma_enc;
    ref_values(end+1) = S1.GV_TV(i);
    ref_sd_values(end+1) = S1.GV_SD(i);
end

for i = 1:numel(S1.GE_LEVELS)
    ge = S1.GE_LEVELS(i);
    if abs(ge-S1.DEFAULT.gamma_enc) < 1e-12
        continue;
    end
    point_names{end+1} = sprintf('gamma_enc=%g',ge);
    gv_values(end+1) = S1.DEFAULT.gamma_vol;
    ge_values(end+1) = ge;
    ref_values(end+1) = S1.GE_TV(i);
    ref_sd_values(end+1) = S1.GE_SD(i);
end

out = cell(0,1);
allpass = true;
worst = NaN;

for i = 1:numel(point_names)
    ix = find(abs(rows.gamma_vol-gv_values(i)) < 1e-12 & ...
        abs(rows.gamma_enc-ge_values(i)) < 1e-12,1);

    n_ok = 0; n_expected = S1.NREP; n_failed = 0; n_missing = n_expected;
    tv_mean = NaN; tv_std = NaN;
    if ~isempty(ix)
        n_ok = rows.n_ok(ix);
        n_expected = rows.n_expected(ix);
        n_failed = rows.n_failed(ix);
        n_missing = rows.n_missing(ix);
        tv_mean = rows.TV_mean(ix);
        tv_std = rows.TV_std(ix);
    end

    complete = n_expected == S1.NREP && n_ok == S1.NREP && ...
        n_failed == 0 && n_missing == 0 && isfinite(tv_mean) && isfinite(tv_std);
    if complete
        sem_new = tv_std/sqrt(n_ok);
        tol = 2*sqrt(sem_new^2 + (ref_sd_values(i)/sqrt(S1.NREP))^2);
        abs_diff = abs(tv_mean-ref_values(i));
        pass = abs_diff <= tol;
        if isnan(worst)
            worst = abs_diff;
        else
            worst = max(worst,abs_diff);
        end
    else
        tol = NaN;
        abs_diff = NaN;
        pass = false;
    end

    if ~pass
        allpass = false;
    end

    q = struct();
    q.phase = phase;
    q.point = point_names{i};
    q.gamma_vol = gv_values(i);
    q.gamma_enc = ge_values(i);
    q.n_ok = n_ok;
    q.n_expected = n_expected;
    q.n_failed = n_failed;
    q.n_missing = n_missing;
    q.H5v2_TV = tv_mean;
    q.TableS1_TV = ref_values(i);
    q.abs_diff = abs_diff;
    q.tolerance = tol;
    q.PASS = logical(pass);
    out{end+1,1} = q; %#ok<AGROW>
end

chk = struct2table(vertcat(out{:}));
end

function T = empty_s1_check_table()
T = table(cell(0,1),cell(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),false(0,1), ...
    'VariableNames',{'phase','point','gamma_vol','gamma_enc','n_ok', ...
    'n_expected','n_failed','n_missing','H5v2_TV','TableS1_TV', ...
    'abs_diff','tolerance','PASS'});
end

function suffix = arm_field_suffix(arm)
if strcmp(arm,'snr30')
    suffix = 'snr30';
else
    suffix = 'clean';
end
end

function write_verdict(V,outdir)
fid = fopen(fullfile(outdir,'h5v2_verdict.txt'),'w');
if fid < 0
    error('Could not create h5v2_verdict.txt in %s.',outdir);
end

fprintf(fid,'=== H5-v2 formal verdict ===\n');
fprintf(fid,'Generated: %s\n',V.generated_at);
fprintf(fid,'Protocol: %s\n',V.protocol_id);
fprintf(fid,'\nG0: smoke protocol alignment\n');
fprintf(fid,'  complete all smoke runs: %d\n',V.G0_smoke_complete);
fprintf(fid,'  all nine Table-S1 points pass: %d\n',V.G0_tableS1_slice_pass);
fprintf(fid,'  canonical smoke settings: %d\n',V.G0_canonical_settings);
fprintf(fid,'  worst absolute TV difference: %.6f\n',V.G0_worst_abs_delta);
fprintf(fid,'  G0 overall: %d\n',V.G0_smoke_pass);

fprintf(fid,'\nG1: run completeness\n');
fprintf(fid,'  smoke complete with zero failures: %d\n',V.G1_smoke_complete);
fprintf(fid,'  grid complete with zero failures: %d\n',V.G1_grid_complete);
fprintf(fid,'  G1 overall: %d\n',V.G1_zero_failure);

if isfield(V,'G2_clean_complete')
    fprintf(fid,'\nG2: phase-map zones\n');
    fprintf(fid,'  clean: complete=%d, shrink cells=%d, over-expansion cells=%d, discernible=%d\n', ...
        V.G2_clean_complete,V.G2_clean_n_shrink_cells,V.G2_clean_n_over_cells, ...
        V.G2_clean_zones_discernible);
    fprintf(fid,'  snr30: complete=%d, shrink cells=%d, over-expansion cells=%d, discernible=%d\n', ...
        V.G2_snr30_complete,V.G2_snr30_n_shrink_cells,V.G2_snr30_n_over_cells, ...
        V.G2_snr30_zones_discernible);

    fprintf(fid,'\nG3: theoretical-shape diagnostic\n');
    fprintf(fid,'  definition: s = V_est / V_true; response = log(s)\n');
    fprintf(fid,'  x = 0.5*(log(gamma_vol)-log(gamma_enc)); reference slope = 1\n');
    fprintf(fid,'  clean: fit_available=%d, n_cells=%d, slope=%.6f\n', ...
        V.G3_clean_fit_available,V.G3_clean_n_fit_cells,V.G3_clean_shape_slope);
    fprintf(fid,'  snr30: fit_available=%d, n_cells=%d, slope=%.6f\n', ...
        V.G3_snr30_fit_available,V.G3_snr30_n_fit_cells,V.G3_snr30_shape_slope);

    fprintf(fid,'\nG4: Table-S1 consistency on the grid SNR30 slice\n');
    fprintf(fid,'  grid SNR30 complete: %d\n',V.G4_grid_snr30_complete);
    fprintf(fid,'  all nine Table-S1 points pass: %d\n',V.G4_tableS1_slice_pass);
    fprintf(fid,'  canonical grid settings: %d\n',V.G4_canonical_grid_settings);
    fprintf(fid,'  worst absolute TV difference: %.6f\n',V.G4_worst_abs_delta);
    fprintf(fid,'  G4 overall: %d\n',V.G4_tableS1_pass);
end

fprintf(fid,'\nFile counts\n');
fprintf(fid,'  run files: %d\n',V.n_run_files);
fprintf(fid,'  expected active runs: %d\n',V.n_expected_active);
fprintf(fid,'  missing active runs: %d\n',V.n_missing_active);
fprintf(fid,'  failed/invalid run files: %d\n',V.n_failed_files);
fprintf(fid,'  unexpected run files: %d\n',V.n_unexpected_files);

fprintf(fid,'\nInterpretation note\n');
fprintf(fid,['A completed run is not automatically an accepted experiment. ' ...
    'G0 requires complete smoke data and Table-S1 agreement. ' ...
    'G1 checks completeness/failures. G2-G4 are evaluated only from ' ...
    'the completed grid and are reported separately for clean and SNR30.\n']);
fclose(fid);

save(fullfile(outdir,'h5v2_verdict.mat'),'V','-v7');
end
