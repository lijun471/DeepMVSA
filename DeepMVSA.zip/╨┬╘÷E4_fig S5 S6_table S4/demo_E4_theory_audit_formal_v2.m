%% FORMAL DEEPMVSA E4: THEORY-CONDITION / CERTIFICATE AUDIT
% v127 E4 design; data/seed/metrics/incremental-save style based on supplied E2.
% Requires deep_mvsa_invflow_E4.m and VCA.m on the MATLAB path.
% Synthetic mode (DEFAULT) does not require USGS or spectMixGen.
% Optional E2-matched USGS mode requires USGS_1995_Library.mat + spectMixGen.m.
%
% Reports seven rows:
% C1-C3: exact observed geometric envelope conditions;
% C4-C5: finite-part Prop 3.2(i) PLUG-IN diagnostics, NOT certificates;
% C6: observed transfer enclosure threshold (epsilon = empirical TV);
% C7: A-Net realised witness <= approximation threshold (sufficient witness).
% C4/C5 omit unknown O_p remainders and true eta_opt; never claim proofs.
% Adam-versus-oracle objective gap is a signed comparison, NOT eta_opt.
%
% E4 evaluates the E2 *reported* projected vertices for geometry; if
% the model's internal Q has affine drift, Prop conditions remain proxy audits.
% Adam branch retains ORIGINAL E2 training loss (sample-sum penalties)
% and E2 warm-up behavior. The theory audit computes mean enc_N separately.
% Fix: summary masks use column vectors to prevent implicit expansion.
% Outputs: ONE incrementally updated results MAT, per-run/condition CSV,
% Figure G/H PNG and genuinely editable MATLAB-generated SVG.
%
% Pilot: set cfg.FAST_TEST=true. Formal 27 cells x 20 repeats = 540 runs.
clear; close all; clc;

%% CONFIGURATION
cfg = struct();
cfg.FAST_TEST = false;                  % true: minimal end-to-end smoke test
cfg.DATA_MODE = 'synthetic';            % 'synthetic' (v127) or 'usgs' (E2-like)
cfg.K_LIST = [3,5,7];                  % simplex dimension; p=K+1 vertices
cfg.N_LIST = [10000,100000,1000000];
cfg.SNR_LIST = [Inf,30,20];
cfg.REPEATS = 20;
cfg.STEPS = 1500;
cfg.WARM_UP = 600;
cfg.ORACLE_STEPS = 1500;             % A-Net only, Q fixed at M_true_work
cfg.HIDDEN = 32;
cfg.BATCH_SIZE = 4096;
cfg.LR = 1e-3;
cfg.LAMBDA_VOL = 0.01;
cfg.LAMBDA_ENCLOSE = 10;
cfg.LAMBDA_SUMONE = 2;
cfg.LAMBDA_NONNEG = 5;
cfg.LAMBDA_EQ = 80;
cfg.TV_MC = 100000;                 % E2/Table-2 estimator budget
cfg.TV_CHUNK = 10000;
cfg.EPS_MIN = 1e-8;
cfg.C2 = 1;
cfg.DATA_SEED_BASE = 41000;
cfg.TRAIN_SEED_BASE = 71000;
cfg.ORACLE_SEED_BASE = 91000;
cfg.TV_SEED_BASE = 810000;
cfg.RESUME = true;
cfg.FIG_VISIBLE = 'off';
cfg.PRINT_EVERY = 1;
cfg.OUTPUT_DIR = fullfile(pwd,'E4_formal_outputs_E2loss');  % separate from old mean-normalized run
cfg.SHAPE_PARAMETER = 1;
cfg.MAX_PURITY = 1.0;
cfg.SAVE_EVERY_RUNS = 1;               % update same MAT after every completed/failed run
cfg.THEORY_NORMALIZED = false;         % retain original E2 Adam objective and warm-up

if cfg.FAST_TEST
    cfg.K_LIST = 3; cfg.N_LIST = 10000; cfg.SNR_LIST = Inf;
    cfg.REPEATS = 1; cfg.STEPS = 40; cfg.WARM_UP = 15;
    cfg.ORACLE_STEPS = 40; cfg.TV_MC = 3000; cfg.TV_CHUNK = 1000;
    cfg.OUTPUT_DIR = fullfile(pwd,'E4_fast_test_outputs');
end
assert(cfg.STEPS > cfg.WARM_UP && cfg.ORACLE_STEPS > 0);
assert(exist('deep_mvsa_invflow_E4','file') == 2,'deep_mvsa_invflow_E4.m not on path.');
assert(exist('VCA','file') == 2,'VCA.m not on path.');
if ~exist(cfg.OUTPUT_DIR,'dir'), mkdir(cfg.OUTPUT_DIR); end

if strcmpi(cfg.DATA_MODE,'usgs')
    if exist('USGS_1995_Library.mat','file')
        tmp = load('USGS_1995_Library.mat','datalib');
    else
        error('USGS_1995_Library.mat required in usgs mode.');
    end
    datalib_all = double(tmp.datalib);
    assert(exist('spectMixGen','file') == 2,'spectMixGen.m is required for usgs mode.');
else
    assert(strcmpi(cfg.DATA_MODE,'synthetic'),'DATA_MODE must be synthetic or usgs.');
    datalib_all = [];
end

condNames = {'C1_volume_envelope','C2_diameter_envelope', ...
    'C3_vertex_envelope','C4_prop_enc_finite_proxy', ...
    'C5_prop_vol_finite_proxy','C6_transfer_enc', ...
    'C7_transfer_apx_witness'};
nRuns = numel(cfg.K_LIST)*numel(cfg.N_LIST)*numel(cfg.SNR_LIST)*cfg.REPEATS;
resultsFile = fullfile(cfg.OUTPUT_DIR,'E4_formal_results.mat');
runs = repmat(e4_blank_run(),nRuns,1);
if cfg.RESUME && exist(resultsFile,'file')
    old = load(resultsFile,'cfg','runs');
    if isequaln(e4_signature(old.cfg),e4_signature(cfg)) && numel(old.runs)==nRuns
        runs = old.runs;
        fprintf('Resuming from E4_formal_results.mat: %d/%d completed.\n', ...
            sum(strcmp({runs.status},'done')),nRuns);
    else
        error(['Existing results MAT has a different configuration. ' ...
            'Move/delete it or use a different OUTPUT_DIR.']);
    end
end
fprintf('E4: %d runs | K=%s N=%s SNR=%s | repeats=%d | oracle=%d\n', ...
    nRuns,mat2str(cfg.K_LIST),mat2str(cfg.N_LIST), ...
    mat2str(cfg.SNR_LIST),cfg.REPEATS,cfg.ORACLE_STEPS);

%% EXPERIMENT GRID (paired noise arms within each K, N, repeat)
runIndex = 0;
for ik = 1:numel(cfg.K_LIST)
    K = cfg.K_LIST(ik); p = K+1;
    for iN = 1:numel(cfg.N_LIST)
        N = cfg.N_LIST(iN);
        for rep = 1:cfg.REPEATS
            % Skip entire paired trio if all SNR arms were already saved.
            % This lets a completed 540-run MAT go straight to CSV/figures
            % without regenerating 1e6-sample synthetic datasets.
            firstIdx = ((ik-1)*numel(cfg.N_LIST) + (iN-1)) * ...
                cfg.REPEATS*numel(cfg.SNR_LIST) + ...
                (rep-1)*numel(cfg.SNR_LIST) + 1;
            groupIds = firstIdx:(firstIdx+numel(cfg.SNR_LIST)-1);
            if all(strcmp({runs(groupIds).status},'done'))
                runIndex = runIndex + numel(cfg.SNR_LIST);
                continue;
            end

            dataSeed = cfg.DATA_SEED_BASE + 100000*K + 1000*iN + rep;
            rng(dataSeed,'twister');
            if strcmpi(cfg.DATA_MODE,'synthetic')
                % Synthetic orthonormal vertices; nonzero affine centroid.
                [M_true,~] = qr(randn(p,p),0);
                G = -log(max(rand(p,N),realmin));
                A_true = G./sum(G,1);
                Y_clean = M_true*A_true;
                selectedMaterials = '';
                clear G A_true
            else
                nMaterials = size(datalib_all,2);
                assert(nMaterials>=p+4,'Not enough USGS materials for p=%d.',p);
                materialOrder = 4+randperm(nMaterials-4);
                selected = materialOrder(1:p);
                selectedMaterials = mat2str(selected);
                M_true = datalib_all(:,selected);
                [Y_clean,A_true,~] = spectMixGen(M_true,N, ...
                    'Source_pdf','Diri_id','pdf_pars',cfg.SHAPE_PARAMETER, ...
                    'max_purity',cfg.MAX_PURITY*ones(1,p), ...
                    'no_outliers',0,'violation_extremes',[1 1.2], ...
                    'snr',Inf,'noise_shape','uniform');
                Y_clean = double(Y_clean);
                clear A_true
            end
            % Fix the noise realisation for all three arms in a given repeat.
            E = randn(size(Y_clean));
            E = E*norm(Y_clean,'fro')/max(norm(E,'fro'),realmin);
            for ia = 1:numel(cfg.SNR_LIST)
                runIndex = runIndex+1;
                if strcmp(runs(runIndex).status,'done'), continue; end
                snrDb = cfg.SNR_LIST(ia);
                if isinf(snrDb)
                    Y = Y_clean; measuredSNR = Inf;
                else
                    Y = Y_clean + E*10^(-snrDb/20);
                    measuredSNR = 10*log10(norm(Y_clean,'fro')^2/ ...
                        max(norm(Y-Y_clean,'fro')^2,realmin));
                end
                % Same training/oracle RNG streams across SNR arms within each repeat.
                trainSeed = cfg.TRAIN_SEED_BASE + 100000*K + 1000*iN + 10*rep;
                oracleSeed = cfg.ORACLE_SEED_BASE + 100000*K + 1000*iN + 10*rep;
                tvSeed = cfg.TV_SEED_BASE + 100000*K + 1000*iN + rep;
                tStart = tic;
                try
                    % Adam, standard trainable Q-flow, base->joint training.
                    [M_est,A_adam,Up,my,~,~,e4info] = deep_mvsa_invflow_E4(Y,p, ...
                        'MM_ITERS',cfg.STEPS,'WARM_UP',cfg.WARM_UP, ...
                        'LR',cfg.LR,'BATCH_SIZE',cfg.BATCH_SIZE, ...
                        'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
                        'LAMBDA_VOL',cfg.LAMBDA_VOL, ...
                        'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE, ...
                        'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
                        'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
                        'LAMBDA_EQ',cfg.LAMBDA_EQ, ...
                        'spherize','yes','SEED',trainSeed, ...
                        'E4_THEORY_NORMALIZATION',cfg.THEORY_NORMALIZED, ...
                        'E1_MONITOR_INTERVAL',0,'verbose',0);
                    % Use EXACTLY Adam's whitening map for all audit quantities.
                    Yw = e4_to_work(Y,Up,my,e4info.D,e4info.lambda_reg,p);
                    MTw = e4_to_work(M_true,Up,my,e4info.D,e4info.lambda_reg,p);
                    % Reconstruct the reported simplex using E2's recovered
                    % ambient endmembers. Model internal Q can depart from
                    % the homogeneous affine hyperplane; record its drift.
                    MEw = e4_to_work(M_est,Up,my,e4info.D,e4info.lambda_reg,p);
                    Mmodel = e4info.M_work;
                    affineDrift = max(abs(Mmodel(p,:)-1/sqrt(p)));
                    qw = e4info.qm;
                    if any(~isfinite(MEw(:))) || rcond(MEw) < 1e-12
                        error('Estimated working simplex is numerically singular.');
                    end
                    riskAdam = e4_full_risk(Yw,Mmodel,A_adam,qw,MTw,cfg);
                    clear A_adam M_est

                    % Independent oracle: Q fixed at true simplex; train only
                    % the A-Net base branch (nonlinear gate OFF).
                    [~,A_oracle,~,~,~,~,infoOrc] = deep_mvsa_invflow_E4(Y,p, ...
                        'MM_ITERS',cfg.ORACLE_STEPS,'WARM_UP',0, ...
                        'LR',cfg.LR,'BATCH_SIZE',cfg.BATCH_SIZE, ...
                        'HIDDEN',cfg.HIDDEN,'COORD_MODE','index', ...
                        'LAMBDA_VOL',cfg.LAMBDA_VOL, ...
                        'LAMBDA_ENCLOSE',cfg.LAMBDA_ENCLOSE, ...
                        'LAMBDA_NONNEG',cfg.LAMBDA_NONNEG, ...
                        'LAMBDA_SUMONE',cfg.LAMBDA_SUMONE, ...
                        'LAMBDA_EQ',cfg.LAMBDA_EQ, ...
                        'spherize','yes','SEED',oracleSeed, ...
                        'E4_FIXED_M_TRUE',M_true, ...
                        'E4_ORACLE_BASE_ONLY',true, ...
                        'E4_THEORY_NORMALIZATION',cfg.THEORY_NORMALIZED, ...
                        'E1_MONITOR_INTERVAL',0,'verbose',0);
                    % A oracle may have been trained in an equivalent (sign-
                    % flipped) SVD basis. Risk is evaluated in Adam's basis.
                    riskOrc = e4_full_risk(Yw,MTw,A_oracle,qw,MTw,cfg);
                    etaApxWitness = riskOrc.recon;
                    clear A_oracle infoOrc

                    [tv,Vtrue,Vest] = e4_tv_dist_simplex( ...
                        MTw,MEw,cfg.TV_MC,tvSeed,cfg.TV_CHUNK);
                    DT = e4_diameter(MTw);
                    DE = e4_diameter(MEw);
                    vertexDist = e4_max_vertex_dist_to_simplex(MEw,MTw);
                    encN = e4_enclosure_squared_mean(Yw,MEw,cfg.TV_CHUNK);
                    Qtrue = inv(MTw);
                    [permIsIdentity,minPivot,leadingMin] = e4_lu_audit(Qtrue);
                    kapT = K*Vtrue/(4*(K+1)*(2*DT)^(K-1));
                    epsTV = max(tv,cfg.EPS_MIN);
                    cbar3 = cfg.LAMBDA_VOL/4;
                    b = (K/epsTV)*max(1,2/max(kapT,realmin));
                    c4 = 2*DT;

                    % Prop 3.2(i), FINITE-TERM PLUG-IN comparisons ONLY.
                    % True eta_opt and O_p remainder terms are unknown.
                    pEncRHS = (cfg.C2*etaApxWitness + ...
                        cfg.LAMBDA_VOL*max(log(Vtrue/Vest),0)) /cfg.LAMBDA_ENCLOSE;
                    pVolLogRHS = cfg.C2*etaApxWitness/cfg.LAMBDA_VOL;
                    pVolRHS = exp(min(pVolLogRHS,700));
                    transferEncRHS = cbar3^2 * epsTV^2 / (16*b^2*c4^2);
                    transferApxRHS = cbar3*epsTV/(8*cfg.C2);
                    volRatio = Vest/Vtrue;
                    oracleGap = riskAdam.total - riskOrc.total;

                    r = e4_blank_run();
                    r.status='done'; r.run_id=runIndex;
                    r.K=K; r.p=p; r.N=N; r.repeat=rep; r.snr_db=snrDb;
                    r.data_seed=dataSeed; r.train_seed=trainSeed;
                    r.oracle_seed=oracleSeed; r.tv_seed=tvSeed;
                    r.material_indices=selectedMaterials;
                    r.measured_snr_db=measuredSNR;
                    r.tv=tv; r.vol_true=Vtrue; r.vol_est=Vest; r.vol_ratio=volRatio;
                    r.D_true=DT; r.D_est=DE; r.max_vertex_dist=vertexDist;
                    r.enc_N=encN; r.eta_apx_witness=etaApxWitness; r.model_affine_drift=affineDrift;
                    r.kappa_true=kapT; r.b=b; r.cbar3=cbar3;
                    r.epsilon_selfconsistent=epsTV;
                    r.prop_enc_rhs_finite=pEncRHS;
                    r.prop_vol_rhs_finite=pVolRHS;
                    r.prop_vol_log_rhs=pVolLogRHS;
                    r.transfer_enc_rhs=transferEncRHS;
                    r.transfer_apx_rhs=transferApxRHS;
                    r.risk_adam=riskAdam.total;
                    r.risk_oracle=riskOrc.total;
                    r.risk_oracle_gap_signed=oracleGap;
                    r.risk_adam_recon=riskAdam.recon;
                    r.risk_oracle_recon=riskOrc.recon;
                    r.risk_adam_enclose=riskAdam.enclose;
                    r.risk_oracle_enclose=riskOrc.enclose;
                    r.oracle_lu_perm_identity=double(permIsIdentity);
                    r.oracle_lu_min_abs_pivot=minPivot;
                    r.oracle_min_abs_leading_minor=leadingMin;
                    r.C1=double(volRatio>=0.25 && volRatio<=2);
                    r.C2=double(DE<=2*DT);
                    r.C3=double(vertexDist<=2*DT);
                    r.C4=double(encN<=pEncRHS);
                    r.C5=double(log(volRatio)<=pVolLogRHS);
                    r.C6=double(encN<=transferEncRHS);
                    r.C7=double(etaApxWitness<=transferApxRHS);
                    if ~(isfinite(tv) && tv>cfg.EPS_MIN)
                        % epsilon=measured TV is undefined/degenerated at TV~0.
                        r.C6=NaN; r.C7=NaN;
                    end
                    r.C1_margin_lower=volRatio-0.25;
                    r.C1_margin_upper=2-volRatio;
                    r.C2_margin=2*DT-DE;
                    r.C3_margin=2*DT-vertexDist;
                    r.C4_margin=pEncRHS-encN;
                    r.C5_log_margin=pVolLogRHS-log(volRatio);
                    r.C6_margin=transferEncRHS-encN;
                    r.C7_margin=transferApxRHS-etaApxWitness;
                    r.M_true_work=MTw;
                    r.M_est_work=MEw;
                    r.M_model_work=Mmodel;
                    r.Q_model_work=e4info.Q_work;
                    r.wall_clock_s=toc(tStart);
                    runs(runIndex)=r;
                    if mod(runIndex,cfg.PRINT_EVERY)==0 || runIndex==nRuns
                        fprintf('E4 %3d/%3d K=%d N=%d SNR=%g rep=%d TV=%.4g enc=%.3g C=[%s] %.1fs\n', ...
                            runIndex,nRuns,K,N,snrDb,rep,tv,encN, ...
                            sprintf('%d', [r.C1,r.C2,r.C3,r.C4,r.C5,r.C6,r.C7]),r.wall_clock_s);
                    end
                catch ME
                    r=e4_blank_run(); r.status='failed'; r.run_id=runIndex;
                    r.K=K; r.p=p; r.N=N; r.repeat=rep; r.snr_db=snrDb;
                    r.data_seed=dataSeed; r.train_seed=trainSeed;
                    r.error_message=ME.message;
                    r.wall_clock_s=toc(tStart); runs(runIndex)=r;
                    warning('E4 run %d failed: %s',runIndex,ME.message);
                end
                if mod(runIndex,cfg.SAVE_EVERY_RUNS)==0 || runIndex==nRuns
                    e4_save_single_mat(resultsFile,cfg,runs,runIndex,condNames);
                end
                clear Y Yw MTw MEw e4info
            end
            clear Y_clean E M_true
        end
    end
end
e4_save_single_mat(resultsFile,cfg,runs,runIndex,condNames);

%% RESULT TABLES (compact MAT: no N-column arrays)
Tcsv=struct2table(rmfield(runs,{'M_true_work','M_est_work', ...
    'M_model_work','Q_model_work'}));
T=Tcsv;
writetable(Tcsv,fullfile(cfg.OUTPUT_DIR,'E4_run_summary.csv'));

% One row per (K,N,SNR,condition) with exact k/n and Wilson 95% CI.
summaryRows=struct('K',{},'N',{},'snr_db',{},'condition',{}, ...
    'n_valid',{},'n_pass',{},'rate',{},'ci_lower',{},'ci_upper',{});
for ik=1:numel(cfg.K_LIST)
    for iN=1:numel(cfg.N_LIST)
        for ia=1:numel(cfg.SNR_LIST)
            % Force every operand to a COLUMN.  [runs.K] is 1-by-nRuns,
            % while arrayfun(...,runs) inherits runs' nRuns-by-1 shape;
            % combining them without reshaping broadcasts to nRuns-by-nRuns
            % and may create TRUE values beyond the runs array bounds.
            kVec = reshape([runs.K],[],1);
            nVec = reshape([runs.N],[],1);
            snrVec = reshape([runs.snr_db],[],1);
            doneVec = reshape(strcmp({runs.status},'done'),[],1);
            idx = (kVec==cfg.K_LIST(ik)) & ...
                (nVec==cfg.N_LIST(iN)) & ...
                (snrVec==cfg.SNR_LIST(ia)) & doneVec;
            assert(numel(idx)==numel(runs), 'E4 result-index size mismatch.');
            chosen=runs(idx);
            for ic=1:numel(condNames)
                key=sprintf('C%d',ic);
                vals=[chosen.(key)]; vals=vals(isfinite(vals));
                k=sum(vals>0.5); n=numel(vals);
                [rate,lo,hi]=e4_wilson(k,n);
                summaryRows(end+1)=struct('K',cfg.K_LIST(ik), ...
                    'N',cfg.N_LIST(iN),'snr_db',cfg.SNR_LIST(ia), ...
                    'condition',condNames{ic},'n_valid',n,'n_pass',k, ...
                    'rate',rate,'ci_lower',lo,'ci_upper',hi); %#ok<SAGROW>
            end
        end
    end
end
summary=struct2table(summaryRows);
writetable(summary,fullfile(cfg.OUTPUT_DIR,'E4_condition_summary.csv'));
e4_save_single_mat(resultsFile,cfg,runs,runIndex,condNames,Tcsv,summary);

%% FIGURE G: 7 conditions x 9 (K,N) cells per SNR; rates and Wilson CIs
figG=figure('Visible',cfg.FIG_VISIBLE,'Color','w', ...
    'Position',[60 60 2250 1500]);
for ia=1:numel(cfg.SNR_LIST)
    ax=subplot(numel(cfg.SNR_LIST),1,ia); %#ok<LAXES>
    nCells=numel(cfg.K_LIST)*numel(cfg.N_LIST);
    rates=nan(numel(condNames),nCells);
    labs=cell(1,nCells); idx=0;
    for ik=1:numel(cfg.K_LIST)
        for iN=1:numel(cfg.N_LIST)
            idx=idx+1;
            labs{idx}=sprintf('K=%d / N=%g',cfg.K_LIST(ik),cfg.N_LIST(iN));
            for ic=1:numel(condNames)
                isRow=summary.K==cfg.K_LIST(ik) & summary.N==cfg.N_LIST(iN) & ...
                    arrayfun(@(x) isequaln(x,cfg.SNR_LIST(ia)),summary.snr_db) & ...
                    strcmp(summary.condition,condNames{ic});
                rr=summary(isRow,:);
                if height(rr)==1 && rr.n_valid>0, rates(ic,idx)=rr.rate; end
            end
        end
    end
    imagesc(ax,rates,[0,1]); colormap(ax,parula(256));
    set(ax,'YTick',1:numel(condNames),'YTickLabel',condNames, ...
        'XTick',1:nCells,'XTickLabel',labs,'FontSize',12, ...
        'XTickLabelRotation',0,'TickLength',[0 0]);
    xlim(ax,[0.5 nCells+0.5]); ylim(ax,[0.5 numel(condNames)+0.5]);
    xlabel(ax,'(K, N)');
    title(ax,sprintf('E4 Figure G | SNR=%g dB | pass rate (k/n, Wilson 95%% CI)',cfg.SNR_LIST(ia)));
    cb=colorbar(ax); ylabel(cb,'Satisfaction rate');
    for j=1:nCells
        for i=1:numel(condNames)
            if ~isfinite(rates(i,j)), continue; end
            kx=0; n=0; lo=0; hi=0;
            isRow=summary.K==cfg.K_LIST(ceil(j/numel(cfg.N_LIST))) & ...
                summary.N==cfg.N_LIST(mod(j-1,numel(cfg.N_LIST))+1) & ...
                arrayfun(@(x) isequaln(x,cfg.SNR_LIST(ia)),summary.snr_db) & ...
                strcmp(summary.condition,condNames{i});
            rr=summary(isRow,:);
            if height(rr)==1, kx=rr.n_pass; n=rr.n_valid; lo=rr.ci_lower; hi=rr.ci_upper; end
            text(ax,j,i,sprintf('%d/%d\n[%.2f, %.2f]',kx,n,lo,hi), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontSize',10,'Color','k');
        end
    end
end
exportgraphics(figG,fullfile(cfg.OUTPUT_DIR,'E4_FigG_Condition_heatmap.png'),'Resolution',190);
print(figG,fullfile(cfg.OUTPUT_DIR,'E4_FigG_Condition_heatmap.svg'),'-dsvg');

%% FIGURE H: finite-part diagnostics and transfer comparisons, LHS vs RHS
Tdone=T(strcmp(T.status,'done'),:);
figH=figure('Visible',cfg.FIG_VISIBLE,'Color','w','Position',[80 80 1300 980]);
comp={ ...
    {'enc_N','prop_enc_rhs_finite','C4 | Prop enclosure finite proxy'}, ...
    {'vol_ratio','prop_vol_rhs_finite','C5 | Prop volume finite proxy'}, ...
    {'enc_N','transfer_enc_rhs','C6 | Transfer enclosure bound'}, ...
    {'eta_apx_witness','transfer_apx_rhs','C7 | Transfer approximation bound'}};
for ii=1:4
    ax=subplot(2,2,ii); hold(ax,'on'); grid(ax,'on'); box(ax,'on');
    lhs=Tdone.(comp{ii}{1}); rhs=Tdone.(comp{ii}{2});
    good=isfinite(lhs)&isfinite(rhs)&lhs>=0&rhs>0;
    lhs=max(lhs(good),1e-300); rhs=max(rhs(good),1e-300);
    kval=Tdone.K(good);
    mk=['o','s','^'];
    for ik=1:numel(cfg.K_LIST)
        sel=kval==cfg.K_LIST(ik);
        loglog(ax,rhs(sel),lhs(sel),mk(min(ik,3)),'MarkerSize',5, ...
            'LineStyle','none','DisplayName',sprintf('K=%d',cfg.K_LIST(ik)));
    end
    if ~isempty(lhs)
        v=[lhs;rhs]; mn=min(v); mx=max(v);
        if mx/mn>1e20, mn=max(mn,mx/1e24); end
        line(ax,[mn mx],[mn mx],'LineStyle','--','Color',[.25 .25 .25], ...
            'LineWidth',1.1,'DisplayName','LHS = RHS');
    end
    xlabel(ax,'RHS (bound)'); ylabel(ax,'LHS (observed)');
    title(ax,comp{ii}{3}); legend(ax,'Location','best');
end
exportgraphics(figH,fullfile(cfg.OUTPUT_DIR,'E4_FigH_LHS_vs_RHS.png'),'Resolution',190);
print(figH,fullfile(cfg.OUTPUT_DIR,'E4_FigH_LHS_vs_RHS.svg'),'-dsvg');

fprintf('\nE4 completed: %d done / %d runs | output: %s\n', ...
    sum(strcmp({runs.status},'done')),nRuns,cfg.OUTPUT_DIR);
fprintf(['IMPORTANT: C4/C5 are finite-part plug-in diagnostics. ' ...
    'C6/C7 use observed epsilon; neither is a formal Adam certificate.\n']);

%% LOCAL FUNCTIONS
function e4_save_single_mat(resultsFile,cfg,runs,runIndex,condNames,Tcsv,summary)
% Only ONE persistent MAT is kept for both restart and final replotting.
% Write a temporary MAT in the same folder, then replace resultsFile to
% avoid corrupting the last good result if MATLAB is interrupted mid-save.
% The temporary file is not an additional checkpoint and is deleted on
% successful replacement.
if nargin < 6
    Tcsv = table();
    summary = table();
    is_final = false;
else
    is_final = true;
end
n_completed = sum(strcmp({runs.status},'done'));
n_failed = sum(strcmp({runs.status},'failed'));
resultsDir = fileparts(resultsFile);
tempFile = fullfile(resultsDir,'E4_formal_results_writing.mat');
save(tempFile,'cfg','runs','runIndex','condNames','Tcsv','summary', ...
    'is_final','n_completed','n_failed','-v7.3');
[ok,msg] = movefile(tempFile,resultsFile,'f');
if ~ok
    error('Unable to replace E4_formal_results.mat: %s',msg);
end
end

function r=e4_blank_run()
% Scalar audit outputs plus small p-by-p simplex vertices (no p-by-N arrays).
r=struct('status','pending','error_message','','run_id',NaN, ...
    'K',NaN,'p',NaN,'N',NaN,'repeat',NaN,'snr_db',NaN, ...
    'data_seed',NaN,'train_seed',NaN,'oracle_seed',NaN,'tv_seed',NaN, ...
    'material_indices','','measured_snr_db',NaN, ...
    'tv',NaN,'vol_true',NaN,'vol_est',NaN,'vol_ratio',NaN, ...
    'D_true',NaN,'D_est',NaN,'max_vertex_dist',NaN,'enc_N',NaN, ...
    'eta_apx_witness',NaN,'model_affine_drift',NaN,'kappa_true',NaN,'b',NaN,'cbar3',NaN, ...
    'epsilon_selfconsistent',NaN,'prop_enc_rhs_finite',NaN, ...
    'prop_vol_rhs_finite',NaN,'prop_vol_log_rhs',NaN, ...
    'transfer_enc_rhs',NaN,'transfer_apx_rhs',NaN, ...
    'risk_adam',NaN,'risk_oracle',NaN,'risk_oracle_gap_signed',NaN, ...
    'risk_adam_recon',NaN,'risk_oracle_recon',NaN, ...
    'risk_adam_enclose',NaN,'risk_oracle_enclose',NaN, ...
    'oracle_lu_perm_identity',NaN,'oracle_lu_min_abs_pivot',NaN, ...
    'oracle_min_abs_leading_minor',NaN, ...
    'C1',NaN,'C2',NaN,'C3',NaN,'C4',NaN,'C5',NaN,'C6',NaN,'C7',NaN, ...
    'C1_margin_lower',NaN,'C1_margin_upper',NaN,'C2_margin',NaN, ...
    'C3_margin',NaN,'C4_margin',NaN,'C5_log_margin',NaN, ...
    'C6_margin',NaN,'C7_margin',NaN, ...
    'M_true_work',[],'M_est_work',[], ...
    'M_model_work',[],'Q_model_work',[],'wall_clock_s',NaN);
end

function sig=e4_signature(c)
keys={'FAST_TEST','DATA_MODE','K_LIST','N_LIST','SNR_LIST','REPEATS', ...
    'STEPS','WARM_UP','ORACLE_STEPS','HIDDEN','BATCH_SIZE', ...
    'LR','LAMBDA_VOL','LAMBDA_ENCLOSE','LAMBDA_SUMONE', ...
    'LAMBDA_NONNEG','LAMBDA_EQ','TV_MC','DATA_SEED_BASE', ...
    'TRAIN_SEED_BASE','ORACLE_SEED_BASE','THEORY_NORMALIZED'};
sig=cell(1,numel(keys));
for i=1:numel(keys), sig{i}=c.(keys{i}); end
end

function W=e4_to_work(Z,Up,my,D,reg,p)
C=diag(1./sqrt(diag(D)+reg));
W=C*Up(:,1:p-1)'*(Z-my);
W(p,:)=1;
W=W/sqrt(p);
end

function R=e4_full_risk(Yw,Mw,A,qm,MTw,cfg)
% E2-equivalent full-data objective for BOTH Adam and oracle, with
% volume relative to the true simplex (same additive constant removed).
% Sample penalties use SUM, matching the actual E2-trained objective.
% The theorem's MEAN enc_N is calculated separately by e4_enclosure_squared_mean.
N=size(Yw,2); Q=inv(Mw);
R.recon=mean(sum((Mw*A-Yw).^2,1));
R.nonneg=sum(min(A,0).^2,'all');
R.sumone=sum((sum(A,1)-1).^2);
R.eq=sum((sum(Q,1)-qm).^2,'all');
R.enclose=0;
for j=1:cfg.TV_CHUNK:N
    ids=j:min(j+cfg.TV_CHUNK-1,N);
    QY=Q*Yw(:,ids);
    R.enclose=R.enclose+sum(min(QY,0).^2,'all');
end
% Keep the full-data enclosure SUM for the E2 training objective.
% (Do not divide by N; the separate enc_N metric remains an average.)
% Exact flow log-determinant term up to the SAME additive constant:
% -sum(r_log) = log|det(M_internal)| - log|det(M0)|.
% Do not substitute geometric simplex volume here if model affine drift exists.
R.vol=sum(log(svd(Mw)))-sum(log(svd(MTw)));
R.total=R.recon+cfg.LAMBDA_VOL*R.vol+ ...
    cfg.LAMBDA_NONNEG*R.nonneg+cfg.LAMBDA_SUMONE*R.sumone+ ...
    cfg.LAMBDA_EQ*R.eq+cfg.LAMBDA_ENCLOSE*R.enclose;
end

function v=e4_simplex_volume(M)
p=size(M,2); E=M(:,2:p)-M(:,1);
sv=svd(E,'econ');
v=prod(sv)/factorial(p-1);
end

function d=e4_diameter(M)
p=size(M,2); d=0;
for i=1:p
    for j=i+1:p
        d=max(d,norm(M(:,i)-M(:,j)));
    end
end
end

function [tv,V1,V2]=e4_tv_dist_simplex(M1,M2,nMC,seed,chunk)
% E2/Table-2 TV: 1 - intersection_volume / max(volume1,volume2).
% Consistent paired MC stream; chunks prevent high peak RAM.
V1=e4_simplex_volume(M1); V2=e4_simplex_volume(M2);
if V1<=0 || V2<=0 || ~isfinite(V1+V2), tv=NaN; return; end
stream=RandStream('mt19937ar','Seed',seed);
p=size(M1,2); nInside12=0; nInside21=0;
Q1=inv(M1); Q2=inv(M2);
for j=1:chunk:nMC
    m=min(chunk,nMC-j+1);
    A=-log(max(rand(stream,p,m),realmin)); A=A./sum(A,1);
    nInside12=nInside12+sum(all((Q2*(M1*A))>=-1e-8,1));
    B=-log(max(rand(stream,p,m),realmin)); B=B./sum(B,1);
    nInside21=nInside21+sum(all((Q1*(M2*B))>=-1e-8,1));
end
Vint=0.5*(V1*(nInside12/nMC)+V2*(nInside21/nMC));
tv=max(0,min(1,1-Vint/max(V1,V2)));
end

function enc=e4_enclosure_squared_mean(Yw,Mw,chunk)
% EXACT paper enc_N: mean of squared NEGATIVE barycentric coordinates.
% NOT the out-of-simplex sample fraction (Python demo's enc_mass).
Q=inv(Mw); N=size(Yw,2); s=0;
for j=1:chunk:N
    ii=j:min(j+chunk-1,N);
    A=Q*Yw(:,ii);
    s=s+sum(min(A,0).^2,'all');
end
enc=s/N;
end

function md=e4_max_vertex_dist_to_simplex(Me,Mt)
md=0;
for i=1:size(Me,2)
    md=max(md,e4_point_to_simplex_dist(Me(:,i),Mt));
end
end

function d=e4_point_to_simplex_dist(x,M)
% Exact small-p active-face enumeration, p<=8 (up to 255 faces).
% Unlike nearest-vertex matching, computes min_{a>=0, 1'a=1} ||Ma-x||.
p=size(M,2); a0=M\x;
if min(a0)>=-1e-10 && abs(sum(a0)-1)<1e-8, d=0; return; end
best=inf;
for mask=1:(2^p-1)
    ids=find(bitget(mask,1:p));
    if numel(ids)==1
        cost=sum((M(:,ids)-x).^2);
    else
        Z=M(:,ids); q=numel(ids);
        G=Z'*Z; onesq=ones(q,1);
        tmp=[G,onesq;onesq',0] \ [Z'*x;1];
        a=tmp(1:q);
        if min(a)<-1e-9, continue; end
        cost=sum((Z*a-x).^2);
    end
    best=min(best,cost);
end
if ~isfinite(best), error('Point-to-simplex projection failed.'); end
d=sqrt(max(best,0));
end

function [permId,minPivot,minMinor]=e4_lu_audit(Q)
% Inspect unpermuted leading principal minors and MATLAB pivoted LU.
[~,U,P]=lu(Q);
permId=(norm(P-eye(size(Q)),inf)<1e-10);
minPivot=min(abs(diag(U)));
minMinor=inf;
for j=1:size(Q,1)
    minMinor=min(minMinor,abs(det(Q(1:j,1:j))));
end
end

function [rate,lo,hi]=e4_wilson(k,n)
if n==0, rate=NaN; lo=NaN; hi=NaN; return; end
z=1.95996398454005; rate=k/n;
den=1+z^2/n;
c=(rate+z^2/(2*n))/den;
h=z*sqrt(rate*(1-rate)/n+z^2/(4*n^2))/den;
lo=max(0,c-h); hi=min(1,c+h);
end
