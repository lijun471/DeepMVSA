%% demo_deepmvsa_dz01v_invflow
% DeepMVSA-InvFlow on DZ01V_L4.mat -- Fig. 7(a)-style experiment.
%
% Experimental setting used here:
%   1) use ALL valid DZ01V pixels for DeepMVSA unmixing;
%   2) do NOT randomly subsample pixels;
%   3) do NOT add a separate PCA-to-10 preprocessing step;
%   4) estimate p endmembers (the p variable below is authoritative);
%   5) display ALL valid pixels in the final 2-D projection;
%   6) perform 20 paired repetitions: DeepMVSA(seed i), then MVSA(seed i);
%   7) compare paired 20-run DeepMVSA and MVSA results by full-data reconstruction
%      RMSE, relative reconstruction residual, runtime, and 2-D endmember overlay;
%   8) save a separate MVSA comparison MAT file and the combined AllPlots MAT.
%
% Required functions on MATLAB path:
%   dataProj.m
%   deep_mvsa_invflow_rmse1.m (or the function file defining this function)
%   mvsa.m
%   VCA.m
%   quadProg1.m

clear; clc; close all;

%% ===================== Parameters =====================
%DATA_FILE = 'DZ01V_L4.mat';
DATA_FILE = 'DZ01V_L4_clean_norm.mat';
% Number of endmembers used by both methods.
p = 3;

% DeepMVSA-InvFlow parameters: retained from the supplied USGS demo.
DEEP_MM_ITERS       = 15000;
DEEP_WARM_UP        = 400;
DEEP_LR             = 1e-3;
DEEP_LAMBDA_VOL     = 0.01;
DEEP_LAMBDA_NONNEG  = 5;
DEEP_LAMBDA_EQ      = 80;
DEEP_LAMBDA_SUMONE  = 2;
DEEP_LAMBDA_ENCLOSE = 20;
DEEP_BATCH_SIZE     = 4096;
DEEP_SEED           = 0;
% 重复运行次数。两张训练曲线会对这20次结果取平均，并绘制mean±std色带。
DEEP_NUM_RUNS       = 20;
DEEP_RMSE_INTERVAL  = 100;
DEEP_RMSE_MONITOR_SIZE = 20000;

% ===================== MVSA baseline settings =====================
% MVSA uses exactly the same full Y and the same endmember number p.
% The supplied mvsa.m implementation uses VCA initialization when M0=0.
RUN_MVSA             = true;
MVSA_MM_ITERS        = 10;
MVSA_SPHERIZE        = 'yes';
MVSA_MU              = 1e-6;
MVSA_LAMBDA          = 1e-10;
MVSA_TOLF            = 1e-2;
MVSA_VERBOSE         = 1;
MVSA_SEED            = DEEP_SEED;  % MVSA uses the same seed as DeepMVSA in each paired run.
MVSA_NUM_RUNS        = 20;
MVSA_PLOT_RUN        = 1;   % Representative run used for the 2-D endmember overlay.
% Chunk size used only for computing full-data reconstruction metrics.
% This does not subsample pixels or alter either method's output.
METRIC_CHUNK_SIZE    = 100000;
% Optional: save full p-by-N abundance matrices. This can create a large MAT
% file for million-pixel scenes; keep false when only curves/endmembers/
% quantitative comparison metrics are required.
SAVE_ABUNDANCE_MATRICES = false;
ABUNDANCE_DATA_FILE = sprintf('1DZ01V_DeepMVSA_MVSA_Abundances_p%d.mat', p);

% Save the result figures.
SAVE_FIGURE = true;
FIGURE_FILE = sprintf('1DZ01V_DeepMVSA_MVSA_Fig7a_p%d.png', p);
RMSE_FIGURE_FILE = sprintf('1DZ01V_DeepMVSA_RMSE_p%d.png', p);
RMSE_DATA_FILE = sprintf('1DZ01V_DeepMVSA_RMSE_p%d.mat', p);
LOGVOL_FIGURE_FILE = sprintf('1DZ01V_DeepMVSA_LogVolume_p%d.png', p);
LOGVOL_DATA_FILE = sprintf('1DZ01V_DeepMVSA_LogVolume_p%d.mat', p);
ALL_PLOTS_DATA_FILE = sprintf('1DZ01V_DeepMVSA_AllPlots_p%d.mat', p);
MVSA_DATA_FILE = sprintf('1DZ01V_DeepMVSA_MVSA_Comparison_p%d.mat', p);
COMPARISON_FIGURE_FILE = sprintf('1DZ01V_DeepMVSA_vs_MVSA_Comparison_p%d.png', p);

% ===================== RMSE曲线图显示参数 =====================
% 图窗口大小，单位为像素。数值越大，导出的图片整体越大。
RMSE_FIGURE_POSITION = [100 100 560 380];
% 坐标轴在图窗口内的位置：[左边距 下边距 宽度 高度]，取值范围0到1。
% 适当增大左/下边距可以避免导出PNG/PDF时坐标轴文字被裁掉。
RMSE_AXES_POSITION = [0.20 0.22 0.70 0.60];
% 横坐标刻度字体大小。
RMSE_X_TICK_FONT_SIZE = 15;
% 纵坐标刻度字体大小。
RMSE_Y_TICK_FONT_SIZE = 15;
% 横坐标标题字体大小。
RMSE_X_LABEL_FONT_SIZE = 18;
% 纵坐标标题字体大小。
RMSE_Y_LABEL_FONT_SIZE = 18;
% 图标题字体大小。
RMSE_TITLE_FONT_SIZE = 14;
% 图例字体大小。
RMSE_LEGEND_FONT_SIZE = 14;
% RMSE曲线线宽。
RMSE_LINE_WIDTH = 1.8;
% RMSE标准差色带透明度，取值0到1；越大色带越不透明。
RMSE_STD_BAND_ALPHA = 0.20;
% RMSE均值曲线颜色。
RMSE_LINE_COLOR = [0.00 0.20 0.85];
% RMSE标准差色带颜色。
RMSE_STD_BAND_COLOR = [0.45 0.65 1.00];

% ===================== log-volume曲线图显示参数 =====================
% 这里复用RMSE图的版式，只单独设置线宽，方便两张曲线图风格一致。
LOGVOL_LINE_WIDTH = 1.8;
% log-volume标准差色带透明度，取值0到1；越大色带越不透明。
LOGVOL_STD_BAND_ALPHA = 0.20;
% log-volume均值曲线颜色。
LOGVOL_LINE_COLOR = [0.85 0.10 0.05];
% log-volume标准差色带颜色。
LOGVOL_STD_BAND_COLOR = [1.00 0.62 0.55];

%% ===================== Load DZ01V data =====================
if ~isfile(DATA_FILE)
    error('Data file does not exist: %s', DATA_FILE);
end

file_info = whos('-file', DATA_FILE);
var_names = {file_info.name};

fprintf('Loading DZ01V data from:\n  %s\n', DATA_FILE);

if ismember('Y', var_names)
    % Case 1: MAT file already contains Y.
    S = load(DATA_FILE, 'Y');
    Y = S.Y;
    clear S;

    % If num_bands is available, use it to verify/correct orientation.
    if ismember('num_bands', var_names)
        Smeta = load(DATA_FILE, 'num_bands');
        num_bands_file = double(Smeta.num_bands);
        clear Smeta;

        if size(Y,1) ~= num_bands_file && size(Y,2) == num_bands_file
            Y = Y.';
        end
    end

elseif ismember('cube_rad', var_names)
    % Case 2: MAT file was produced by make_dz01v_unmixing_mat.m.
    vars_to_load = {'cube_rad'};
    if ismember('valid_idx', var_names)
        vars_to_load{end+1} = 'valid_idx';
    elseif ismember('valid_mask', var_names)
        vars_to_load{end+1} = 'valid_mask';
    end

    S = load(DATA_FILE, vars_to_load{:});

    cube_rad = S.cube_rad;
    num_bands_cube = size(cube_rad, 1);
    Y = reshape(cube_rad, num_bands_cube, []);
    clear cube_rad;

    % Use all valid pixels prepared by the DZ01V preprocessing file.
    if isfield(S, 'valid_idx') && ~isempty(S.valid_idx)
        Y = Y(:, double(S.valid_idx));
    elseif isfield(S, 'valid_mask') && ~isempty(S.valid_mask)
        valid_idx_local = find(S.valid_mask(:));
        Y = Y(:, valid_idx_local);
        clear valid_idx_local;
    end
    clear S;

else
    error(['DZ01V_L4.mat must contain either variable ''Y'' or ''cube_rad''. ' ...
           'The preprocessing file make_dz01v_unmixing_mat.m produces ''cube_rad''.']);
end

% Match the numerical type used in the original MATLAB DeepMVSA workflow.
Y = double(Y);

% Safety filtering for a directly supplied Y. This does NOT subsample data;
% it only removes invalid or entirely-zero pixel spectra.
valid_col = all(isfinite(Y), 1) & any(Y ~= 0, 1);
if ~all(valid_col)
    fprintf('Removing %d invalid/zero pixels.\n', sum(~valid_col));
    Y = Y(:, valid_col);
end
clear valid_col;

[L, N] = size(Y);

if L < p
    error('Number of spectral bands L=%d must be >= p=%d.', L, p);
end
if N < p
    error('Not enough valid pixels: N=%d, p=%d.', N, p);
end

fprintf('\n========== DZ01V DATA ==========' );
fprintf('\nSpectral bands L       = %d\n', L);
fprintf('Valid pixels N         = %d\n', N);
fprintf('Number of endmembers p = %d\n', p);
fprintf('All %d valid pixels will participate in DeepMVSA.\n', N);
fprintf('All %d valid pixels will also be displayed in the final 2-D figure.\n', N);
fprintf('Actual endmember number p = %d (both methods will use this value).\n', p);

if RUN_MVSA
    required_mvsa_functions = {'mvsa', 'VCA', 'quadProg1'};
    missing_mvsa_functions = {};
    for kk = 1:numel(required_mvsa_functions)
        if exist(required_mvsa_functions{kk}, 'file') ~= 2
            missing_mvsa_functions{end+1} = required_mvsa_functions{kk}; %#ok<AGROW>
        end
    end
    if ~isempty(missing_mvsa_functions)
        error(['MVSA comparison cannot start. Missing function(s) on MATLAB path: %s. ' ...
               'Place mvsa.m, VCA.m and quadProg1.m on the MATLAB path.'], ...
               strjoin(missing_mvsa_functions, ', '));
    end

    if N > 1e6
        warning(['MVSA is being run on all %d valid pixels. The supplied MVSA ' ...
                 'implementation forms QP constraints whose size grows with p*N; ' ...
                 'runtime and memory may be substantial. No pixel subsampling is applied.'], N);
    end
    if ~isscalar(MVSA_NUM_RUNS) || MVSA_NUM_RUNS < 1 || MVSA_NUM_RUNS ~= floor(MVSA_NUM_RUNS)
        error('MVSA_NUM_RUNS must be a positive integer.');
    end
    if ~isscalar(MVSA_PLOT_RUN) || MVSA_PLOT_RUN < 1 || ...
            MVSA_PLOT_RUN > MVSA_NUM_RUNS || MVSA_PLOT_RUN ~= floor(MVSA_PLOT_RUN)
        error('MVSA_PLOT_RUN must be an integer between 1 and MVSA_NUM_RUNS.');
    end
end

%% ===================== Affine projection =====================
% This is the same affine projection step used by the supplied USGS demo.
% No additional PCA-to-10 preprocessing is introduced here.
[Y_proj, Up, ~, sing_val] = dataProj(Y, p, 'proj_type', 'affine');
pc_var_percent = 100 * sing_val(:) / sum(sing_val);

% For the final figure, use ALL pixels and only compute the first two
% coordinates needed for display. This is equivalent to taking the first
% two rows of Up' * Y_proj, but avoids allocating the full p-by-N display
% matrix solely for visualization.
Y_plot = Up(:,1:2)' * Y_proj;
clear Y_proj;

%% ===================== Paired DeepMVSA / MVSA repeated runs =====================
% Each paired repetition runs DeepMVSA first and MVSA second with the SAME seed.
% The next seed is not started until both methods have completed the current pair.
if RUN_MVSA
    if MVSA_NUM_RUNS ~= DEEP_NUM_RUNS
        error(['Paired execution requires MVSA_NUM_RUNS == DEEP_NUM_RUNS. ' ...
               'Received MVSA_NUM_RUNS=%d and DEEP_NUM_RUNS=%d.'], ...
               MVSA_NUM_RUNS, DEEP_NUM_RUNS);
    end

    required_mvsa_functions = {'mvsa', 'VCA', 'quadProg1'};
    missing_mvsa_functions = {};
    for kk = 1:numel(required_mvsa_functions)
        if exist(required_mvsa_functions{kk}, 'file') ~= 2
            missing_mvsa_functions{end+1} = required_mvsa_functions{kk}; %#ok<AGROW>
        end
    end
    if ~isempty(missing_mvsa_functions)
        error(['MVSA comparison cannot start. Missing function(s) on MATLAB path: %s. ' ...
               'Place mvsa.m, VCA.m and quadProg1.m on the MATLAB path.'], ...
               strjoin(missing_mvsa_functions, ', '));
    end

    if N > 1e6
        warning(['MVSA is being run on all %d valid pixels. The supplied MVSA ' ...
                 'implementation forms QP constraints whose size grows with p*N; ' ...
                 'runtime and memory may be substantial. No pixel subsampling is applied.'], N);
    end

    if ~isscalar(MVSA_PLOT_RUN) || MVSA_PLOT_RUN < 1 || ...
            MVSA_PLOT_RUN > MVSA_NUM_RUNS || MVSA_PLOT_RUN ~= floor(MVSA_PLOT_RUN)
        error('MVSA_PLOT_RUN must be an integer between 1 and MVSA_NUM_RUNS.');
    end

    fprintf('\n========== Paired DeepMVSA / MVSA experiment ==========');
    fprintf('\nInput size L x N        = %d x %d\n', L, N);
    fprintf('Number of endmembers p = %d\n', p);
    fprintf('Paired repetitions     = %d\n', DEEP_NUM_RUNS);
    fprintf('DeepMVSA seed range    = %d to %d\n', ...
        DEEP_SEED, DEEP_SEED + DEEP_NUM_RUNS - 1);
    fprintf('MVSA uses the matching DeepMVSA seed in each pair.\n');
    fprintf('MVSA MM_ITERS           = %d\n', MVSA_MM_ITERS);
    fprintf('MVSA SPHERIZE           = %s\n', MVSA_SPHERIZE);
    fprintf('MVSA representative run = %d\n', MVSA_PLOT_RUN);

    mvsa_options = struct( ...
        'MM_ITERS', MVSA_MM_ITERS, ...
        'SPHERIZE', MVSA_SPHERIZE, ...
        'MU', MVSA_MU, ...
        'LAMBDA', MVSA_LAMBDA, ...
        'TOLF', MVSA_TOLF, ...
        'M0', 0, ...
        'VERBOSE', MVSA_VERBOSE, ...
        'SEED_BASE', DEEP_SEED, ...
        'NUM_RUNS', MVSA_NUM_RUNS, ...
        'PLOT_RUN', MVSA_PLOT_RUN, ...
        'SEED_PAIRING', 'MVSA uses the same seed as DeepMVSA for each run index.');

    mvsa_seed_runs = (DEEP_SEED + (0:MVSA_NUM_RUNS-1)).';
    mvsa_runtime_runs = zeros(MVSA_NUM_RUNS, 1);
    mvsa_metrics_runs = cell(MVSA_NUM_RUNS, 1);
    M_mvsa_runs = zeros(L, p, MVSA_NUM_RUNS);

    % Preserve the caller's RNG and warning states for the complete paired run.
    rng_state_before_paired_runs = rng;
    warning_state_before_paired_runs = warning;
end

% If optional abundance export is enabled, create the MAT file before the
% first pair so the selected MVSA abundance can be appended even when its
% representative run is earlier than the final repetition.
if SAVE_ABUNDANCE_MATRICES
    abundance_export_initialized = true; %#ok<NASGU>
    save(ABUNDANCE_DATA_FILE, 'abundance_export_initialized', '-v7.3');
end

rmse_histories = cell(DEEP_NUM_RUNS, 1);
logvol_histories = cell(DEEP_NUM_RUNS, 1);
memory_stats_runs = cell(DEEP_NUM_RUNS, 1);
runtime_runs = zeros(DEEP_NUM_RUNS, 1);
deep_reconstruction_metrics_runs = cell(DEEP_NUM_RUNS, 1);
deep_seed_runs = (DEEP_SEED + (0:DEEP_NUM_RUNS-1)).';

for run_idx = 1:DEEP_NUM_RUNS
    run_seed = deep_seed_runs(run_idx);
    fprintf('\n========== PAIRED RUN %d/%d, shared seed=%d ==========\n', ...
        run_idx, DEEP_NUM_RUNS, run_seed);

    % --------------------- Step A: DeepMVSA ---------------------
    % Reset MATLAB's global RNG and also pass the same explicit seed to the
    % DeepMVSA implementation.
    rng(run_seed, 'twister');
    fprintf('--- DeepMVSA run %d/%d, seed=%d ---\n', ...
        run_idx, DEEP_NUM_RUNS, run_seed);

    tic;
    [M_deep, S_deep, ~, ~, theta, rmse_history, logvol_history, memory_stats] = deep_mvsa_invflow_rmse1(Y, p, ...
        'spherize', 'yes', ...
        'verbose', 1, ...
        'MM_ITERS', DEEP_MM_ITERS, ...
        'WARM_UP', DEEP_WARM_UP, ...
        'LR', DEEP_LR, ...
        'LAMBDA_VOL', DEEP_LAMBDA_VOL, ...
        'LAMBDA_NONNEG', DEEP_LAMBDA_NONNEG, ...
        'LAMBDA_EQ', DEEP_LAMBDA_EQ, ...
        'LAMBDA_SUMONE', DEEP_LAMBDA_SUMONE, ...
        'LAMBDA_ENCLOSE', DEEP_LAMBDA_ENCLOSE, ...
        'BATCH_SIZE', DEEP_BATCH_SIZE, ...
        'SEED', run_seed, ...
        'MONITOR_INTERVAL', DEEP_RMSE_INTERVAL, ...
        'MONITOR_SIZE', DEEP_RMSE_MONITOR_SIZE, ...
        'MONITOR_SEED', DEEP_SEED + 1009, ...
        'MEASURE_OPT_MEMORY', true);
    runtime_runs(run_idx) = toc;

    % Full-data metrics are evaluated after the timed model call.
    deep_reconstruction_metrics_runs{run_idx} = reconstruction_metrics_chunked( ...
        Y, M_deep, S_deep, METRIC_CHUNK_SIZE);

    rmse_histories{run_idx} = rmse_history;
    logvol_histories{run_idx} = logvol_history;
    memory_stats_runs{run_idx} = memory_stats;

    fprintf('DeepMVSA run %d/%d: RMSE=%.8g, relative residual=%.6f%%, runtime=%.3fs\n', ...
        run_idx, DEEP_NUM_RUNS, ...
        deep_reconstruction_metrics_runs{run_idx}.rmse, ...
        deep_reconstruction_metrics_runs{run_idx}.relative_residual_percent, ...
        runtime_runs(run_idx));

    % Preserve the original script's optional abundance export: save the
    % final DeepMVSA run only. Release S before running MVSA to limit memory.
    if SAVE_ABUNDANCE_MATRICES && run_idx == DEEP_NUM_RUNS
        save(ABUNDANCE_DATA_FILE, 'S_deep', '-append');
    end
    clear S_deep;

    % --------------------- Step B: MVSA ---------------------
    % MVSA is run immediately after its paired DeepMVSA run, using exactly
    % the same integer seed. mvsa.m does not expose a SEED option, so seed
    % MATLAB's RNG immediately before its VCA-based initialization.
    if RUN_MVSA
        mvsa_run_idx = run_idx;
        mvsa_run_seed = run_seed;
        fprintf('--- MVSA run %d/%d, paired seed=%d ---\n', ...
            mvsa_run_idx, MVSA_NUM_RUNS, mvsa_run_seed);

        rng_state_before_mvsa = rng;
        warning_state_before_mvsa = warning;
        rng(mvsa_run_seed, 'twister');

        try
            tic;
            [M_mvsa_run, S_mvsa_run, Up_mvsa_run, my_mvsa_run, sing_values_mvsa_run] = mvsa(Y, p, ...
                'MM_ITERS', MVSA_MM_ITERS, ...
                'SPHERIZE', MVSA_SPHERIZE, ...
                'MU', MVSA_MU, ...
                'LAMBDA', MVSA_LAMBDA, ...
                'TOLF', MVSA_TOLF, ...
                'M0', 0, ...
                'VERBOSE', MVSA_VERBOSE);
            mvsa_runtime_runs(mvsa_run_idx) = toc;
        catch ME
            rng(rng_state_before_mvsa);
            warning(warning_state_before_mvsa);
            rethrow(ME);
        end

        rng(rng_state_before_mvsa);
        warning(warning_state_before_mvsa);

        if ~isequal(size(M_mvsa_run), [L, p])
            error('MVSA run %d returned M with size %s; expected %d x %d.', ...
                mvsa_run_idx, mat2str(size(M_mvsa_run)), L, p);
        end
        if ~isequal(size(S_mvsa_run), [p, N])
            error('MVSA run %d returned Sest with size %s; expected %d x %d.', ...
                mvsa_run_idx, mat2str(size(S_mvsa_run)), p, N);
        end

        mvsa_metrics_runs{mvsa_run_idx} = reconstruction_metrics_chunked( ...
            Y, M_mvsa_run, S_mvsa_run, METRIC_CHUNK_SIZE);
        M_mvsa_runs(:, :, mvsa_run_idx) = M_mvsa_run;

        fprintf('MVSA run %d/%d: RMSE=%.8g, relative residual=%.6f%%, runtime=%.3fs\n', ...
            mvsa_run_idx, MVSA_NUM_RUNS, ...
            mvsa_metrics_runs{mvsa_run_idx}.rmse, ...
            mvsa_metrics_runs{mvsa_run_idx}.relative_residual_percent, ...
            mvsa_runtime_runs(mvsa_run_idx));

        % Append the selected representative MVSA abundance matrix only.
        if SAVE_ABUNDANCE_MATRICES && mvsa_run_idx == MVSA_PLOT_RUN
            S_mvsa = S_mvsa_run; %#ok<NASGU>
            save(ABUNDANCE_DATA_FILE, 'S_mvsa', '-append');
            abundance_file_info = dir(ABUNDANCE_DATA_FILE);
            fprintf('Representative MVSA abundance matrix (run %d) appended: %s (%.3f MB)\n', ...
                MVSA_PLOT_RUN, ABUNDANCE_DATA_FILE, abundance_file_info.bytes/1e6);
            if abundance_file_info.bytes > 95e6
                warning(['Abundance MAT file exceeds 95 MB. Use a MAT splitting ' ...
                         'script before transferring or archiving it.']);
            end
            clear S_mvsa;
        end

        if mvsa_run_idx == MVSA_PLOT_RUN
            M_mvsa = M_mvsa_run;
            Up_mvsa = Up_mvsa_run;
            my_mvsa = my_mvsa_run;
            sing_values_mvsa = sing_values_mvsa_run;
        end

        clear M_mvsa_run S_mvsa_run Up_mvsa_run my_mvsa_run sing_values_mvsa_run;
    end
end

% Restore the RNG/warning states that were active before the paired experiment.
if RUN_MVSA
    rng(rng_state_before_paired_runs);
    warning(warning_state_before_paired_runs);
end

% Aggregate the 20 DeepMVSA training histories after all paired runs finish.
rmse_stats = aggregate_monitor_histories(rmse_histories, 'rmse');
logvol_stats = aggregate_monitor_histories(logvol_histories, 'log_volume');
t_deep = sum(runtime_runs);

% Preserve the final DeepMVSA run's outputs for compatibility with the
% existing plotting/saving variables; use all 20 runs for summary statistics.
deep_reconstruction_metrics = deep_reconstruction_metrics_runs{end};
deep_rmse_runs = cellfun(@(x) x.rmse, deep_reconstruction_metrics_runs(:));
deep_relative_residual_runs = cellfun( ...
    @(x) x.relative_residual_percent, deep_reconstruction_metrics_runs(:));
deep_reconstruction_stats = struct();
deep_reconstruction_stats.rmse_mean = mean(deep_rmse_runs);
deep_reconstruction_stats.rmse_std = std(deep_rmse_runs, 0);
deep_reconstruction_stats.relative_residual_percent_mean = mean(deep_relative_residual_runs);
deep_reconstruction_stats.relative_residual_percent_std = std(deep_relative_residual_runs, 0);

% Project the final DeepMVSA endmembers into the common display coordinates.
Mdeep = Up' * M_deep;
m_deep = Mdeep(1:2, :);

% ===================== Paired MVSA summaries and comparison =====================
if RUN_MVSA
    mvsa_rmse_runs = cellfun(@(x) x.rmse, mvsa_metrics_runs(:));
    mvsa_relative_residual_runs = cellfun( ...
        @(x) x.relative_residual_percent, mvsa_metrics_runs(:));
    mvsa_runtime_sec = mean(mvsa_runtime_runs);
    mvsa_runtime_std_sec = std(mvsa_runtime_runs, 0);

    mvsa_reconstruction_metrics = mvsa_metrics_runs{MVSA_PLOT_RUN};
    mvsa_reconstruction_stats = struct();
    mvsa_reconstruction_stats.rmse_mean = mean(mvsa_rmse_runs);
    mvsa_reconstruction_stats.rmse_std = std(mvsa_rmse_runs, 0);
    mvsa_reconstruction_stats.relative_residual_percent_mean = mean(mvsa_relative_residual_runs);
    mvsa_reconstruction_stats.relative_residual_percent_std = std(mvsa_relative_residual_runs, 0);

    Mmvsa_projected = Up' * M_mvsa;
    m_mvsa = Mmvsa_projected(1:2, :);

    % Pairwise differences preserve the shared-seed run correspondence.
    paired_rmse_difference = mvsa_rmse_runs - deep_rmse_runs;
    paired_relative_residual_difference = ...
        mvsa_relative_residual_runs - deep_relative_residual_runs;
    paired_runtime_difference = mvsa_runtime_runs - runtime_runs;

    comparison_summary = struct();
    comparison_summary.method = {'DeepMVSA-InvFlow'; 'MVSA'};
    comparison_summary.num_runs = [DEEP_NUM_RUNS; MVSA_NUM_RUNS];
    comparison_summary.full_data_rmse = [ ...
        deep_reconstruction_stats.rmse_mean; mvsa_reconstruction_stats.rmse_mean];
    comparison_summary.full_data_rmse_std = [ ...
        deep_reconstruction_stats.rmse_std; mvsa_reconstruction_stats.rmse_std];
    comparison_summary.relative_residual_percent = [ ...
        deep_reconstruction_stats.relative_residual_percent_mean; ...
        mvsa_reconstruction_stats.relative_residual_percent_mean];
    comparison_summary.relative_residual_percent_std = [ ...
        deep_reconstruction_stats.relative_residual_percent_std; ...
        mvsa_reconstruction_stats.relative_residual_percent_std];
    comparison_summary.runtime_sec = [mean(runtime_runs); mean(mvsa_runtime_runs)];
    comparison_summary.runtime_std_sec = [std(runtime_runs, 0); std(mvsa_runtime_runs, 0)];
    comparison_summary.total_runtime_sec = [sum(runtime_runs); sum(mvsa_runtime_runs)];
    comparison_summary.full_data_rmse_runs = {deep_rmse_runs; mvsa_rmse_runs};
    comparison_summary.relative_residual_percent_runs = ...
        {deep_relative_residual_runs; mvsa_relative_residual_runs};
    comparison_summary.runtime_runs = {runtime_runs; mvsa_runtime_runs};
    comparison_summary.shared_seed_runs = deep_seed_runs;
    comparison_summary.deep_seed_runs = deep_seed_runs;
    comparison_summary.mvsa_seed_runs = mvsa_seed_runs;
    comparison_summary.paired_rmse_difference_mvsa_minus_deep = paired_rmse_difference;
    comparison_summary.paired_relative_residual_difference_mvsa_minus_deep = ...
        paired_relative_residual_difference;
    comparison_summary.paired_runtime_difference_mvsa_minus_deep = paired_runtime_difference;
    comparison_summary.mvsa_plot_run = MVSA_PLOT_RUN;
    comparison_summary.execution_order = ...
        'For each run index: DeepMVSA(seed) first, then MVSA(same seed), then the next run index.';
    comparison_summary.runtime_note = ...
        'Each method reports mean runtime per run and sample standard deviation across paired runs; metric calculation is excluded from runtime.';
    comparison_summary.rmse_note = ...
        'Each run uses all L-by-N input values. Run i of DeepMVSA and run i of MVSA share the same integer seed.';
    comparison_summary.plot_note = ...
        'The 2-D MVSA overlay uses the explicitly selected MVSA_PLOT_RUN; endmember matrices are not averaged across runs.';

    save(MVSA_DATA_FILE, ...
        'M_deep', 'deep_seed_runs', 'deep_reconstruction_metrics', ...
        'deep_reconstruction_metrics_runs', 'deep_reconstruction_stats', ...
        'deep_rmse_runs', 'deep_relative_residual_runs', 'runtime_runs', ...
        'M_mvsa', 'M_mvsa_runs', 'Up_mvsa', 'my_mvsa', 'sing_values_mvsa', ...
        'mvsa_seed_runs', 'mvsa_runtime_runs', 'mvsa_runtime_sec', ...
        'mvsa_runtime_std_sec', 'mvsa_metrics_runs', 'mvsa_rmse_runs', ...
        'mvsa_relative_residual_runs', 'mvsa_reconstruction_metrics', ...
        'mvsa_reconstruction_stats', 'mvsa_options', 'comparison_summary', ...
        'paired_rmse_difference', 'paired_relative_residual_difference', ...
        'paired_runtime_difference', 'm_deep', 'm_mvsa', 'Mdeep', ...
        'Mmvsa_projected', 'Up', 'pc_var_percent', 'p', 'L', 'N', ...
        'DEEP_NUM_RUNS', 'MVSA_NUM_RUNS', 'MVSA_PLOT_RUN', ...
        'DEEP_SEED', 'MVSA_SEED', 'METRIC_CHUNK_SIZE', '-v7.3');

    fprintf('\n========== 20-pair method comparison summary ==========\n');
    fprintf('DeepMVSA RMSE             = %.8g +/- %.8g\n', ...
        deep_reconstruction_stats.rmse_mean, deep_reconstruction_stats.rmse_std);
    fprintf('MVSA RMSE                 = %.8g +/- %.8g\n', ...
        mvsa_reconstruction_stats.rmse_mean, mvsa_reconstruction_stats.rmse_std);
    fprintf('DeepMVSA relative residual= %.6f +/- %.6f %%\n', ...
        deep_reconstruction_stats.relative_residual_percent_mean, ...
        deep_reconstruction_stats.relative_residual_percent_std);
    fprintf('MVSA relative residual    = %.6f +/- %.6f %%\n', ...
        mvsa_reconstruction_stats.relative_residual_percent_mean, ...
        mvsa_reconstruction_stats.relative_residual_percent_std);
    fprintf('DeepMVSA runtime/run      = %.3f +/- %.3f sec\n', ...
        mean(runtime_runs), std(runtime_runs, 0));
    fprintf('MVSA runtime/run          = %.3f +/- %.3f sec\n', ...
        mvsa_runtime_sec, mvsa_runtime_std_sec);
    fprintf('MVSA total runtime        = %.3f sec\n', sum(mvsa_runtime_runs));
    fprintf('Mean paired RMSE difference (MVSA - DeepMVSA) = %.8g\n', ...
        mean(paired_rmse_difference));
    fprintf('Mean paired relative residual difference     = %.6f percentage points\n', ...
        mean(paired_relative_residual_difference));
    fprintf('MVSA memory monitoring    = not instrumented in supplied mvsa.m\n');
    fprintf('MVSA comparison MAT saved: %s\n', MVSA_DATA_FILE);
end

%% ===================== Save consolidated data for all figures =====================
% This third MAT file is self-contained for reproducing:
%   1) Reconstruction RMSE mean +/- std;
%   2) Log-volume mean +/- std;
%   3) Fig. 7(a)-style 2-D projection of all valid pixels and endmembers.
%
% It stores the actual plotted coordinates and all display settings.
% Replotting from this file does not require the original DZ01V dataset
% or rerunning DeepMVSA.

plot_cfg = struct();

% Figure canvas and axes layout
plot_cfg.figure_position = RMSE_FIGURE_POSITION;
plot_cfg.axes_position = RMSE_AXES_POSITION;

% Common typography
plot_cfg.x_tick_font_size = RMSE_X_TICK_FONT_SIZE;
plot_cfg.y_tick_font_size = RMSE_Y_TICK_FONT_SIZE;
plot_cfg.x_label_font_size = RMSE_X_LABEL_FONT_SIZE;
plot_cfg.y_label_font_size = RMSE_Y_LABEL_FONT_SIZE;
plot_cfg.title_font_size = RMSE_TITLE_FONT_SIZE;
plot_cfg.legend_font_size = RMSE_LEGEND_FONT_SIZE;

% RMSE appearance
plot_cfg.rmse_line_width = RMSE_LINE_WIDTH;
plot_cfg.rmse_band_alpha = RMSE_STD_BAND_ALPHA;
plot_cfg.rmse_line_color = RMSE_LINE_COLOR;
plot_cfg.rmse_band_color = RMSE_STD_BAND_COLOR;

% Log-volume appearance
plot_cfg.logvol_line_width = LOGVOL_LINE_WIDTH;
plot_cfg.logvol_band_alpha = LOGVOL_STD_BAND_ALPHA;
plot_cfg.logvol_line_color = LOGVOL_LINE_COLOR;
plot_cfg.logvol_band_color = LOGVOL_STD_BAND_COLOR;

% 2-D projection appearance
plot_cfg.projection_pixel_color = [0.20 0.20 0.20];
plot_cfg.projection_pixel_marker_size = 2;
plot_cfg.projection_hull_color = [1 0 0];
plot_cfg.projection_hull_line_width = 2.0;
plot_cfg.projection_endmember_color = [1 0 0];
plot_cfg.projection_endmember_marker = '^';
plot_cfg.projection_endmember_marker_size = 9;
plot_cfg.projection_endmember_line_width = 1.5;
plot_cfg.deepmvsa_endmember_color = [1.00 0.00 0.00];
plot_cfg.deepmvsa_endmember_marker = '^';
plot_cfg.mvsa_endmember_color = [0.00 0.25 0.90];
plot_cfg.mvsa_endmember_marker = 's';
plot_cfg.mvsa_hull_line_style = '--';

% Output filenames, retained for the standalone replot script
plot_cfg.rmse_png_file = RMSE_FIGURE_FILE;
plot_cfg.logvol_png_file = LOGVOL_FIGURE_FILE;
plot_cfg.projection_png_file = FIGURE_FILE;
plot_cfg.comparison_png_file = COMPARISON_FIGURE_FILE;

% Save all data required by the figures and the method comparison.
% Y_plot contains the 2-D coordinates of ALL valid pixels, not a subsample.
% m_deep contains the projected endmember coordinates of the final run.
save(ALL_PLOTS_DATA_FILE, ...
    'rmse_history', 'rmse_histories', 'rmse_stats', ...
    'logvol_history', 'logvol_histories', 'logvol_stats', ...
    'runtime_runs', 'memory_stats_runs', 'deep_seed_runs', ...
    'deep_reconstruction_metrics_runs', 'deep_reconstruction_stats', ...
    'deep_rmse_runs', 'deep_relative_residual_runs', ...
    'Y_plot', 'm_deep', 'Mdeep', 'M_deep', 'Up', 'pc_var_percent', ...
    'p', 'L', 'N', 'theta', ...
    'M_mvsa', 'M_mvsa_runs', 'm_mvsa', 'Mmvsa_projected', ...
    'mvsa_seed_runs', 'mvsa_runtime_runs', 'mvsa_runtime_sec', 'mvsa_runtime_std_sec', ...
    'mvsa_metrics_runs', 'mvsa_rmse_runs', 'mvsa_relative_residual_runs', ...
    'mvsa_reconstruction_metrics', 'mvsa_reconstruction_stats', ...
    'deep_reconstruction_metrics', 'comparison_summary', 'mvsa_options', ...
    'MVSA_MM_ITERS', 'MVSA_SPHERIZE', 'MVSA_MU', 'MVSA_LAMBDA', ...
    'MVSA_TOLF', 'MVSA_VERBOSE', 'MVSA_SEED', 'MVSA_NUM_RUNS', ...
    'MVSA_PLOT_RUN', 'METRIC_CHUNK_SIZE', ...
    'RUN_MVSA', 'MVSA_DATA_FILE', 'COMPARISON_FIGURE_FILE', ...
    'SAVE_ABUNDANCE_MATRICES', 'ABUNDANCE_DATA_FILE', ...
    'DEEP_NUM_RUNS', 'DEEP_RMSE_INTERVAL', 'DEEP_RMSE_MONITOR_SIZE', ...
    'DEEP_MM_ITERS', 'DEEP_WARM_UP', 'DEEP_LR', ...
    'DEEP_LAMBDA_VOL', 'DEEP_LAMBDA_NONNEG', 'DEEP_LAMBDA_EQ', ...
    'DEEP_LAMBDA_SUMONE', 'DEEP_LAMBDA_ENCLOSE', ...
    'DEEP_BATCH_SIZE', 'DEEP_SEED', 'plot_cfg', '-v7.3');

fprintf('Consolidated all-figure data saved to:\n  %s\n', ALL_PLOTS_DATA_FILE);

fprintf('\n========== DZ01V DeepMVSA-InvFlow ==========' );
fprintf('\nTotal Runtime             = %.3f sec\n', t_deep);
fprintf('Mean Runtime per Run      = %.3f sec\n', mean(runtime_runs));
fprintf('Peak Optimization Memory  = %.6f MB\n', memory_stats.peak_mb);
fprintf('Parameter + Adam Memory   = %.6f MB\n', memory_stats.parameter_optimizer_mb);
fprintf('Peak Memory Stage         = %s\n', memory_stats.peak_stage);
fprintf('Mini-batch size          = %d\n', DEEP_BATCH_SIZE);
fprintf('Training iterations      = %d\n', DEEP_MM_ITERS);
fprintf('RMSE monitor interval    = %d iterations\n', DEEP_RMSE_INTERVAL);
fprintf('RMSE monitor pixels      = %d\n', rmse_history.monitor_size);
fprintf('Repeated runs            = %d\n', DEEP_NUM_RUNS);
if RUN_MVSA
    fprintf('MVSA repeated runs        = %d\n', MVSA_NUM_RUNS);
    fprintf('MVSA mean runtime/run     = %.3f sec\n', mvsa_runtime_sec);
    fprintf('MVSA runtime std          = %.3f sec\n', mvsa_runtime_std_sec);
    fprintf('MVSA memory monitoring    = not instrumented in supplied mvsa.m\n');
    fprintf('DeepMVSA RMSE mean +/- std= %.8g +/- %.8g\n', ...
        deep_reconstruction_stats.rmse_mean, deep_reconstruction_stats.rmse_std);
    fprintf('MVSA RMSE mean +/- std    = %.8g +/- %.8g\n', ...
        mvsa_reconstruction_stats.rmse_mean, mvsa_reconstruction_stats.rmse_std);
end
fprintf('Approx. effective epochs = %.6f\n', ...
    DEEP_MM_ITERS * min(DEEP_BATCH_SIZE, N) / N);
if isstruct(theta) && isfield(theta, 'c')
    fprintf('Learned c                = %.6f\n', theta.c);
end

%% ===================== Reconstruction RMSE curve =====================
figure('Name', 'DZ01V - DeepMVSA Reconstruction RMSE', ...
    'Color', 'w', ...
    'Position', RMSE_FIGURE_POSITION);
ax_rmse = axes('Position', RMSE_AXES_POSITION);
hold on;
rmse_x = rmse_stats.iteration;
rmse_mean = rmse_stats.mean;
rmse_std = rmse_stats.std;
rmse_band = patch(ax_rmse, ...
    [rmse_x; flipud(rmse_x)], ...
    [rmse_mean - rmse_std; flipud(rmse_mean + rmse_std)], ...
    RMSE_STD_BAND_COLOR, ...
    'FaceAlpha', RMSE_STD_BAND_ALPHA, ...
    'EdgeColor', 'none', ...
    'DisplayName', 'Mean \pm std');
rmse_line = plot(ax_rmse, rmse_x, rmse_mean, '-', ...
    'Color', RMSE_LINE_COLOR, ...
    'LineWidth', RMSE_LINE_WIDTH, ...
    'DisplayName', 'Mean RMSE');
xlabel('Iteration', 'FontSize', RMSE_X_LABEL_FONT_SIZE);
ylabel('Reconstruction RMSE', 'FontSize', RMSE_Y_LABEL_FONT_SIZE);
title('DeepMVSA Reconstruction RMSE During Training', ...
    'FontSize', RMSE_TITLE_FONT_SIZE);
lgd_rmse = legend([rmse_line, rmse_band], 'Location', 'best');
lgd_rmse.FontSize = RMSE_LEGEND_FONT_SIZE;
ax_rmse.XAxis.FontSize = RMSE_X_TICK_FONT_SIZE;
ax_rmse.YAxis.FontSize = RMSE_Y_TICK_FONT_SIZE;
set(ax_rmse, 'TickDir', 'in', 'TickLength', [0.01 0.025]);
grid off;
box off;
xl_rmse = xlim(ax_rmse);
yl_rmse = ylim(ax_rmse);
rmse_top_border = line(ax_rmse, xl_rmse, [yl_rmse(2) yl_rmse(2)], ...
    'Color', ax_rmse.XColor, ...
    'LineWidth', ax_rmse.LineWidth, ...
    'HandleVisibility', 'off');
rmse_right_border = line(ax_rmse, [xl_rmse(2) xl_rmse(2)], yl_rmse, ...
    'Color', ax_rmse.YColor, ...
    'LineWidth', ax_rmse.LineWidth, ...
    'HandleVisibility', 'off');
set(gcf, 'PaperPositionMode', 'auto');

if SAVE_FIGURE
    exportgraphics(gcf, RMSE_FIGURE_FILE, 'Resolution', 300);
    save(RMSE_DATA_FILE, 'rmse_history', 'rmse_histories', 'rmse_stats', ...
        'logvol_history', 'logvol_histories', 'logvol_stats', ...
        'runtime_runs', 'memory_stats_runs', 'DEEP_NUM_RUNS', 'DEEP_RMSE_INTERVAL', ...
        'DEEP_RMSE_MONITOR_SIZE', ...
        'DEEP_MM_ITERS', 'DEEP_WARM_UP');
    fprintf('RMSE curve saved to:\n  %s\n', RMSE_FIGURE_FILE);
    fprintf('RMSE history saved to:\n  %s\n', RMSE_DATA_FILE);
end

%% ===================== Log-volume curve =====================
figure('Name', 'DZ01V - DeepMVSA Log-Volume', ...
    'Color', 'w', ...
    'Position', RMSE_FIGURE_POSITION);
ax_logvol = axes('Position', RMSE_AXES_POSITION);
hold on;
logvol_x = logvol_stats.iteration;
logvol_mean = logvol_stats.mean;
logvol_std = logvol_stats.std;
logvol_band = patch(ax_logvol, ...
    [logvol_x; flipud(logvol_x)], ...
    [logvol_mean - logvol_std; flipud(logvol_mean + logvol_std)], ...
    LOGVOL_STD_BAND_COLOR, ...
    'FaceAlpha', LOGVOL_STD_BAND_ALPHA, ...
    'EdgeColor', 'none', ...
    'DisplayName', 'Mean \pm std');
logvol_line = plot(ax_logvol, logvol_x, logvol_mean, '-', ...
    'Color', LOGVOL_LINE_COLOR, ...
    'LineWidth', LOGVOL_LINE_WIDTH, ...
    'DisplayName', 'Mean 1/logQ');
xlabel('Iteration', 'FontSize', RMSE_X_LABEL_FONT_SIZE);
ylabel('1/logQ', 'FontSize', RMSE_Y_LABEL_FONT_SIZE);
title('DeepMVSA 1/logQ During Training', ...
    'FontSize', RMSE_TITLE_FONT_SIZE);
lgd_logvol = legend([logvol_line, logvol_band], 'Location', 'best');
lgd_logvol.FontSize = RMSE_LEGEND_FONT_SIZE;
ax_logvol.XAxis.FontSize = RMSE_X_TICK_FONT_SIZE;
ax_logvol.YAxis.FontSize = RMSE_Y_TICK_FONT_SIZE;
set(ax_logvol, 'TickDir', 'in', 'TickLength', [0.01 0.025]);
grid off;
box off;
xl_logvol = xlim(ax_logvol);
yl_logvol = ylim(ax_logvol);
logvol_top_border = line(ax_logvol, xl_logvol, [yl_logvol(2) yl_logvol(2)], ...
    'Color', ax_logvol.XColor, ...
    'LineWidth', ax_logvol.LineWidth, ...
    'HandleVisibility', 'off');
logvol_right_border = line(ax_logvol, [xl_logvol(2) xl_logvol(2)], yl_logvol, ...
    'Color', ax_logvol.YColor, ...
    'LineWidth', ax_logvol.LineWidth, ...
    'HandleVisibility', 'off');
set(gcf, 'PaperPositionMode', 'auto');

if SAVE_FIGURE
    exportgraphics(gcf, LOGVOL_FIGURE_FILE, 'Resolution', 300);
    save(LOGVOL_DATA_FILE, 'logvol_history', 'logvol_histories', 'logvol_stats', ...
        'rmse_history', 'rmse_histories', 'rmse_stats', ...
        'runtime_runs', 'memory_stats_runs', 'DEEP_NUM_RUNS', ...
        'DEEP_RMSE_INTERVAL', 'DEEP_MM_ITERS', 'DEEP_WARM_UP');
    fprintf('Log-volume curve saved to:\n  %s\n', LOGVOL_FIGURE_FILE);
    fprintf('Log-volume history saved to:\n  %s\n', LOGVOL_DATA_FILE);
end

%% ===================== Fig. 7(a)-style 2-D result =====================
figure('Name', 'DZ01V - DeepMVSA vs MVSA Fig. 7(a)', 'Color', 'w');

% IMPORTANT: plot ALL valid pixels. No display subsampling is used.
plot(Y_plot(1,:), Y_plot(2,:), '.', ...
    'Color', [0.20 0.20 0.20], ...
    'MarkerSize', 2, ...
    'HandleVisibility', 'off');
hold on;

% DeepMVSA simplex outline and endmember markers.
try
    hull_idx_deep = convhull(m_deep(1,:)', m_deep(2,:)');
    h_deep_hull = plot(m_deep(1,hull_idx_deep), m_deep(2,hull_idx_deep), ...
        'r-', 'LineWidth', 2.0, 'DisplayName', 'DeepMVSA simplex');
catch
    center_deep = mean(m_deep, 2);
    angle_deep = atan2(m_deep(2,:) - center_deep(2), ...
                       m_deep(1,:) - center_deep(1));
    [~, order_deep] = sort(angle_deep);
    order_deep = [order_deep, order_deep(1)];
    h_deep_hull = plot(m_deep(1,order_deep), m_deep(2,order_deep), ...
        'r-', 'LineWidth', 2.0, 'DisplayName', 'DeepMVSA simplex');
end

h_deep_markers = plot(m_deep(1,:), m_deep(2,:), 'r^', ...
    'LineStyle', 'none', ...
    'MarkerSize', 9, ...
    'LineWidth', 1.5, ...
    'MarkerFaceColor', 'r', ...
    'DisplayName', 'DeepMVSA endmembers');

% MVSA simplex outline and endmember markers, using the SAME 2-D projection.
if RUN_MVSA
    try
        hull_idx_mvsa = convhull(m_mvsa(1,:)', m_mvsa(2,:)');
        h_mvsa_hull = plot(m_mvsa(1,hull_idx_mvsa), m_mvsa(2,hull_idx_mvsa), ...
            'b--', 'LineWidth', 2.0, 'DisplayName', 'MVSA simplex');
    catch
        center_mvsa = mean(m_mvsa, 2);
        angle_mvsa = atan2(m_mvsa(2,:) - center_mvsa(2), ...
                           m_mvsa(1,:) - center_mvsa(1));
        [~, order_mvsa] = sort(angle_mvsa);
        order_mvsa = [order_mvsa, order_mvsa(1)];
        h_mvsa_hull = plot(m_mvsa(1,order_mvsa), m_mvsa(2,order_mvsa), ...
            'b--', 'LineWidth', 2.0, 'DisplayName', 'MVSA simplex');
    end

    h_mvsa_markers = plot(m_mvsa(1,:), m_mvsa(2,:), 'bs', ...
        'LineStyle', 'none', ...
        'MarkerSize', 8, ...
        'LineWidth', 1.5, ...
        'MarkerFaceColor', 'none', ...
        'DisplayName', 'MVSA endmembers');

    legend([h_deep_markers, h_mvsa_markers], ...
        {'DeepMVSA endmembers', 'MVSA endmembers'}, ...
        'Location', 'best');
else
    legend(h_deep_markers, {'DeepMVSA endmembers'}, 'Location', 'best');
end

axis tight;
xlabel(sprintf('PC1 (%.2f%%)', pc_var_percent(1)), ...
    'FontSize', RMSE_X_LABEL_FONT_SIZE);
ylabel(sprintf('PC2 (%.2f%%)', pc_var_percent(2)), ...
    'FontSize', RMSE_Y_LABEL_FONT_SIZE);
ax_proj = gca;
ax_proj.XAxis.FontSize = RMSE_X_TICK_FONT_SIZE;
ax_proj.YAxis.FontSize = RMSE_Y_TICK_FONT_SIZE;
set(ax_proj, 'TickDir', 'in', 'TickLength', [0.01 0.025]);
grid off;
box off;
xl_proj = xlim(ax_proj);
yl_proj = ylim(ax_proj);
proj_top_border = line(ax_proj, xl_proj, [yl_proj(2) yl_proj(2)], ...
    'Color', ax_proj.XColor, ...
    'LineWidth', ax_proj.LineWidth, ...
    'HandleVisibility', 'off');
proj_right_border = line(ax_proj, [xl_proj(2) xl_proj(2)], yl_proj, ...
    'Color', ax_proj.YColor, ...
    'LineWidth', ax_proj.LineWidth, ...
    'HandleVisibility', 'off');

if SAVE_FIGURE
    exportgraphics(gcf, FIGURE_FILE, 'Resolution', 300);
    fprintf('DeepMVSA/MVSA 2-D comparison figure saved to:\n  %s\n', FIGURE_FILE);
end

%% ===================== Quantitative DeepMVSA vs MVSA comparison =====================
if RUN_MVSA
    figure('Name', 'DZ01V - DeepMVSA vs MVSA 20-run comparison', ...
        'Color', 'w', 'Position', [100 100 900 360]);

    % Panel 1: 20-run full-data reconstruction RMSE (mean +/- std).
    subplot(1,2,1);
    rmse_values = [deep_reconstruction_stats.rmse_mean, ...
                   mvsa_reconstruction_stats.rmse_mean];
    rmse_errors = [deep_reconstruction_stats.rmse_std, ...
                   mvsa_reconstruction_stats.rmse_std];
    bar(1:2, rmse_values);
    hold on;
    errorbar(1:2, rmse_values, rmse_errors, 'k.', ...
        'LineWidth', 1.3, 'CapSize', 10);
    set(gca, 'XTick', 1:2, ...
        'XTickLabel', {'DeepMVSA (20 runs)', 'MVSA (20 runs)'}, ...
        'TickDir', 'in', 'FontSize', 11);
    ylabel('Full-data reconstruction RMSE');
    title('Reconstruction error (mean +/- std)');
    box off;

    % Panel 2: per-run runtime (mean +/- std) for both methods.
    subplot(1,2,2);
    runtime_values = [mean(runtime_runs), mean(mvsa_runtime_runs)];
    runtime_errors = [std(runtime_runs, 0), std(mvsa_runtime_runs, 0)];
    bar(1:2, runtime_values);
    hold on;
    errorbar(1:2, runtime_values, runtime_errors, 'k.', ...
        'LineWidth', 1.3, 'CapSize', 10);
    set(gca, 'XTick', 1:2, ...
        'XTickLabel', {'DeepMVSA (20 runs)', 'MVSA (20 runs)'}, ...
        'TickDir', 'in', 'FontSize', 11);
    ylabel('Runtime per run (s)');
    title('Runtime (mean +/- std)');
    box off;

    if SAVE_FIGURE
        exportgraphics(gcf, COMPARISON_FIGURE_FILE, 'Resolution', 300);
        fprintf('Quantitative comparison figure saved to:\n  %s\n', ...
            COMPARISON_FIGURE_FILE);
    end
end


%% ===================== Local helper: chunked reconstruction metrics =====================
function metrics = reconstruction_metrics_chunked(Y, M, S, chunk_size)
% Compute full-data reconstruction metrics without allocating a full Yhat.
% RMSE is calculated over all L*N spectral values:
%   RMSE = sqrt(sum((Y-M*S).^2, 'all') / (L*N)).
% Relative residual is:
%   100 * ||Y-M*S||_F / ||Y||_F.

    [L, N] = size(Y);

    if size(M,1) ~= L
        error('M has %d rows, but Y has %d spectral bands.', size(M,1), L);
    end
    if size(S,1) ~= size(M,2) || size(S,2) ~= N
        error('S must have size %d x %d; received %s.', ...
            size(M,2), N, mat2str(size(S)));
    end

    sum_residual_sq = 0;
    sum_data_sq = 0;

    for first_col = 1:chunk_size:N
        last_col = min(N, first_col + chunk_size - 1);
        cols = first_col:last_col;

        Y_chunk = Y(:, cols);
        Yhat_chunk = M * S(:, cols);
        R_chunk = Y_chunk - Yhat_chunk;

        sum_residual_sq = sum_residual_sq + sum(double(R_chunk(:)).^2);
        sum_data_sq = sum_data_sq + sum(double(Y_chunk(:)).^2);
    end

    metrics = struct();
    metrics.rmse = sqrt(sum_residual_sq / (L*N));
    metrics.relative_residual_percent = ...
        100 * sqrt(sum_residual_sq) / max(sqrt(sum_data_sq), eps);
    metrics.sum_squared_residual = sum_residual_sq;
    metrics.sum_squared_data = sum_data_sq;
    metrics.num_bands = L;
    metrics.num_pixels = N;
    metrics.num_values = L*N;
    metrics.chunk_size = chunk_size;
end
